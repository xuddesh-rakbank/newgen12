package com.newgen.DAO.SignUpdate;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.Locale;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import javax.imageio.stream.MemoryCacheImageOutputStream;
import ISPack.CImageServer;
import ISPack.ISUtil.JPISException;
import Jdts.DataObject.JPDBString;
import org.apache.commons.codec.binary.Base64;

/**
 * Standalone utility: crops, grayscales and JPEG-compresses every signature
 * image in INPUT_FOLDER down to a target byte-size range, writing results to
 * OUTPUT_FOLDER. Paths are fixed at compile time - edit the constants below.
 */
public final class SignatureCompressor {

	// private static final String INPUT_FOLDER =
	// "C:/Suraj/ecilpseWorkspace/POC/Input"; //main signature file path
	// private static final String OUTPUT_FOLDER =
	// "C:/Suraj/ecilpseWorkspace/POC/Output"; //compressed image
	// path--Compreessed_Output
	private static final int MIN_TARGET_BYTES = 7 * 1024;
	private static final int MAX_TARGET_BYTES = 10 * 1024;

	// Ink is either near-black or noticeably colored - unlike gray
	// wood-grain/shadow background.
	private static final int DARK_LUMA_THRESHOLD = 90;
	private static final int SATURATION_THRESHOLD = 30;
	private static final int MIN_ROW_INK_PIXELS = 3;
	private static final int MIN_COL_INK_PIXELS = 3;
	private static final int CROP_PADDING = 15;

	private static final int TARGET_MAX_DIMENSION = 600; // longest side, orientation preserved
	private static final int BINARY_SEARCH_ITERATIONS = 10;
	private static final float MIN_JPEG_QUALITY = 0.25f; // floor so strokes never get crushed by compression
	private static final String[] SUPPORTED_EXTENSIONS = { ".jpg", ".jpeg", ".png", ".bmp" };

	private SignatureCompressor() {
	}

	public static String DownloadDocumentCompressor(String filePath) throws IOException {
		File inputFile = new File(filePath);

		if (!inputFile.exists() || !inputFile.isFile()) {
			throw new IOException("File not found: " + filePath);
		}

		try {
			return processFile(inputFile, inputFile.getParentFile());
		} catch (IOException e) {
			SignUpdateLogger.SignUpdateLogger.info("Failed to process " + inputFile.getName() + ": " + e.getMessage());
			return "";
		}
	}
// Download and Compress
	public static String DownloadCompressDocument(String imageIndex, String wiName, String docName, String cabinetName,
			String jtsIP, String jtsPort, String volumeId, String siteId, String fileDownloadLoc) {

		try {

			StringBuilder strFilePath = new StringBuilder();

			strFilePath.append(System.getProperty("user.dir"));
			strFilePath.append(File.separator);
			strFilePath.append(fileDownloadLoc);
			strFilePath.append(File.separator);
			strFilePath.append(wiName);
			strFilePath.append("_");
			strFilePath.append(docName);
			strFilePath.append(".PNG");

			String filePath = strFilePath.toString();

			File downloadDir = new File(System.getProperty("user.dir") + File.separator + fileDownloadLoc);

			if (!downloadDir.exists()) {
				downloadDir.mkdirs();
			}

			CImageServer cImageServer = null;

			try {
				cImageServer = new CImageServer(null, jtsIP, Short.parseShort(jtsPort));
			} catch (JPISException e) {

				SignUpdateLogger.SignUpdateLogger.error("Error creating CImageServer", e);

				return "F";
			}

			int odDownloadCode = cImageServer.JPISGetDocInFile_MT(null, jtsIP, Short.parseShort(jtsPort), cabinetName,
					Short.parseShort(siteId), Short.parseShort(volumeId), Integer.parseInt(imageIndex), "", filePath,
					new JPDBString());

			SignUpdateLogger.SignUpdateLogger.info("JPISGetDocInFile_MT Return Code = " + odDownloadCode);

			if (odDownloadCode == 1) {

				// Existing compressor call
				String base64 = DownloadDocumentCompressor(filePath);

				try {
					File downloadedFile = new File(filePath);

					if (downloadedFile.exists()) {
						downloadedFile.delete();
					}
				} catch (Exception ex) {
					SignUpdateLogger.SignUpdateLogger.error("Unable to delete temp file", ex);
				}

				return base64;
			}

		} catch (Exception e) {

			SignUpdateLogger.SignUpdateLogger.error("DownloadCompressDocument Error : " + e.getMessage(), e);
		}

		return "F";
	}

	private static boolean hasSupportedExtension(String name) {
		String lower = name.toLowerCase(Locale.ROOT);
		for (String ext : SUPPORTED_EXTENSIONS) {
			if (lower.endsWith(ext)) {
				return true;
			}
		}
		return false;
	}

	private static String processFile(File inputFile, File outputFolder) throws IOException {
		BufferedImage original = ImageIO.read(inputFile);
		if (original == null) {
			throw new IOException("Unsupported or unreadable image");
		}
		BufferedImage cropped = cropToInk(original);
		BufferedImage prepared = toGrayscale(cropped, TARGET_MAX_DIMENSION);
		byte[] compressed = compressToTargetSize(prepared, MIN_TARGET_BYTES, MAX_TARGET_BYTES);
		String baseName = stripExtension(inputFile.getName());
		File outputFile = new File(outputFolder, baseName + "_compressed.jpg");
		Files.write(outputFile.toPath(), compressed);
//        System.out.printf(
//                "%s: %d bytes (%dx%d) -> %d bytes (%dx%d) -> %s%n",
//                inputFile.getName(), inputFile.length(), original.getWidth(), original.getHeight(),
//                compressed.length, prepared.getWidth(), prepared.getHeight(), outputFile.getName());

		byte[] encodedBytes = Base64.encodeBase64(compressed);
		String sEncodedBytes = new String(encodedBytes);
		return sEncodedBytes;
	}

	private static String stripExtension(String name) {
		int dot = name.lastIndexOf('.');
		return dot > 0 ? name.substring(0, dot) : name;
	}

	/**
	 * Trims blank margin around the signature by finding the bounding box of dark
	 * pixels.
	 */
	private static BufferedImage cropToInk(BufferedImage src) {
		int width = src.getWidth();
		int height = src.getHeight();
		int[] pixels = src.getRGB(0, 0, width, height, null, 0, width);

		int[] rowCounts = new int[height];
		int[] colCounts = new int[width];

		for (int y = 0; y < height; y++) {
			int rowOffset = y * width;
			for (int x = 0; x < width; x++) {
				int rgb = pixels[rowOffset + x];
				int r = (rgb >> 16) & 0xFF;
				int g = (rgb >> 8) & 0xFF;
				int b = rgb & 0xFF;
				int maxChannel = Math.max(r, Math.max(g, b));
				int minChannel = Math.min(r, Math.min(g, b));
				int saturation = maxChannel - minChannel;
				int luma = (r * 299 + g * 587 + b * 114) / 1000;

				if (saturation >= SATURATION_THRESHOLD || luma <= DARK_LUMA_THRESHOLD) {
					rowCounts[y]++;
					colCounts[x]++;
				}
			}
		}

		int minY = firstIndexAtLeast(rowCounts, MIN_ROW_INK_PIXELS, true);
		int maxY = firstIndexAtLeast(rowCounts, MIN_ROW_INK_PIXELS, false);
		int minX = firstIndexAtLeast(colCounts, MIN_COL_INK_PIXELS, true);
		int maxX = firstIndexAtLeast(colCounts, MIN_COL_INK_PIXELS, false);

		if (minY < 0 || minX < 0) {
			return src; // no reliable ink detected, skip cropping
		}

		minX = Math.max(0, minX - CROP_PADDING);
		minY = Math.max(0, minY - CROP_PADDING);
		maxX = Math.min(width - 1, maxX + CROP_PADDING);
		maxY = Math.min(height - 1, maxY + CROP_PADDING);

		return src.getSubimage(minX, minY, maxX - minX + 1, maxY - minY + 1);
	}

	private static int firstIndexAtLeast(int[] counts, int minCount, boolean fromStart) {
		if (fromStart) {
			for (int i = 0; i < counts.length; i++) {
				if (counts[i] >= minCount) {
					return i;
				}
			}
		} else {
			for (int i = counts.length - 1; i >= 0; i--) {
				if (counts[i] >= minCount) {
					return i;
				}
			}
		}
		return -1;
	}

	private static BufferedImage toGrayscale(BufferedImage src, int targetMaxDimension) {
		int srcWidth = src.getWidth();
		int srcHeight = src.getHeight();
		int longerSide = Math.max(srcWidth, srcHeight);
		double scale = longerSide > targetMaxDimension ? targetMaxDimension / (double) longerSide : 1.0;
		int width = Math.max(1, (int) Math.round(srcWidth * scale));
		int height = Math.max(1, (int) Math.round(srcHeight * scale));
		BufferedImage out = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
		Graphics2D g = out.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(src, 0, 0, width, height, null);
		g.dispose();
		return out;
	}

	/** Binary-searches JPEG quality to land within [minBytes, maxBytes]. */
	private static byte[] compressToTargetSize(BufferedImage image, int minBytes, int maxBytes) throws IOException {
		float low = MIN_JPEG_QUALITY;
		float high = 0.95f;
		byte[] best = encodeJpeg(image, high);
		for (int i = 0; i < BINARY_SEARCH_ITERATIONS; i++) {
			float quality = (low + high) / 2f;
			byte[] result = encodeJpeg(image, quality);
			best = result;
			if (result.length >= minBytes && result.length <= maxBytes) {
				return result;
			}
			if (result.length > maxBytes) {
				high = quality;
			} else {
				low = quality;
			}
		}
		return best; // closest achieved after fixed iteration budget
	}

	private static byte[] encodeJpeg(BufferedImage image, float quality) throws IOException {
		Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpg");
		if (!writers.hasNext()) {
			throw new IOException("No JPEG writer available in this JDK.");
		}
		ImageWriter writer = writers.next();
		ImageWriteParam param = writer.getDefaultWriteParam();
		param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
		param.setCompressionQuality(quality);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try (ImageOutputStream ios = new MemoryCacheImageOutputStream(baos)) {
			writer.setOutput(ios);
			writer.write(null, new IIOImage(image, null, null), param);
		} finally {
			writer.dispose();
		}
		return baos.toByteArray();
	}
}
