/*
---------------------------------------------------------------------------------------------------------
                  NEWGEN SOFTWARE TECHNOLOGIES LIMITED

Group                   : Application - Projects
Project/Product            : RAK BPM
Application                : RAK BPM Utility
Module                    : Sign Update
File Name                : SignUpdateLogger.java
Author                     : Uddeshya Rastogi
Date (DD/MM/YYYY)        : 30/06/2026

---------------------------------------------------------------------------------------------------------
                     CHANGE HISTORY
---------------------------------------------------------------------------------------------------------

Problem No/CR No        Change Date           Changed By             Change Description
---------------------------------------------------------------------------------------------------------
Initial                 30/06/2026            Your Name              Logger for Sign Update WS
---------------------------------------------------------------------------------------------------------
*/

package com.newgen.DAO.SignUpdate;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public final class SignUpdateLogger {

    private static String loggerName = "SignUpdateLogger";

    protected static org.apache.log4j.Logger SignUpdateLogger = org.apache.log4j.Logger.getLogger(loggerName);;
    static {
        setLogger();
    }

    protected static void setLogger() {

    	try {

    	    System.out.println("######## SignUpdateLogger Started ########");

    	    String configPath = System.getProperty("user.dir")
    	            + File.separator + "log4jFiles"
    	            + File.separator + "SignUpdateLogger.properties";

    	    System.out.println("user.dir = " + System.getProperty("user.dir"));
    	    System.out.println("ConfigPath = " + configPath);
    	    System.out.println("ConfigExists = " + new File(configPath).exists());

            Date date = new Date();
            DateFormat logDateFormat = new SimpleDateFormat("dd-MM-yyyy");

            Properties p = new Properties();

            p.load(new FileInputStream(configPath));

            System.out.println("Logger Property File Loaded");

            String dynamicLogPath;
            String originalFileName = p.getProperty("log4j.appender." + loggerName + ".File");

            // ✅ Default dynamic path
            dynamicLogPath = "Logs/SignUpdate/" + logDateFormat.format(date) + "/SignUpdate_Log.xml";

            if (originalFileName != null && !originalFileName.trim().isEmpty()) {

                dynamicLogPath =
                        originalFileName.substring(0, originalFileName.lastIndexOf("/") + 1)
                        + logDateFormat.format(date)
                        + originalFileName.substring(originalFileName.lastIndexOf("/"));
            }

            // ✅ Create directory
            File dir = new File(dynamicLogPath.substring(0, dynamicLogPath.lastIndexOf("/")));
            dir.mkdirs();

            // ✅ Create file if not exists
            File logFile = new File(dynamicLogPath);
            if (!logFile.exists()) {
                logFile.createNewFile();
            }

            // ✅ Set dynamic log path
            p.put("log4j.appender." + loggerName + ".File", dynamicLogPath);

            PropertyConfigurator.configure(p);
            

        } catch (Exception e) {

            System.out.println("SIGN LOGGER ERROR : " + e.getMessage());

            e.printStackTrace();
        }
    }
}