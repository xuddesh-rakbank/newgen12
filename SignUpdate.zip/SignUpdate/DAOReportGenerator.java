package com.newgen.DAO.SignUpdate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Set;
import java.util.Iterator;
import java.util.ArrayList;

import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileInputStream;
import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.BaseColor;

public class DAOReportGenerator {

	public void generateReportsForWI(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {

		try {

			SignUpdateLogger.SignUpdateLogger.info("Report Generation Started For WI : " + wiName);

			String query = "select " + "is_kyc_report_onload," + "is_risk_score_report_onload,"
					+ "is_firco_report_onload," + "is_dedupe_onload " + "from NG_DAO_EXTTABLE with(nolock) "
					+ "where WI_name='" + wiName + "'";

			String inputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionId);
			String outputXML = SignUpdate_WI.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
			XMLParser parser = new XMLParser(outputXML);
			if (!"0".equals(parser.getValueOf("MainCode"))) {
				SignUpdateLogger.SignUpdateLogger.info("Unable To Fetch Flags For WI : " + wiName);
				return;
			}
			String record = parser.getNextValueOf("Record");
			if (record == null || record.trim().isEmpty()) {
				return;
			}

			XMLParser recParser = new XMLParser(record);
			String kycFlag = recParser.getValueOf("is_kyc_report_onload");
			String riskFlag = recParser.getValueOf("is_risk_score_report_onload");
			String fircoFlag = recParser.getValueOf("is_firco_report_onload");
			String dedupeFlag = recParser.getValueOf("is_dedupe_onload");

			// KYC
			if (!"Y".equalsIgnoreCase(kycFlag)) {
				SignUpdateLogger.SignUpdateLogger.info("Generating KYC Report For : " + wiName);
				boolean kycGenerated = generateKYCReport(wiName, cabinetName, sessionId, jtsIP, jtsPort);
				if (kycGenerated) {
					updateFlag(wiName, "is_kyc_report_onload", cabinetName, sessionId, jtsIP, jtsPort);
				}

			}

			// Risk
			if (!"Y".equalsIgnoreCase(riskFlag)) {
				SignUpdateLogger.SignUpdateLogger.info("Generating Risk Report For : " + wiName);
				boolean riskGenerated = generateRiskReport(wiName, cabinetName, sessionId, jtsIP, jtsPort);
				if (riskGenerated) {
					updateFlag(wiName, "is_risk_score_report_onload", cabinetName, sessionId, jtsIP, jtsPort);
				} else {
					SignUpdateLogger.SignUpdateLogger.error("Risk Report Generation Failed For : " + wiName);
				}
			}

			// Firco
			if (!"Y".equalsIgnoreCase(fircoFlag)) {
				SignUpdateLogger.SignUpdateLogger.info("Generating Firco Report For : " + wiName);
				boolean fircoGenerated = generateFircoReport(wiName, cabinetName, sessionId, jtsIP, jtsPort);
				if (fircoGenerated) {
					updateFlag(wiName, "is_firco_report_onload", cabinetName, sessionId, jtsIP, jtsPort);
				}
			}

			// Dedupe
			if (!"Y".equalsIgnoreCase(dedupeFlag)) {
				SignUpdateLogger.SignUpdateLogger.info("Generating Dedupe Report For : " + wiName);
				boolean dedupeGenerated = generateDedupeReport(wiName, cabinetName, sessionId, jtsIP, jtsPort);
				if (dedupeGenerated) {
					updateFlag(wiName, "is_dedupe_onload", cabinetName, sessionId, jtsIP, jtsPort);
				}

			}

		} catch (Exception e) {

			SignUpdateLogger.SignUpdateLogger.error("Exception In Report Generation", e);
		}
	}

	// ============================
	// KYC
	// ============================
	private boolean generateKYCReport(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {

		try {

			XMLParser customerData = getKycCustomerData(wiName, cabinetName, sessionId, jtsIP, jtsPort);

			if (customerData == null) {
				return false;
			}
			String firstName = customerData.getValueOf("Given_Name");
			String middleName = customerData.getValueOf("Middle_Name");
			String lastName = customerData.getValueOf("Surname");
			String emailId = customerData.getValueOf("email_id_1");
			String mobileNo = customerData.getValueOf("mobile_no_1");
			String nationality = customerData.getValueOf("Nationality");
			String secondaryNationality = customerData.getValueOf("Secondary_Nationality");
			String dob = customerData.getValueOf("DOB");
			String riskScore = customerData.getValueOf("risk_score");
			String pep = customerData.getValueOf("PEP");
			String purposeOfAccount = customerData.getValueOf("Purpose_of_account");
			String employmentType = customerData.getValueOf("employement_type");
			String employerName = customerData.getValueOf("Company_employer_name");
			String currentDesignation = customerData.getValueOf("current_visa_designation");
			String monthlyIncome = customerData.getValueOf("gross_monthly_salary_income");
			String employerCode = customerData.getValueOf("employer_code");
			String turnoverCash = customerData.getValueOf("Monthly_expected_turnover_Cash");
			String turnoverNonCash = customerData.getValueOf("Monthly_expected_turnover_non_cash");
			String customerName = "";

			if (middleName == null || middleName.trim().isEmpty()) {
				customerName = firstName + " " + lastName;
			} else {
				customerName = firstName + " " + middleName + " " + lastName;
			}
			String nationalityDesc = getCountryDescription(nationality, cabinetName, sessionId, jtsIP, jtsPort);
			String secondaryNationalityDesc = getCountryDescription(secondaryNationality, cabinetName, sessionId, jtsIP,
					jtsPort);
			Map<String, String> kycPdfData = new HashMap<String, String>();
			kycPdfData.put("CUSTOMER_NAME", customerName);
			kycPdfData.put("EMAIL_ID", emailId);
			kycPdfData.put("MOBILE_NO", mobileNo);
			kycPdfData.put("DOB", dob);
			kycPdfData.put("NATIONALITY", nationalityDesc);
			kycPdfData.put("SECONDARY_NATIONALITY", secondaryNationalityDesc);
			kycPdfData.put("RISK_SCORE", riskScore);
			kycPdfData.put("PEP", pep);
			kycPdfData.put("PURPOSE_OF_ACCOUNT", purposeOfAccount);
			kycPdfData.put("EMPLOYMENT_TYPE", employmentType);
			kycPdfData.put("EMPLOYER_NAME", employerName);
			kycPdfData.put("CURRENT_DESIGNATION", currentDesignation);
			kycPdfData.put("MONTHLY_INCOME", monthlyIncome);
			kycPdfData.put("EMPLOYER_CODE", employerCode);
			kycPdfData.put("TURNOVER_CASH", turnoverCash);
			kycPdfData.put("TURNOVER_NON_CASH", turnoverNonCash);
			boolean pdfGenerated = generateKycPdf(wiName, kycPdfData);
			return pdfGenerated;
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("KYC Report Error", e);
			return false;
		}

	}

	// ============================
	// FIRCO
	// ============================
	private boolean generateFircoReport(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {

		try {

			XMLParser fircoData = getFircoExtData(wiName, cabinetName, sessionId, jtsIP, jtsPort);

			if (fircoData == null) {
				return false;
			}
			SignUpdateLogger.SignUpdateLogger.info("Firco Base Data Fetched Successfully");
			String cif = fircoData.getValueOf("CIF");
			String firstName = fircoData.getValueOf("Given_Name");
			String middleName = fircoData.getValueOf("Middle_Name");
			String lastName = fircoData.getValueOf("Surname");
			String dob = fircoData.getValueOf("DOB");
			String emailId = fircoData.getValueOf("email_id_1");
			String mobileNo = fircoData.getValueOf("mobile_no_1");
			String passportNo = fircoData.getValueOf("Passport_No");
			String nationality = fircoData.getValueOf("Nationality");
			String countryOfResidence = fircoData.getValueOf("country_of_residence");
			String passportIssuingCountry = fircoData.getValueOf("Passport_issuing_country");
			String gender = fircoData.getValueOf("Gender");
			String customerName = "";
			if (middleName == null || middleName.trim().isEmpty()) {
				customerName = firstName + " " + lastName;
			} else {
				customerName = firstName + " " + middleName + " " + lastName;
			}
			String genderDesc = "";
			if ("M".equalsIgnoreCase(gender)) {
				genderDesc = "Male";
			} else if ("F".equalsIgnoreCase(gender)) {
				genderDesc = "Female";
			} else {
				genderDesc = "Other";
			}
			SignUpdateLogger.SignUpdateLogger.info("Gender Description : " + genderDesc);
			SignUpdateLogger.SignUpdateLogger.info("Customer Name : " + customerName);
			SignUpdateLogger.SignUpdateLogger.info("CIF : " + cif);
			SignUpdateLogger.SignUpdateLogger.info("Nationality : " + nationality);

			String nationalityDesc = getCountryDescription(nationality, cabinetName, sessionId, jtsIP, jtsPort);
			SignUpdateLogger.SignUpdateLogger.info("Nationality Desc : " + nationalityDesc);
			String countryOfResidenceDesc = getCountryDescription(countryOfResidence, cabinetName, sessionId, jtsIP,
					jtsPort);
			SignUpdateLogger.SignUpdateLogger.info("Country Of Residence Desc : " + countryOfResidenceDesc);
			String passportIssuingCountryDesc = getCountryDescription(passportIssuingCountry, cabinetName, sessionId,
					jtsIP, jtsPort);
			SignUpdateLogger.SignUpdateLogger.info("Passport Country Desc : " + passportIssuingCountryDesc);

			Map<String, String> fircoPdfData = new HashMap<String, String>();

			fircoPdfData.put("CUSTOMER_NAME", customerName);
			fircoPdfData.put("CIF", cif);
			fircoPdfData.put("DOB", dob);
			fircoPdfData.put("EMAIL_ID", emailId);
			fircoPdfData.put("MOBILE_NO", mobileNo);
			fircoPdfData.put("PASSPORT_NO", passportNo);
			fircoPdfData.put("NATIONALITY", nationalityDesc);
			fircoPdfData.put("COUNTRY_OF_RESIDENCE", countryOfResidenceDesc);
			fircoPdfData.put("PASSPORT_COUNTRY", passportIssuingCountryDesc);
			fircoPdfData.put("GENDER", genderDesc);
			/*
			 * TODO Fetch UID_Details_Grid Data
			 *
			 * Columns Required: OFAC_ID Matching_Text Name Origin Designation Date_of_Birth
			 * User_Data_1 Nationality Passport Additional_Info Remarks
			 */
			boolean pdfGenerated = generateFircoPdf(wiName, fircoPdfData);
			return pdfGenerated;

		} catch (Exception e) {

			SignUpdateLogger.SignUpdateLogger.error("Firco Report Error", e);
		}
		return false;
	}

	// ============================
	// DEDUPE
	// ============================
	private boolean generateDedupeReport(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {

		try {

			// Dedupe Table Fetch

			// PDF Generate

			// Attach Document

		} catch (Exception e) {

			SignUpdateLogger.SignUpdateLogger.error("Dedupe Report Error", e);
		}
		return false;
	}

	// ============================
	// RISK
	// ============================
	private boolean generateRiskReport(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {
		try {
			/*
			 * TODO CRAM specific logic to be implemented.
			 */
			String cramFlag = getCramSwitchFlag(cabinetName, sessionId, jtsIP, jtsPort);
			XMLParser extData = getRiskExtTableData(wiName, cabinetName, sessionId, jtsIP, jtsPort);
			if (extData == null) {
				return false;
			}
			Map<String, String> riskDBValues = fetchRiskSheetDBValues(wiName, cabinetName, sessionId, jtsIP, jtsPort);
			String persona = derivePersona(extData);
			SignUpdateLogger.SignUpdateLogger.info("Risk Report Processing Started");
			boolean success = generateRiskPdf(wiName, extData, riskDBValues, persona);
			return success;
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Risk Report Error", e);

			return false;
		}
	}

	// ============================
	// FLAG UPDATE
	// ============================
	private void updateFlag(String wiName, String columnName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {

		try {

			String query = "update NG_DAO_EXTTABLE " + "set " + columnName + "='Y' " + "where WI_name='" + wiName + "'";
			String inputXML = CommonMethods.apUpdateInput(cabinetName, sessionId, "NG_DAO_EXTTABLE", columnName, "'Y'",
					"WI_name='" + wiName + "'");
			String outputXML = SignUpdate_WI.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
			SignUpdateLogger.SignUpdateLogger
					.info("Flag Updated : " + columnName + " For WI : " + wiName + " Response : " + outputXML);
		} catch (Exception e) {

			SignUpdateLogger.SignUpdateLogger.error("Flag Update Error", e);
		}
	}
	// ============================
	// RISK Generation Methods
	// ============================

	private String getCramSwitchFlag(String cabinetName, String sessionId, String jtsIP, String jtsPort) {
		try {
			String query = "SELECT CONST_FIELD_VALUE " + "FROM USR_0_BPM_CONSTANTS WITH(NOLOCK) "
					+ "WHERE CONST_FIELD_NAME='DAO_CRAM_SWITCH'";
			String inputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionId);
			String outputXML = SignUpdate_WI.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
			XMLParser parser = new XMLParser(outputXML);
			if ("0".equals(parser.getValueOf("MainCode"))) {
				String record = parser.getNextValueOf("Record");

				if (record != null) {
					XMLParser recParser = new XMLParser(record);
					return recParser.getValueOf("CONST_FIELD_VALUE");
				}
			}
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("CRAM Flag Error", e);
		}

		return "N";
	}

	private XMLParser getRiskExtTableData(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {
		try {
			String query = "SELECT " + "CIF, " + "Given_Name, " + "Middle_Name, " + "Surname, " + "Nationality, "
					+ "Secondary_Nationality, " + "PEP, " + "pepValue, " + "employement_type, " + "product_typw, "
					+ "product_currency, " + "country_of_residence, " + "risk_score, "
					+ "Money_send_and_received_Countries_final_IBPS, " + "is_Ruling_Family "
					+ "FROM NG_DAO_EXTTABLE WITH(NOLOCK) " + "WHERE WI_name='" + wiName + "'";

			SignUpdateLogger.SignUpdateLogger.info("Risk Ext Data Query : " + query);

			String inputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionId);
			String outputXML = SignUpdate_WI.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
			XMLParser parser = new XMLParser(outputXML);

			if (!"0".equals(parser.getValueOf("MainCode"))) {
				SignUpdateLogger.SignUpdateLogger.error("MainCode Failed While Fetching Risk Data");
				return null;
			}

			String record = parser.getNextValueOf("Record");

			if (record == null || record.trim().isEmpty()) {
				SignUpdateLogger.SignUpdateLogger.error("No Record Found In NG_DAO_EXTTABLE For WI : " + wiName);
				return null;
			}

			return new XMLParser(record);
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Exception In getRiskExtTableData", e);
			return null;
		}
	}

	private String derivePersona(XMLParser extData) {
		try {
			String rulingFlag = extData.getValueOf("is_Ruling_Family");
			String empType = extData.getValueOf("employement_type");

			if ("Y".equalsIgnoreCase(rulingFlag)) {
				return "Ruling Family";
			}

			if ("Self employed".equalsIgnoreCase(empType)) {
				return "Self Employed - Resident";
			}

			if ("Salaried".equalsIgnoreCase(empType)) {
				return "Employed - Resident";
			}

		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Persona Error", e);
		}

		return "Employed - Resident";
	}

	private Map<String, String> fetchRiskSheetDBValues(String wiName, String cabinetName, String sessionId,
			String jtsIP, String jtsPort) {
		Map<String, String> riskDBValues = new HashMap<String, String>();

		try {
			String query = "SELECT * " + "FROM NG_DAO_RISK_SHEET_DATA WITH(NOLOCK) " + "WHERE WI_NAME='" + wiName + "'";
			String inputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionId);
			String outputXML = SignUpdate_WI.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
			XMLParser parser = new XMLParser(outputXML);

			if ("0".equals(parser.getValueOf("MainCode"))) {
				String record = parser.getNextValueOf("Record");

				if (record != null && !record.trim().isEmpty()) {
					XMLParser rec = new XMLParser(record);
					riskDBValues.put("PERSONA", rec.getValueOf("PERSONA"));
					riskDBValues.put("PRODUCT_TYPE", rec.getValueOf("PRODUCT_TYPE"));
					riskDBValues.put("CURRENCY", rec.getValueOf("CURRENCY"));
					riskDBValues.put("CASH_RISK", rec.getValueOf("CASH_RISK"));
					riskDBValues.put("LENGTH_OF_RESIDENCY", rec.getValueOf("LENGTH_OF_RESIDENCY"));
					riskDBValues.put("MATURITY_RELATIONSHIP", rec.getValueOf("MATURITY_RELATIONSHIP"));
					riskDBValues.put("COUNTRY_OF_BIRTH", rec.getValueOf("COUNTRY_OF_BIRTH"));
					riskDBValues.put("AVERAGE_EXPECTED_TXN", rec.getValueOf("AVG_EXPECTED_TXN"));
					riskDBValues.put("HNWI_FLAG", rec.getValueOf("HNWI_FLAG"));
					riskDBValues.put("DELIVERY_CHANNEL", rec.getValueOf("DELIVERY_CHANNEL"));
				}
			}
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Risk Sheet Data Error", e);
		}

		return riskDBValues;
	}

	private boolean generateRiskPdf(String wiName, XMLParser extData, Map<String, String> riskDBValues,
			String persona) {
		try {
			SignUpdateLogger.SignUpdateLogger.info("Risk PDF Generation Started");
			String cif = extData.getValueOf("CIF");
			String riskScore = extData.getValueOf("risk_score");
			String employmentType = extData.getValueOf("employement_type");
			String nationality = extData.getValueOf("Nationality");
			Properties properties = new Properties();
			properties.load(new FileInputStream(System.getProperty("user.dir") + File.separator + "CustomConfig"
					+ File.separator + "RakBankConfig.properties"));

			String path = System.getProperty("user.dir");
//TODo
			String pdfTemplatePath = path + properties.getProperty("DAO_RAK_RiskScore");
			String dynamicPdfName = wiName + "Risk Score Sheet.pdf";

			String generatedPdfPath = path + properties.getProperty("DAO_GENERTATED_PDF_PATH") + File.separator
					+ dynamicPdfName;

			String pdfArabtypePath = path + properties.getProperty("RAOP_ARABTYPE_PATH");
			SignUpdateLogger.SignUpdateLogger.info("PDF Template Path : " + pdfTemplatePath);

			SignUpdateLogger.SignUpdateLogger.info("Arabic Font Path : " + pdfArabtypePath);

			SignUpdateLogger.SignUpdateLogger.info("Generated PDF Path : " + generatedPdfPath);

			Map<String, String> columnValues = new HashMap<String, String>();

			columnValues.put("CIF_NUMBER", cif);
			columnValues.put("RISK_SCORE", riskScore);
			columnValues.put("EMPLOYMENT_TYPE", employmentType);
			columnValues.put("NATIONALITY", nationality);
			columnValues.put("PERSONA", persona);
			columnValues.put("PRODUCT_TYPE", riskDBValues.get("PRODUCT_TYPE"));
			columnValues.put("CURRENCY", riskDBValues.get("CURRENCY"));
			columnValues.put("CASH_RISK", riskDBValues.get("CASH_RISK"));
			columnValues.put("LENGTH_OF_RESIDENCY", riskDBValues.get("LENGTH_OF_RESIDENCY"));
			columnValues.put("MATURITY_RELATIONSHIP", riskDBValues.get("MATURITY_RELATIONSHIP"));
			columnValues.put("COUNTRY_OF_BIRTH", riskDBValues.get("COUNTRY_OF_BIRTH"));
			columnValues.put("AVERAGE_EXPECTED_TXN", riskDBValues.get("AVERAGE_EXPECTED_TXN"));
			// todo
			// HNWI_FLAG
			// DELIVERY_CHANNEL
			// ADVERSE_MEDIA_FLAG
			// PERSONAL_ACCOUNT_FLAG
			// SAR_FLAG
			// NON_RESIDENT_FLAG
			// PEP_STATUS
			// Date
			// final_risk_type
			// P_FullName
			// acctype_curr
			// DEMOGRAPHIC
			// INDUSTRY_SUBSEGMENT

			SignUpdateLogger.SignUpdateLogger.info("Risk PDF Fields Prepared : " + columnValues);
			PdfReader reader = new PdfReader(pdfTemplatePath);
			PdfStamper stamp = new PdfStamper(reader, new FileOutputStream(generatedPdfPath));

			AcroFields form = stamp.getAcroFields();
			BaseFont unicode = BaseFont.createFont(pdfArabtypePath, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);

			ArrayList<BaseFont> al = new ArrayList<BaseFont>();
			al.add(unicode);
			form.setSubstitutionFonts(al);

			PdfWriter writer = stamp.getWriter();
			writer.setRunDirection(PdfWriter.RUN_DIRECTION_RTL);

			BaseFont bf1 = BaseFont.createFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.EMBEDDED);
			form.addSubstitutionFont(bf1);

			Set<String> keys = columnValues.keySet();
			Iterator<String> itr = keys.iterator();
			while (itr.hasNext()) {
				String fieldName = itr.next();

				String fieldValue = columnValues.get(fieldName);

				if (fieldValue == null) {
					fieldValue = "";
				}
				form.setField(fieldName, fieldValue);
			}
			stamp.setFormFlattening(true);
			stamp.close();
			reader.close();

			File generatedFile = new File(generatedPdfPath);

			if (!generatedFile.exists()) {
				SignUpdateLogger.SignUpdateLogger.error("Generated PDF Not Found");

				return false;
			}
			SignUpdateLogger.SignUpdateLogger.info("Generated PDF Verified");

			SignUpdateLogger.SignUpdateLogger.info("PDF Ready For Attachment");

			/*
			 * TODO Attach Document SearchExistingDoc(...)
			 */

			return true;
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Risk PDF Generation Error", e);

			return false;
		}
	}

	// ============================
	// FIRCO Generation Method
	// ============================
	private XMLParser getFircoExtData(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {
		try {
			String query = "SELECT " + "CIF," + "Given_Name," + "Middle_Name," + "Surname," + "DOB," + "email_id_1,"
					+ "mobile_no_1," + "Passport_No," + "Nationality," + "country_of_residence,"
					+ "Passport_issuing_country," + "Gender " + "FROM NG_DAO_EXTTABLE WITH(NOLOCK) " + "WHERE WI_name='"
					+ wiName + "'";
			SignUpdateLogger.SignUpdateLogger.info("Firco Ext Data Query : " + query);
			String inputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionId);
			String outputXML = SignUpdate_WI.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
			XMLParser parser = new XMLParser(outputXML);

			if (!"0".equals(parser.getValueOf("MainCode"))) {
				SignUpdateLogger.SignUpdateLogger.error("MainCode Failed While Fetching Firco Data");
				return null;
			}

			String record = parser.getNextValueOf("Record");

			if (record == null || record.trim().isEmpty()) {
				SignUpdateLogger.SignUpdateLogger.error("No Record Found In NG_DAO_EXTTABLE For WI : " + wiName);
				return null;
			}

			return new XMLParser(record);
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Exception In getFircoExtData", e);
			return null;
		}
	}

	private String getCountryDescription(String countryCode, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {
		try {
			String query = "SELECT CD_DESC " + "FROM NG_MASTER_DAO_COUNTRY_OF_RESIDENCE " + "WITH(NOLOCK) "
					+ "WHERE CM_CODE='" + countryCode + "'";

			String inputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionId);
			String outputXML = SignUpdate_WI.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
			XMLParser parser = new XMLParser(outputXML);
			if ("0".equals(parser.getValueOf("MainCode"))) {
				String record = parser.getNextValueOf("Record");

				if (record != null) {
					XMLParser rec = new XMLParser(record);

					return rec.getValueOf("CD_DESC");
				}
			}
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Country Description Error", e);
		}

		return "";
	}

	private boolean generateFircoPdf(String wiName, Map<String, String> fircoPdfData) {

		try {

			SignUpdateLogger.SignUpdateLogger.info("Firco PDF Generation Started");
			Properties properties = new Properties();
			properties.load(new FileInputStream(System.getProperty("user.dir") + File.separator + "CustomConfig"
					+ File.separator + "RakBankConfig.properties"));
			String path = System.getProperty("user.dir");
			String generatedPdfPath = path + properties.getProperty("DAO_GENERTATED_PDF_PATH") + File.separator + wiName
					+ "Firco.pdf";
			SignUpdateLogger.SignUpdateLogger.info("Generated PDF Path : " + generatedPdfPath);
			Document document = new Document(PageSize.A4.rotate());
			PdfWriter.getInstance(document, new FileOutputStream(generatedPdfPath));
			document.open();

			Paragraph heading = new Paragraph("CUSTOMER DETAILS");
			document.add(heading);

			document.add(new Paragraph(" "));
			PdfPTable customerTable = new PdfPTable(2);

			customerTable.addCell("Customer Name");
			customerTable.addCell(fircoPdfData.get("CUSTOMER_NAME"));
			customerTable.addCell("CIF");
			customerTable.addCell(fircoPdfData.get("CIF"));
			customerTable.addCell("DOB");
			customerTable.addCell(fircoPdfData.get("DOB"));
			customerTable.addCell("Email");
			customerTable.addCell(fircoPdfData.get("EMAIL_ID"));
			customerTable.addCell("Mobile");
			customerTable.addCell(fircoPdfData.get("MOBILE_NO"));
			customerTable.addCell("Passport No");
			customerTable.addCell(fircoPdfData.get("PASSPORT_NO"));
			customerTable.addCell("Nationality");
			customerTable.addCell(fircoPdfData.get("NATIONALITY"));
			customerTable.addCell("Country Of Residence");
			customerTable.addCell(fircoPdfData.get("COUNTRY_OF_RESIDENCE"));
			customerTable.addCell("Passport Country");
			customerTable.addCell(fircoPdfData.get("PASSPORT_COUNTRY"));
			customerTable.addCell("Gender");
			customerTable.addCell(fircoPdfData.get("GENDER"));

			document.add(customerTable);
			/*
			 * TODO Add Current Date Time
			 */

			/*
			 * TODO Add Bank Logo
			 */

			/*
			 * TODO Add UID_Details_Grid Table
			 *
			 * OFAC_ID ,Matching_Text, Name, Origin ,Designation ,Date_of_Birth,
			 * User_Data_1, Nationality ,Passport ,Additional_Info, Remarks
			 */

			document.close();

			File generatedFile = new File(generatedPdfPath);
			if (!generatedFile.exists()) {
				SignUpdateLogger.SignUpdateLogger.error("Firco PDF Not Generated");
				return false;
			}

			SignUpdateLogger.SignUpdateLogger.info("Firco PDF Generated Successfully");
			/*
			 * TODO Attach Generated FIRCO PDF
			 */

			return true;

		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Firco PDF Generation Error", e);
			return false;
		}
	}

	// ============================
	// KYC Generation Method
	// ============================
	private XMLParser getKycCustomerData(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {
		try {
			String query = "SELECT " + "CIF," + "Given_Name," + "Middle_Name," + "Surname," + "email_id_1,"
					+ "mobile_no_1," + "Country_of_birth," + "Nationality," + "Secondary_Nationality,"
					+ "Employer_name_as_per_visa," + "DOB," + "risk_score," + "PEP," + "Company_employer_name,"
					+ "current_visa_designation," + "gross_monthly_salary_income," + "employer_code,"
					+ "Purpose_of_account," + "Monthly_expected_turnover_Cash," + "Monthly_expected_turnover_non_cash,"
					+ "employement_type " + "FROM NG_DAO_EXTTABLE WITH(NOLOCK) " + "WHERE WI_name='" + wiName + "'";

			SignUpdateLogger.SignUpdateLogger.info("KYC Query : " + query);
			String inputXML = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionId);
			String outputXML = SignUpdate_WI.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
			XMLParser parser = new XMLParser(outputXML);

			if (!"0".equals(parser.getValueOf("MainCode"))) {
				return null;
			}

			String record = parser.getNextValueOf("Record");

			if (record == null || record.trim().isEmpty()) {
				return null;
			}

			return new XMLParser(record);
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("KYC Data Fetch Error", e);

			return null;
		}
	}

	private boolean generateKycPdf(String wiName, Map<String, String> kycPdfData) {

		try {

			SignUpdateLogger.SignUpdateLogger.info("KYC PDF Generation Started");

			Properties properties = new Properties();
			properties.load(new FileInputStream(System.getProperty("user.dir") + File.separator + "CustomConfig"
					+ File.separator + "RakBankConfig.properties"));

			String path = System.getProperty("user.dir");
			String generatedPdfPath = path + properties.getProperty("DAO_GENERTATED_PDF_PATH") + File.separator + wiName
					+ "KYC.pdf";

			SignUpdateLogger.SignUpdateLogger.info("Generated PDF Path : " + generatedPdfPath);

			Document document = new Document(PageSize.A4.rotate());
			PdfWriter.getInstance(document, new FileOutputStream(generatedPdfPath));

			document.open();
			Paragraph heading = new Paragraph("DIGITAL KYC");
			document.add(heading);

			/*
			 * TODO Add WI Name
			 */

			/*
			 * TODO Add Current Date Time
			 */

			/*
			 * TODO Add Bank Logo
			 */

			document.add(new Paragraph(" "));
			Paragraph personalHeading = new Paragraph("PERSONAL INFORMATION");

			document.add(personalHeading);
			document.add(new Paragraph(" "));

			PdfPTable personalInfoTable = new PdfPTable(2);

			personalInfoTable.addCell("Customer Name");
			personalInfoTable.addCell(kycPdfData.get("CUSTOMER_NAME"));
			personalInfoTable.addCell("Email");
			personalInfoTable.addCell(kycPdfData.get("EMAIL_ID"));
			personalInfoTable.addCell("Mobile");
			personalInfoTable.addCell(kycPdfData.get("MOBILE_NO"));
			personalInfoTable.addCell("DOB");
			personalInfoTable.addCell(kycPdfData.get("DOB"));
			personalInfoTable.addCell("Nationality");
			personalInfoTable.addCell(kycPdfData.get("NATIONALITY"));
			personalInfoTable.addCell("Secondary Nationality");
			personalInfoTable.addCell(kycPdfData.get("SECONDARY_NATIONALITY"));
			personalInfoTable.addCell("Risk Score");
			personalInfoTable.addCell(kycPdfData.get("RISK_SCORE"));
			personalInfoTable.addCell("PEP");
			personalInfoTable.addCell(kycPdfData.get("PEP"));

			document.add(personalInfoTable);

			document.add(new Paragraph(" "));

			/*
			 * TODO ADDRESS DETAILS GRID
			 *
			 * Grid : address_detail
			 *
			 * Columns: Flat/Villa Number Building/Villa Name Street/Location Nearest
			 * Landmark P.O Box Emirates/City Country Address Type
			 */

			document.add(new Paragraph(" "));

			Paragraph employmentHeading = new Paragraph("EMPLOYMENT INFORMATION");

			document.add(employmentHeading);

			document.add(new Paragraph(" "));

			PdfPTable employmentTable = new PdfPTable(2);

			employmentTable.addCell("Employment Type");
			employmentTable.addCell(kycPdfData.get("EMPLOYMENT_TYPE"));
			employmentTable.addCell("Employer Name");
			employmentTable.addCell(kycPdfData.get("EMPLOYER_NAME"));
			employmentTable.addCell("Current Designation");
			employmentTable.addCell(kycPdfData.get("CURRENT_DESIGNATION"));
			employmentTable.addCell("Monthly Income");
			employmentTable.addCell(kycPdfData.get("MONTHLY_INCOME"));
			employmentTable.addCell("Employer Code");
			employmentTable.addCell(kycPdfData.get("EMPLOYER_CODE"));

			document.add(employmentTable);

			document.add(new Paragraph(" "));

			/*
			 * TODO COMPANY DETAILS GRID
			 *
			 * Grid : company_detail
			 *
			 * Columns: Company Name Percentage Shareholding Country Of Incorporation Annual
			 * Turnover Annual Profit Designation Countries With Business Industry
			 */

			document.add(new Paragraph(" "));

			Paragraph purposeHeading = new Paragraph("PURPOSE OF ACCOUNT");

			document.add(purposeHeading);

			document.add(new Paragraph(" "));

			PdfPTable purposeTable = new PdfPTable(2);

			purposeTable.addCell("Purpose Of Account");
			purposeTable.addCell(kycPdfData.get("PURPOSE_OF_ACCOUNT"));
			document.add(purposeTable);

			document.add(new Paragraph(" "));
			Paragraph txnHeading = new Paragraph("TRANSACTION PARAMETERS");

			document.add(txnHeading);

			document.add(new Paragraph(" "));

			PdfPTable txnTable = new PdfPTable(2);

			txnTable.addCell("Monthly Expected Turnover Cash");
			txnTable.addCell(kycPdfData.get("TURNOVER_CASH"));
			txnTable.addCell("Monthly Expected Turnover Non Cash");
			txnTable.addCell(kycPdfData.get("TURNOVER_NON_CASH"));

			document.add(txnTable);

			document.add(new Paragraph(" "));

			/*
			 * TODO SOURCE OF WEALTH
			 *
			 * Fields: SOW_Inheritance_ibps SOW_Investments_ibps SOW_Insurance_ibps
			 * SOW_RealEstate_ibps SOW_OtherImmovable_Asset_ibps
			 * SOW_GovernmentEmployment_ibps SOW_Other_Income_ibps
			 * SOW_Other_Income_Value_ibps SOW_Total_Income_ibps
			 */

			document.add(new Paragraph(" "));

			/*
			 * TODO BACKGROUND INFORMATION
			 *
			 * Fields: Crypto_NFTS rental_income Inheritance_income Investments
			 * other_business_income other_Source_of_income other_sources_of_income_value
			 * Money_send_and_received_Countries_final_IBPS
			 */

			document.add(new Paragraph(" "));

			/*
			 * TODO BACKGROUND INFORMATION GRID
			 *
			 * Grid : background_information
			 *
			 * Columns: Employer Name Position Held Country Date Of Employment
			 */

			document.close();

			File generatedFile = new File(generatedPdfPath);

			if (!generatedFile.exists()) {

				SignUpdateLogger.SignUpdateLogger.error("KYC PDF Not Generated");

				return false;
			}

			SignUpdateLogger.SignUpdateLogger.info("KYC PDF Generated Successfully");

			/*
			 * TODO Attach Generated KYC PDF
			 */

			return true;

		} catch (Exception e) {

			SignUpdateLogger.SignUpdateLogger.error("KYC PDF Generation Error", e);

			return false;
		}
	}
}