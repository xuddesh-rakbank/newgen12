package com.newgen.DAO.SignUpdate;

import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.*;

import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;

import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

import ISPack.CImageServer;
import ISPack.ISUtil.JPISException;
import Jdts.DataObject.JPDBString;

//import org.apache.commons.codec.binary.Base64;
//
//import ISPack.CImageServer;
//import ISPack.ISUtil.JPISException;
//import Jdts.DataObject.JPDBString;

public class SignUpdate_WI implements Runnable {

	private static NGEjbClient ngEjbClientCIFVer;
	static Map<String, String> DAOExtensionConfigParamMap = new HashMap<>();

	public String jtsIP = "";
	public String jtsPort = "";
	public String sessionID = "";

	@Override
	public void run() {

		try {

			SignUpdateLogger.setLogger();
			SignUpdateLogger.SignUpdateLogger.info("DAO_Sign_Update Utility Started");
			ngEjbClientCIFVer = NGEjbClient.getSharedInstance();

			int configReadStatus = readConfig();
			if (configReadStatus != 0)
				return;

			String cabinetName = CommonConnection.getCabinetName();
			jtsIP = CommonConnection.getJTSIP();
			jtsPort = CommonConnection.getJTSPort();

			String queueIDDAO = DAOExtensionConfigParamMap.get("queueIDDAO");
			int sleepIntervalInMin = Integer.parseInt(DAOExtensionConfigParamMap.get("SleepIntervalInMin"));

			sessionID = CommonConnection.getSessionID(SignUpdateLogger.SignUpdateLogger, false);

			while (true) {

				startDAO_SignUpload_Utility(cabinetName, jtsIP, jtsPort, sessionID, queueIDDAO);

				Thread.sleep(sleepIntervalInMin * 60 * 1000);
			}

		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Exception in run: " + e.getMessage());
		}
	}

	private int readConfig() {
		try {
			Properties p = new Properties();
			p.load(new FileInputStream(System.getProperty("user.dir") + File.separator + "ConfigFiles" + File.separator
					+ "DAO_Sign_Update.properties"));
			SignUpdateLogger.SignUpdateLogger.info("DAO_Sign_Update properties loaded successfully");

			Enumeration<?> names = p.propertyNames();
			while (names.hasMoreElements()) {
				String name = (String) names.nextElement();
				DAOExtensionConfigParamMap.put(name, p.getProperty(name));
			}

		} catch (Exception e) {

			SignUpdateLogger.SignUpdateLogger.error("Error loading properties", e);

			return -1;
		}
		return 0;
	}

	private void startDAO_SignUpload_Utility(String cabinetName, String jtsIp, String jtsPort, String sessionId,
			String queueID) {

		try {

			String fetchXML = CommonMethods.fetchWorkItemsInput(cabinetName, sessionId, queueID);
			String outputXML = WFNGExecute(fetchXML, jtsIp, jtsPort, 1);

			XMLParser parser = new XMLParser(outputXML);

			if (!"0".equals(parser.getValueOf("MainCode")))
				return;

			int count = Integer.parseInt(parser.getValueOf("RetrievedCount"));

			for (int i = 0; i < count; i++) {

				String data = parser.getNextValueOf("Instrument");
				XMLParser wiParser = new XMLParser(data);

				String processInstanceID = wiParser.getValueOf("ProcessInstanceId");
				String workItemID = wiParser.getValueOf("WorkItemId");
				String activityID = wiParser.getValueOf("WorkStageId");
				String processDefID = wiParser.getValueOf("RouteId");

				SignUpdateLogger.SignUpdateLogger.info("Processing WI: " + processInstanceID);
				
				// Report Generation Call Code
				DAOReportGenerator reportGenerator = new DAOReportGenerator();

				reportGenerator.generateReportsForWI(processInstanceID, cabinetName, sessionId, jtsIp, jtsPort);
				
				// Report Generation Call End
				
				// SIGN UPLOAD CORE CALL
				String integrationStatus = executeSignUploadForWI(processInstanceID, cabinetName, sessionId, jtsIp,
						jtsPort);
				SignUpdateLogger.SignUpdateLogger.info("Integration Status = " + integrationStatus);
				String decision = "Failed";
				String remarks = "Sign Upload Failed";

				if ("Success".equalsIgnoreCase(integrationStatus)) {
					decision = "Success";
					remarks = "Sign Upload Successful";
				}
				SignUpdateLogger.SignUpdateLogger.info("Decision Selected = " + decision);

				String attributesTag = "<Decision>" + decision + "</Decision>";

				// MOVE WI
				SignUpdateLogger.SignUpdateLogger.info("Moving WI : " + processInstanceID + " Decision : " + decision);
				String getWI = CommonMethods.getWorkItemInput(cabinetName, sessionId, processInstanceID, workItemID);
				String getWIResp = WFNGExecute(getWI, jtsIp, jtsPort, 1);

				XMLParser getParser = new XMLParser(getWIResp);

				if ("0".equals(getParser.getValueOf("MainCode"))) {

					String assignXML = "<?xml version=\"1.0\"?>" + "<WMAssignWorkItemAttributes_Input>"
							+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>" + cabinetName
							+ "</EngineName>" + "<SessionId>" + sessionId + "</SessionId>" + "<ProcessInstanceId>"
							+ processInstanceID + "</ProcessInstanceId>" + "<WorkItemId>" + workItemID + "</WorkItemId>"
							+ "<ActivityId>" + activityID + "</ActivityId>" + "<ProcessDefId>" + processDefID
							+ "</ProcessDefId>" + "<ActivityType>1</ActivityType>" + "<complete>D</complete>"
							+ "<UserDefVarFlag>Y</UserDefVarFlag>" + "<Attributes>" + attributesTag + "</Attributes>"
							+ "</WMAssignWorkItemAttributes_Input>";

					String assignResponse = WFNGExecute(assignXML, jtsIp, jtsPort, 1);

					XMLParser assignParser = new XMLParser(assignResponse);

					if ("0".equals(assignParser.getValueOf("MainCode"))) {
						insertDecisionHistory(cabinetName, sessionId, jtsIp, jtsPort, processInstanceID, decision,
								remarks);
					}

				}
			}

		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Error in startDAO: " + e.getMessage());
		}
	}

	private void insertDecisionHistory(String cabinetName, String sessionId, String jtsIp, String jtsPort,
			String wiName, String decision, String remarks) {
		try {
			String currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

			String columnNames = "wi_name,decision_date_time,workstep,user_name," + "Decision,Remarks";

			String columnValues = "'" + wiName + "'," + "'" + currentTime + "'," + "'Sign_Update'," + "'"
					+ CommonConnection.getUsername() + "'," + "'" + decision + "'," + "'" + remarks + "'";

			String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionId, columnNames, columnValues,
					"NG_DAO_GR_DECISION_HISTORY");

			String apInsertOutputXML = WFNGExecute(apInsertInputXML, jtsIp, jtsPort, 1);

			SignUpdateLogger.SignUpdateLogger.info("Decision History Insert Response : " + apInsertOutputXML);
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("Error inserting decision history", e);
		}
	}

	// ======================================================
	// CORE SIGN UPLOAD LOGIC (UPDATED)
	// ======================================================
	private String executeSignUploadForWI(String wiName, String cabinetName, String sessionId, String jtsIP,
			String jtsPort) {

		try {

//              STEP 1: FETCH DOCUMENT INDEX
			String query = "select top 1 imageindex from pdbdocument with (nolock) " + "WHERE DocumentIndex in "
					+ "(select DocumentIndex from PDBDocumentContent with (nolock) " + "where ParentFolderIndex = "
					+ "(select FolderIndex from PDBFolder with (nolock) where Name = '" + wiName + "')) "
					+ "and name like 'Signature%' " + "order by DocumentIndex desc";
			String input = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionId);
			String output = WFNGExecute(input, jtsIP, jtsPort, 1);

			XMLParser parser = new XMLParser(output);

			if (!"0".equals(parser.getValueOf("MainCode")))
				return "Failed";

			String record = parser.getNextValueOf("Record");
			if (record == null || record.trim().isEmpty()) {
				SignUpdateLogger.SignUpdateLogger.info("Signature document not found for WI : " + wiName);

				return "Failed";
			}
			XMLParser recParser = new XMLParser(record);

			String imageIndex = recParser.getValueOf("imageindex");
			String volumeId = DAOExtensionConfigParamMap.get("VolumeId");
			String siteId = DAOExtensionConfigParamMap.get("SiteId");

			SignUpdateLogger.SignUpdateLogger
					.info("location for downloading file:" + DAOExtensionConfigParamMap.get("fileDownloadLoc"));
			// DOWNLOAD FILE
			SignUpdateLogger.SignUpdateLogger.info("Downloading Signature : WI=" + wiName + ", ImageIndex=" + imageIndex
					+ ", VolumeId=" + volumeId + ", SiteId=" + siteId);
			// String base64 = DownloadDocument(imageIndex, wiName, "Signature", "", "", "",
			// cabinetName, sessionId, jtsIP,
			// jtsPort, volumeId, siteId);
			String base64 = SignatureCompressor.DownloadCompressDocument(imageIndex, wiName, "Signature", cabinetName,
					jtsIP, jtsPort, volumeId, siteId, DAOExtensionConfigParamMap.get("fileDownloadLoc"));

			if (base64 == null || base64.trim().isEmpty() || "F".equalsIgnoreCase(base64)) {
				return "Failed";
			}

			String dataQuery = "select account_no as accountNo, CIF, Given_Name, Middle_Name, Surname from NG_DAO_EXTTABLE with(nolock) where WI_name='"
					+ wiName + "'";

			SignUpdateLogger.SignUpdateLogger.info("Customer Data Query : " + dataQuery);

			String dataInput = CommonMethods.apSelectWithColumnNames(dataQuery, cabinetName, sessionId);

			String dataOutput = WFNGExecute(dataInput, jtsIP, jtsPort, 1);

			SignUpdateLogger.SignUpdateLogger.info("Customer Data Response : " + dataOutput);

			if (dataOutput == null || dataOutput.trim().isEmpty()) {
				SignUpdateLogger.SignUpdateLogger
						.error("Empty response received while fetching customer details for WI : " + wiName);
				return "Failed";
			}

			XMLParser dataParser = new XMLParser(dataOutput);

			String mainCode = dataParser.getValueOf("MainCode");

			if (!"0".equals(mainCode)) {
				SignUpdateLogger.SignUpdateLogger.error("Customer Data Query Failed. MainCode = " + mainCode);
				return "Failed";
			}

			String rec = dataParser.getNextValueOf("Record");

			if (rec == null || rec.trim().isEmpty()) {
				SignUpdateLogger.SignUpdateLogger.error("No record found in NG_DAO_EXTTABLE for WI : " + wiName);
				return "Failed";
			}

			SignUpdateLogger.SignUpdateLogger.info("Customer Record Retrieved : " + rec);

			XMLParser p = new XMLParser(rec);

			String accountNo = p.getValueOf("accountNo");
			String cif = p.getValueOf("CIF");

			if (accountNo == null || accountNo.trim().isEmpty()) {
				SignUpdateLogger.SignUpdateLogger.error("Account Number missing for WI : " + wiName);
				return "Failed";
			}

			if (cif == null || cif.trim().isEmpty()) {
				SignUpdateLogger.SignUpdateLogger.error("CIF missing for WI : " + wiName);
				return "Failed";
			}

			if (base64 == null || base64.trim().isEmpty()) {
				SignUpdateLogger.SignUpdateLogger.error("Signature Base64 not available for WI : " + wiName);
				return "Failed";
			}

			SignUpdateLogger.SignUpdateLogger.info("Customer Details Found. AccountNo=" + accountNo + ", CIF=" + cif
					+ ", Base64Length=" + base64.length());

			String first = p.getValueOf("Given_Name");
			String middle = p.getValueOf("Middle_Name");
			String last = p.getValueOf("Surname");

			String custName = (middle == null || middle.isEmpty()) ? first + " " + last
					: first + " " + middle + " " + last;

			String xml = getSignatureUploadXML(base64, accountNo, cif, "", custName, "");

			StringBuilder payload = new StringBuilder(xml);

			HashMap<String, String> socketDetails = socketConnectionDetails(cabinetName, jtsIP, jtsPort, sessionId);

			String response = socketConnection(cabinetName, CommonConnection.getUsername(), sessionId, jtsIP, jtsPort,
					wiName, "Sign_Update", 60, 65, socketDetails, payload);

			SignUpdateLogger.SignUpdateLogger.info("MQ Response Received : " + response);

			if (response != null && response.contains("<ReturnCode>0000</ReturnCode>")) {

				SignUpdateLogger.SignUpdateLogger.info("Signature Upload Successful for WI : " + wiName);

				return "Success";
			}

		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.error("SignUpload Error: " + e.getMessage());
		}

		return "Failed";
	}

	private HashMap<String, String> socketConnectionDetails(String cabinetName, String sJtsIp, String iJtsPort,
			String sessionID) {
		HashMap<String, String> socketDetailsMap = new HashMap<String, String>();

		try {
			SignUpdateLogger.SignUpdateLogger.debug("Fetching Socket Connection Details.");
			System.out.println("Fetching Socket Connection Details.");

			String socketDetailsQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName = 'DigitalAO' and CallingSource = 'Utility'";

			String socketDetailsInputXML = CommonMethods.apSelectWithColumnNames(socketDetailsQuery, cabinetName,
					sessionID);
			SignUpdateLogger.SignUpdateLogger.debug("Socket Details APSelect InputXML: " + socketDetailsInputXML);

			String socketDetailsOutputXML = WFNGExecute(socketDetailsInputXML, sJtsIp, iJtsPort, 1);
			SignUpdateLogger.SignUpdateLogger.debug("Socket Details APSelect OutputXML: " + socketDetailsOutputXML);

			XMLParser xmlParserSocketDetails = new XMLParser(socketDetailsOutputXML);
			String socketDetailsMainCode = xmlParserSocketDetails.getValueOf("MainCode");
			SignUpdateLogger.SignUpdateLogger.debug("SocketDetailsMainCode: " + socketDetailsMainCode);

			int socketDetailsTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
			SignUpdateLogger.SignUpdateLogger.debug("SocketDetailsTotalRecords: " + socketDetailsTotalRecords);

			if (socketDetailsMainCode.equalsIgnoreCase("0") && socketDetailsTotalRecords > 0) {
				String xmlDataSocketDetails = xmlParserSocketDetails.getNextValueOf("Record");
				xmlDataSocketDetails = xmlDataSocketDetails.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

				XMLParser xmlParserSocketDetailsRecord = new XMLParser(xmlDataSocketDetails);

				String socketServerIP = xmlParserSocketDetailsRecord.getValueOf("SocketServerIP");
				SignUpdateLogger.SignUpdateLogger.debug("SocketServerIP: " + socketServerIP);
				socketDetailsMap.put("SocketServerIP", socketServerIP);

				String socketServerPort = xmlParserSocketDetailsRecord.getValueOf("SocketServerPort");
				SignUpdateLogger.SignUpdateLogger.debug("SocketServerPort " + socketServerPort);
				socketDetailsMap.put("SocketServerPort", socketServerPort);

				SignUpdateLogger.SignUpdateLogger.debug("SocketServer Details found.");
				System.out.println("SocketServer Details found.");

			}
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger
					.debug("Exception in getting Socket Connection Details: " + e.getMessage());
			System.out.println("Exception in getting Socket Connection Details: " + e.getMessage());
		}

		return socketDetailsMap;
	}

	protected static String WFNGExecute(String ipXML, String jtsServerIP, String serverPort, int flag)
			throws IOException, Exception {
		SignUpdateLogger.SignUpdateLogger.debug("In WF NG Execute : " + serverPort);
		try {
			if (serverPort.startsWith("33"))
				return WFCallBroker.execute(ipXML, jtsServerIP, Integer.parseInt(serverPort), 1);
			else
				return ngEjbClientCIFVer.makeCall(jtsServerIP, serverPort, "WebSphere", ipXML);
		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.debug("Exception Occured in WF NG Execute : " + e.getMessage());
			e.printStackTrace();
			return "Error";
		}
	}

	String socketConnection(String cabinetName, String username, String sessionId, String sJtsIp, String iJtsPort,
			String processInstanceID, String ws_name, int connection_timeout, int integrationWaitTime,
			HashMap<String, String> socketDetailsMap, StringBuilder sInputXML) {

		String socketServerIP;
		int socketServerPort;
		Socket socket = null;
		OutputStream out = null;
		InputStream socketInputStream = null;
		DataOutputStream dout = null;
		DataInputStream din = null;
		String outputResponse = null;
		String inputRequest = null;
		String inputMessageID = null;

		try {

			SignUpdateLogger.SignUpdateLogger.debug("userName " + username);
			SignUpdateLogger.SignUpdateLogger.debug("SessionId " + sessionID);

			socketServerIP = socketDetailsMap.get("SocketServerIP");
			SignUpdateLogger.SignUpdateLogger.debug("SocketServerIP " + socketServerIP);
			socketServerPort = Integer.parseInt(socketDetailsMap.get("SocketServerPort"));
			SignUpdateLogger.SignUpdateLogger.debug("SocketServerPort " + socketServerPort);

			if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort == 0)) {

				socket = new Socket(socketServerIP, socketServerPort);
				socket.setSoTimeout(connection_timeout * 1000);
				out = socket.getOutputStream();
				socketInputStream = socket.getInputStream();
				dout = new DataOutputStream(out);
				din = new DataInputStream(socketInputStream);
				SignUpdateLogger.SignUpdateLogger.debug("Dout " + dout);
				SignUpdateLogger.SignUpdateLogger.debug("Din " + din);

				outputResponse = "";

				String History_tablename = "";
				if ("DCC".equalsIgnoreCase(processInstanceID.substring(0, 3))) {
					History_tablename = "NG_DCC_XMLLOG_HISTORY";
				} else {
					History_tablename = "NG_DAO_XMLLOG_HISTORY";
				}

				inputRequest = getRequestXML(cabinetName, sessionID, processInstanceID, ws_name, username, sInputXML,
						History_tablename);

				if (inputRequest != null && inputRequest.length() > 0) {
					int inputRequestLen = inputRequest.getBytes("UTF-16LE").length;
					SignUpdateLogger.SignUpdateLogger.debug("RequestLen: " + inputRequestLen + "");
					inputRequest = inputRequestLen + "##8##;" + inputRequest;
					SignUpdateLogger.SignUpdateLogger
							.debug("InputRequest" + "Input Request Bytes : " + inputRequest.getBytes("UTF-16LE"));
					dout.write(inputRequest.getBytes("UTF-16LE"));
					dout.flush();
				}
				byte[] readBuffer = new byte[500];
				int num = din.read(readBuffer);
				if (num > 0) {

					byte[] arrayBytes = new byte[num];
					System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
					outputResponse = outputResponse + new String(arrayBytes, "UTF-16LE");
					inputMessageID = outputResponse;
					SignUpdateLogger.SignUpdateLogger.debug("OutputResponse: " + outputResponse);

					if (!"".equalsIgnoreCase(outputResponse))
						outputResponse = getResponseXML(cabinetName, sJtsIp, iJtsPort, sessionID, processInstanceID,
								outputResponse, integrationWaitTime);

					if (outputResponse.contains("&lt;")) {
						outputResponse = outputResponse.replaceAll("&lt;", "<");
						outputResponse = outputResponse.replaceAll("&gt;", ">");
					}
				}
				socket.close();

				outputResponse = outputResponse.replaceAll("</MessageId>",
						"</MessageId>/n<InputMessageId>" + inputMessageID + "</InputMessageId>");

				// SignUpdateLogger.SignUpdateLogger.debug("outputResponse "+outputResponse);
				return outputResponse;

			}

			else {
				SignUpdateLogger.SignUpdateLogger.debug("SocketServerIp and SocketServerPort is not maintained " + "");
				SignUpdateLogger.SignUpdateLogger.debug("SocketServerIp is not maintained " + socketServerIP);
				SignUpdateLogger.SignUpdateLogger.debug(" SocketServerPort is not maintained " + socketServerPort);
				return "Socket Details not maintained";
			}

		}

		catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.debug("Exception Occured Mq_connection_CC" + e.getStackTrace());
			return "";
		} finally {
			try {
				if (out != null) {
					out.close();
					out = null;
				}
				if (socketInputStream != null) {

					socketInputStream.close();
					socketInputStream = null;
				}
				if (dout != null) {

					dout.close();
					dout = null;
				}
				if (din != null) {

					din.close();
					din = null;
				}
				if (socket != null) {
					if (!socket.isClosed())
						socket.close();
					socket = null;
				}

			}

			catch (Exception e) {
				SignUpdateLogger.SignUpdateLogger.debug("Final Exception Occured Mq_connection_CC" + e.getStackTrace());
				// printException(e);
			}
		}

	}

	public String getSignatureUploadXML(String base64String, String ACCNO, String CIFID, String DATE,
			String CustomerName, String Sig_Remarks) {
		java.util.Date d1 = new Date();
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm");
		String DateExtra2 = sdf1.format(d1) + "+04:00";
		Sig_Remarks = "To Sign Singly";
		String integrationXML = "<EE_EAI_MESSAGE>" + "<EE_EAI_HEADER>" + "<MsgFormat>SIGNATURE_ADDITION_REQ</MsgFormat>"
				+ "<MsgVersion>0001</MsgVersion>" + "<RequestorChannelId>BPM</RequestorChannelId>"
				+ "<RequestorUserId>RAKUSER</RequestorUserId>" + "<RequestorLanguage>E</RequestorLanguage>"
				+ "<RequestorSecurityInfo>secure</RequestorSecurityInfo>" + "<ReturnCode>911</ReturnCode>"
				+ "<ReturnDesc>Issuer Timed Out</ReturnDesc>" + "<MessageId>UniqueMessageId123</MessageId>"
				+ "<Extra1>REQ||SHELL.JOHN</Extra1>" + "<Extra2>" + DateExtra2 + "</Extra2>" + "</EE_EAI_HEADER>"
				+ "<SignatureAddReq>" + "<BankId>RAK</BankId>" + "<AcctId>" + ACCNO + "</AcctId>"
				+ "<AccType>N</AccType>" + "<CustId>" + CIFID + "</CustId>" + "<BankCode></BankCode>"
				+ "<EmpId></EmpId>" + "<CustomerName>" + CustomerName + "</CustomerName>"
				+ "<SignPowerNumber></SignPowerNumber>" + "<ImageAccessCode>1</ImageAccessCode>"
				+ "<SignExpDate>2112-03-06T23:59:59.000</SignExpDate>"
				+ "<SignEffDate>2010-12-31T23:59:59.000</SignEffDate>" + "<SignFile>" + base64String + "</SignFile>"
				+ "<PictureExpDate>2099-12-31T23:59:59.000</PictureExpDate>"
				+ "<PictureEffDate>2010-12-31T23:59:59.000</PictureEffDate>" + "<PictureFile></PictureFile>"
				+ "<SignGroupId>SVSB11</SignGroupId>" + "<Remarks>" + Sig_Remarks + "</Remarks>" + "</SignatureAddReq>"
				+ "</EE_EAI_MESSAGE>";

		return integrationXML;
	}

	private String getResponseXML(String cabinetName, String sJtsIp, String iJtsPort, String sessionId,
			String processInstanceID, String message_ID, int integrationWaitTime) {

		String outputResponseXML = "";
		try {
			String QueryString = "";
			if ("DCC".equalsIgnoreCase(processInstanceID.substring(0, 3))) {
				QueryString = "select OUTPUT_XML from NG_DCC_XMLLOG_HISTORY with (nolock) where MESSAGE_ID ='"
						+ message_ID + "' and WI_NAME = '" + processInstanceID + "'";
			}

			else
				QueryString = "select OUTPUT_XML from NG_DAO_XMLLOG_HISTORY with (nolock) where MESSAGE_ID ='"
						+ message_ID + "' and WI_NAME = '" + processInstanceID + "'";

			String responseInputXML = CommonMethods.apSelectWithColumnNames(QueryString, cabinetName, sessionID);
			SignUpdateLogger.SignUpdateLogger.debug("Response APSelect InputXML: " + responseInputXML);

			int Loop_count = 0;
			do {
				String responseOutputXML = CommonMethods.WFNGExecute(responseInputXML, sJtsIp, iJtsPort, 1);
				SignUpdateLogger.SignUpdateLogger.debug("Response APSelect OutputXML: " + responseOutputXML);

				XMLParser xmlParserSocketDetails = new XMLParser(responseOutputXML);
				String responseMainCode = xmlParserSocketDetails.getValueOf("MainCode");
				SignUpdateLogger.SignUpdateLogger.debug("ResponseMainCode: " + responseMainCode);

				int responseTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
				SignUpdateLogger.SignUpdateLogger.debug("ResponseTotalRecords: " + responseTotalRecords);

				if (responseMainCode.equals("0") && responseTotalRecords > 0) {

					String responseXMLData = xmlParserSocketDetails.getNextValueOf("Record");
					responseXMLData = responseXMLData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

					XMLParser xmlParserResponseXMLData = new XMLParser(responseXMLData);
					// SignUpdateLogger.SignUpdateLogger.debug("ResponseXMLData: "+responseXMLData);

					outputResponseXML = xmlParserResponseXMLData.getValueOf("OUTPUT_XML");
					// SignUpdateLogger.SignUpdateLogger.debug("OutputResponseXML:
					// "+outputResponseXML);

					if ("".equalsIgnoreCase(outputResponseXML)) {
						outputResponseXML = "Error";
					}
					break;
				}
				Loop_count++;
				Thread.sleep(1000);
			} while (Loop_count < integrationWaitTime);
			SignUpdateLogger.SignUpdateLogger.debug("integrationWaitTime: " + integrationWaitTime);

		} catch (Exception e) {
			SignUpdateLogger.SignUpdateLogger.debug("Exception occurred in outputResponseXML" + e.getMessage());
			outputResponseXML = "Error";
		}

		return outputResponseXML;

	}

	private String getRequestXML(String cabinetName, String sessionId, String processInstanceID, String ws_name,
			String userName, StringBuilder sInputXML, String tablename) {
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>" + tablename + "</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + processInstanceID + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(sInputXML);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		SignUpdateLogger.SignUpdateLogger.debug("GetRequestXML: " + strBuff.toString());
		return strBuff.toString();
	}

	// **************************sign upload method end here *******************

}
