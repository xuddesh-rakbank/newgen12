package com.newgen.IRBL;

import com.newgen.custom.CreateWorkitem;

public class IRBL_WICreateService extends CreateWorkitem {
	
}
