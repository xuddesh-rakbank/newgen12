package com.newgen.DPL.OCR;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.RandomAccessFileOrArray;
import com.itextpdf.text.pdf.codec.TiffImage;
import com.newgen.DAO.AWB.DAO_AWB_Log;
import com.newgen.DAO.Notify.DAONotifyAPPLog;
import com.newgen.DPL.Digital_PL_CommomMethod;
import com.newgen.DPL.Digital_PL_Log;
import com.newgen.DPL.lms.GenerateXML;
import com.newgen.DPL.lms.User;
import com.newgen.common.CommonConnection;

import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;

import ISPack.CImageServer;
import ISPack.ISUtil.JPISException;
import Jdts.DataObject.JPDBString;
import adminclient.OSASecurity;

public class DPL_STL_OCR implements Runnable{

	private static NGEjbClient ngEjbClient;
	private static org.apache.log4j.Logger logger;

	static Map<String, String> ConfigParamMap= new HashMap<String, String>();


	int socketConnectionTimeout=0;
	int integrationWaitTime=0;
	int sleepIntervalInMin=0;
	public static int sessionCheckInt=0;
	public static int waitLoop=50;
	public static int loopCount=50;
	public String fromMailID="";
	public String toMailID = "";
	public String mailSubject = "";
	public String MailStr="";
	public String jtsIP = "";
	public String jtsPort = "";
	public String sessionID = "";
	public String cabinetName = "";
	
	public String OCR_STL_document_download_path = "";
	public String Kong_Endpoint="";
	public String Kong_API_KEY = "";
	public String Kong_API_client_id = "";
	public String Kong_API_client_secret = "";
	public String Kong_API_resource_type = "";
	public String Kong_API_JKS_Password = ""; 
	public String Kong_OCR_STL_Endpoint = "";
	public String OCR_STL_API_Expected_Tags = "";
	
	public DPL_STL_OCR() throws NGException {
		Digital_PL_Log.setLogger(getClass().getSimpleName());
		this.ngEjbClient = NGEjbClient.getSharedInstance();
		logger = Digital_PL_Log.getLogger(getClass().getSimpleName());
	}
	@Override
	public void run()
	{
		//String cabinetName = "";
		String queueID = "";

		try
		{
			

			logger.debug("Connecting to Cabinet.");

			int configReadStatus = readConfig();

			logger.debug("configReadStatus "+configReadStatus);
			if(configReadStatus !=0)
			{
				logger.debug("Could not Read Config Properties ");
				return;
			}

			cabinetName = CommonConnection.getCabinetName();
			logger.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			logger.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			logger.debug("JTSPORT: " + jtsPort);

			queueID = ConfigParamMap.get("queueID");
			logger.debug("QueueID: " + queueID);
			
			OCR_STL_document_download_path=ConfigParamMap.get("OCR_STL_document_download_path");
			logger.debug("OCR_STL_document_download_path: "+OCR_STL_document_download_path);			

			socketConnectionTimeout=Integer.parseInt(ConfigParamMap.get("MQ_SOCKET_CONNECTION_TIMEOUT"));
			logger.debug("SocketConnectionTimeOut: "+socketConnectionTimeout);

			integrationWaitTime=Integer.parseInt(ConfigParamMap.get("INTEGRATION_WAIT_TIME"));
			logger.debug("IntegrationWaitTime: "+integrationWaitTime);

			sleepIntervalInMin=Integer.parseInt(ConfigParamMap.get("SleepIntervalInMin"));
			logger.debug("SleepIntervalInMin: "+sleepIntervalInMin);

			fromMailID=ConfigParamMap.get("fromMailID");
			logger.debug("fromMailID: "+fromMailID);
			
			toMailID=ConfigParamMap.get("toMailID");
			logger.debug("toMailID: "+toMailID);
			
			mailSubject=ConfigParamMap.get("mailSubject");
			logger.debug("mailSubject: "+mailSubject);
			
			MailStr=ConfigParamMap.get("MailStr");
			logger.debug("MailStr: "+MailStr);
			
			Kong_Endpoint=ConfigParamMap.get("Kong_Endpoint");
			logger.debug("Kong_Endpoint: "+Kong_Endpoint);
			
			Kong_API_KEY=ConfigParamMap.get("Kong_API_KEY");
			logger.debug("Kong_API_KEY: "+Kong_API_KEY);
			
			Kong_API_client_id=ConfigParamMap.get("Kong_API_client_id");
			logger.debug("Kong_API_client_id: "+Kong_API_client_id);
			
			Kong_API_client_secret=ConfigParamMap.get("Kong_API_client_secret");
			logger.debug("Kong_API_client_secret: "+Kong_API_client_secret);
			
			Kong_API_resource_type=ConfigParamMap.get("Kong_API_resource_type");
			logger.debug("Kong_API_resource_type: "+Kong_API_resource_type);
			
			
			Kong_API_JKS_Password=ConfigParamMap.get("Kong_API_JKS_Password");
			logger.debug("Kong_API_JKS_Password: "+Kong_API_JKS_Password);
			
			Kong_OCR_STL_Endpoint=ConfigParamMap.get("Kong_OCR_STL_Endpoint");
			logger.debug("Kong_OCR_STL_Endpoint: "+Kong_OCR_STL_Endpoint);
			
			sleepIntervalInMin=Integer.parseInt(ConfigParamMap.get("SleepIntervalInMin"));
			logger.debug("SleepIntervalInMin: "+sleepIntervalInMin);

			
			OCR_STL_document_download_path=ConfigParamMap.get("OCR_STL_document_download_path");
			logger.debug("OCR_STL_document_download_path: "+OCR_STL_document_download_path);
			

			OCR_STL_API_Expected_Tags=ConfigParamMap.get("OCR_STL_API_Expected_Tags");
			logger.debug("OCR_STL_API_Expected_Tags: "+OCR_STL_API_Expected_Tags);
				
			sessionID = CommonConnection.getSessionID(logger, false);

			if(sessionID.trim().equalsIgnoreCase(""))
			{
				logger.debug("Could Not Connect to Server!");
			}
			else
			{
				logger.debug("Session ID found: " + sessionID);
				HashMap<String, String> socketDetailsMap = socketConnectionDetails(cabinetName, jtsIP, jtsPort, sessionID);
				while (true) {
					//Digital_PL_Log.setLogger(getClass().getSimpleName());
					
					logger.debug("Inside while loop ");
					
					startDPLOCR_Utility(cabinetName, jtsIP, jtsPort, sessionID, queueID, socketConnectionTimeout, integrationWaitTime, socketDetailsMap);
					
					Thread.sleep(sleepIntervalInMin * 60 * 1000);
				}
			}
		}

		catch(Exception e)
		{
			e.printStackTrace();
			logger.debug("Exception Occurred in DAONotifyAPP : "+e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			logger.debug("Exception Occurred in DAONotifyAPP : "+result);
		}
	}

	private int readConfig()
	{
		Properties p = null;
		try {

			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir")+ File.separator + "ConfigFiles"+ File.separator+ "DPL_OCR.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements())
			  {
			    String name = (String) names.nextElement();
			    ConfigParamMap.put(name, p.getProperty(name));
			  }
		    }
		catch (Exception e)
		{
			return -1 ;
		}
		return 0;
	}


	private void startDPLOCR_Utility(String cabinetName, String sJtsIp, String iJtsPort, String sessionId, String queueID, 
	int socketConnectionTimeOut, int integrationWaitTime, HashMap<String, String> socketDetailsMap){
		
		final String ws_name="SYS_STL_OCR";
		try{
			
			final HashMap<String, String> CheckGridDataMap = new HashMap<String, String>();
			
			sessionID  = CommonConnection.getSessionID(logger, false);

			if (sessionID == null || sessionID.equalsIgnoreCase("") || sessionID.equalsIgnoreCase("null"))
			{
				logger.debug("Could Not Get Session ID "+sessionID);
				return;
			}
			
			
			
			String fetchWorkitemListInputXML=CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
			logger.debug("InputXML for fetchWorkList Call: "+fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML= WFNGExecute(fetchWorkitemListInputXML,sJtsIp,iJtsPort,1);

			logger.debug("WMFetchWorkList DAONotifyAPP OutputXML: "+fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			logger.debug("FetchWorkItemListMainCode: "+fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			logger.debug("RetrievedCount for WMFetchWorkList Call: "+fetchWorkitemListCount);

			logger.debug("Number of workitems retrieved on DAONotifyAPP: "+fetchWorkitemListCount);

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0){
				
				for(int i=0; i<fetchWorkitemListCount; i++){
					
					String fetchWorkItemlistData=xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData =fetchWorkItemlistData.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

					logger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: "+fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID=xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					logger.debug("Current ProcessInstanceID: "+processInstanceID);

					logger.debug("Processing Workitem: "+processInstanceID);

					String WorkItemID=xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					logger.debug("Current WorkItemID: "+WorkItemID);

					String entryDateTime=xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					logger.debug("Current EntryDateTime: "+entryDateTime);

					String ActivityName=xmlParserfetchWorkItemData.getValueOf("ActivityName");
					logger.debug("ActivityName: "+ActivityName);
					
					String ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
					logger.debug("ActivityID: "+ActivityID);
					String ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
					logger.debug("ActivityType: "+ActivityType);
					String ProcessDefId = xmlParserfetchWorkItemData.getValueOf("RouteId");
					logger.debug("ProcessDefId: "+ProcessDefId);
					
					String decisionValue="Submit";
					String CIF= "";	
					
				    String DBQuery ="select CIF from NG_DPL_EXTTABLE where winame='" + processInstanceID + "'";
				  
				    String extTabDataIPXML =CommonMethods.apSelectWithColumnNames(DBQuery, CommonConnection.getCabinetName(), CommonConnection.getSessionID(logger, false));
				    logger.debug("extTabDataIPXML: " + extTabDataIPXML);
				    String extTabDataOPXML = WFNGExecute(extTabDataIPXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);
				    logger.debug("extTabDataOPXML: " + extTabDataOPXML);				   
				    XMLParser xmlParserData = new XMLParser(extTabDataOPXML);				  
				    int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));				  
				    if (xmlParserData.getValueOf("MainCode").equalsIgnoreCase("0") && iTotalrec > 0)
			        {
				    	String xmlDataExtTab = xmlParserData.getNextValueOf("Record");
			            xmlDataExtTab = xmlDataExtTab.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");			         
			            NGXmlList objWorkList = xmlParserData.createList("Records", "Record");			            
			            for (; objWorkList.hasMoreElements(true); objWorkList.skip(true))
			            {
			            	 CIF= objWorkList.getVal("CIF");			            	
			            }
			        }
				    
				    String return_value=downloadAttachDocuments(processInstanceID);
				    if("Done".equalsIgnoreCase(return_value))
				    {
				    	String authToken = DPL_executeOCR.getAuthToken(logger,Kong_API_JKS_Password,Kong_Endpoint,Kong_API_KEY,Kong_API_client_id,Kong_API_client_secret,Kong_API_resource_type);
						 
						String callOCRAPI=DPL_executeOCR.callOCRAPI(authToken,Kong_API_KEY,Kong_OCR_STL_Endpoint,logger,Kong_API_JKS_Password,OCR_STL_document_download_path,cabinetName,processInstanceID,sessionID,CIF,OCR_STL_API_Expected_Tags);
						
						String attributesTag="<Decision>"+decisionValue+"</Decision>";
						
						String ErrDesc=callOCRAPI;
						
				    	String MsgId="";
				    	
				    	doneWiDPL( processInstanceID, WorkItemID, ActivityID, ProcessDefId , ActivityType, attributesTag, sJtsIp, iJtsPort,  ErrDesc , decisionValue, MsgId, ActivityName, entryDateTime,CheckGridDataMap);
						
				    	
				    }
				    else
				    {
				    	String attributesTag="<Decision>"+decisionValue+"</Decision>";
				    	String ErrDesc="Unable to Download the Document from Workitem";
				    	String MsgId="";
				    	doneWiDPL( processInstanceID, WorkItemID, ActivityID, ProcessDefId , ActivityType, attributesTag, sJtsIp, iJtsPort,  ErrDesc , decisionValue, MsgId, ActivityName, entryDateTime,CheckGridDataMap);
				    }
				    deleteDownloadedDocument(processInstanceID);
				}
			}
		}
		catch (Exception e){
			logger.debug("Exception: "+e.getMessage());
		}
	}
	
	public void deleteDownloadedDocument(String processInstanceID) {
		
		Path output_path = null;
		File folder = new File(OCR_STL_document_download_path); 
		File[] listOfFiles = folder.listFiles();
		try {
			for (File file : listOfFiles) {
				String filename = file.getName();
				String path = file.getAbsolutePath();
				String destPath = OCR_STL_document_download_path + File.separator + filename;
				logger.debug("path: " + path);
				logger.debug("destPath: " + destPath);
				//String expected_fileName=prospect_id+"_"+processInstanceID+".pdf";
				String expected_fileName=processInstanceID+".pdf"; 

				if (filename.equalsIgnoreCase(expected_fileName)) {
					File finalFolder = new File(destPath);
					if (finalFolder.exists()) {
						finalFolder.delete();						
					}					
				}
				
			}
			
		}
		 catch(Exception e){
			 logger.debug("Exception :" + e.getMessage());
			
		 }
		
	}
	
	public  void sendMail(String cabinetName, String sessionId ,String wiName,String jtsIp,String jtsPort,String ErrDesc, String return_code,String ProcessDefId,String MsgId)throws Exception
    {
        XMLParser objXMLParser = new XMLParser();
        String sInputXML="";
        String sOutputXML="";
        String mainCodeforAPInsert=null;
        sessionCheckInt=0;
        while(sessionCheckInt<loopCount)
        {
            try
            {
            	logger.debug("workitem name to send mail---"+wiName);
            	logger.debug("ErrorMsg to send mail---"+ErrDesc);
            	logger.debug("return_code to send mail---"+return_code);
            	
            	String FinalMailStr = MailStr.toString().replace("<WI_NAME>",wiName).replace("<ret_Code>",return_code)
            	.replace("<errormsg>",ErrDesc).replace("<MsgID>",MsgId);
            	logger.debug("finalbody: "+FinalMailStr);

            	String columnName="MAILFROM,MAILTO,MAILSUBJECT,MAILMESSAGE,MAILCONTENTTYPE,MAILPRIORITY,MAILSTATUS,INSERTEDBY,MAILACTIONTYPE,INSERTEDTIME,PROCESSDEFID,PROCESSINSTANCEID,WORKITEMID,ACTIVITYID,NOOFTRIALS";
            	String strValues="'"+fromMailID+"','"+toMailID+"','"+mailSubject+"','"+FinalMailStr+"','text/html;charset=UTF-8','1','N','CUSTOM','TRIGGER','"+CommonMethods.getdateCurrentDateInSQLFormat()+"','"+ProcessDefId+"','"+wiName+"','1','1','0'";
                
				sInputXML = "<?xml version=\"1.0\"?>" +
                        "<APInsert_Input>" +
                        "<Option>APInsert</Option>" +
                        "<TableName>WFMAILQUEUETABLE</TableName>" +
                        "<ColName>" + columnName + "</ColName>" +
                        "<Values>" + strValues + "</Values>" +
                        "<EngineName>" + cabinetName + "</EngineName>" +
                        "<SessionId>" + sessionID + "</SessionId>" +
                        "</APInsert_Input>";
                logger.debug("Mail Insert InputXml::::::::::\n"+sInputXML);
                sOutputXML =WFNGExecute(sInputXML, jtsIp,jtsPort,0);
                logger.debug("Mail Insert OutputXml::::::::::\n"+sOutputXML);
                objXMLParser.setInputXML(sOutputXML);
                mainCodeforAPInsert=objXMLParser.getValueOf("MainCode");
                
            }
			
			catch(Exception e)
            {
                e.printStackTrace();
                logger.debug("Exception in Sending mail", e);
                sessionCheckInt++;
                waiteloopExecute(waitLoop);
                continue;
            }
            if (mainCodeforAPInsert.equalsIgnoreCase("11")) 
            {
                logger.debug("Invalid session in Sending mail");
                sessionCheckInt++;
                //ThreadConnect.sessionId = ThreadConnect.getSessionID(cabinetName, jtsIP, jtsPort, userName,password);
                sessionID=CommonConnection.getSessionID(logger, false);
                continue;
            }
            else
            {
                sessionCheckInt++;
                break;
            }
        }
        if(mainCodeforAPInsert.equalsIgnoreCase("0"))
        {
            logger.debug("mail Insert Successful");
        }
        else
        {
            logger.debug("mail Insert Unsuccessful");
        }
    }
	
	public static void waiteloopExecute(long wtime) {
		try {
			for (int i = 0; i < 10; i++) {
				Thread.yield();
				Thread.sleep(wtime / 10);
			}
		} catch (InterruptedException e) {
		}
	}

	private HashMap<String, String> socketConnectionDetails(String cabinetName, String sJtsIp, String iJtsPort, String sessionID) {
		HashMap<String, String> socketDetailsMap = new HashMap<String, String>();

		try {
			logger.debug("Fetching Socket Connection Details.");

			String socketDetailsQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName = 'DigitalAO' and CallingSource = 'Utility'";

			String socketDetailsInputXML = CommonMethods.apSelectWithColumnNames(socketDetailsQuery, cabinetName, sessionID);
			logger.debug("Socket Details APSelect InputXML: " + socketDetailsInputXML);

			String socketDetailsOutputXML = WFNGExecute(socketDetailsInputXML, sJtsIp, iJtsPort, 1);
			logger.debug("Socket Details APSelect OutputXML: " + socketDetailsOutputXML);

			XMLParser xmlParserSocketDetails = new XMLParser(socketDetailsOutputXML);
			String socketDetailsMainCode = xmlParserSocketDetails.getValueOf("MainCode");
			logger.debug("SocketDetailsMainCode: " + socketDetailsMainCode);

			int socketDetailsTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
			logger.debug("SocketDetailsTotalRecords: " + socketDetailsTotalRecords);

			if (socketDetailsMainCode.equalsIgnoreCase("0") && socketDetailsTotalRecords > 0) {
				String xmlDataSocketDetails = xmlParserSocketDetails.getNextValueOf("Record");
				xmlDataSocketDetails = xmlDataSocketDetails.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

				XMLParser xmlParserSocketDetailsRecord = new XMLParser(xmlDataSocketDetails);

				String socketServerIP = xmlParserSocketDetailsRecord.getValueOf("SocketServerIP");
				logger.debug("SocketServerIP: " + socketServerIP);
				socketDetailsMap.put("SocketServerIP", socketServerIP);

				String socketServerPort = xmlParserSocketDetailsRecord.getValueOf("SocketServerPort");
				logger.debug("SocketServerPort " + socketServerPort);
				socketDetailsMap.put("SocketServerPort", socketServerPort);

				logger.debug("SocketServer Details found.");

			}
		} catch (Exception e) {
			logger.debug("Exception in getting Socket Connection Details: " + e.getMessage());			
		}

		return socketDetailsMap;
	}

	protected static String WFNGExecute(String ipXML, String jtsServerIP, String serverPort, int flag)
			throws IOException, Exception {
		logger.debug("In WF NG Execute : " + serverPort);
		try {
			if (serverPort.startsWith("33"))
				return WFCallBroker.execute(ipXML, jtsServerIP, Integer.parseInt(serverPort), 1);
			else
				return ngEjbClient.makeCall(jtsServerIP, serverPort, "WebSphere", ipXML);
		} catch (Exception e) {
			logger.debug("Exception Occured in WF NG Execute : " + e.getMessage());
			e.printStackTrace();
			return "Error";
		}
	}
	
	String socketConnection(String cabinetName, String username, String sessionId, String sJtsIp, String iJtsPort, String processInstanceID, String ws_name,
			int connection_timeout, int integrationWaitTime,HashMap<String, String> socketDetailsMap, StringBuilder sInputXML)
	{

		String socketServerIP;
		int socketServerPort;
		Socket socket = null;
		OutputStream out = null;
		InputStream socketInputStream = null;
		DataOutputStream dout = null;
		DataInputStream din = null;
		String outputResponse = null;
		String inputRequest = null;
		String inputMessageID = null;



		try
		{

			logger.debug("userName "+ username);
			logger.debug("SessionId "+ sessionID);

			socketServerIP=socketDetailsMap.get("SocketServerIP");
			logger.debug("SocketServerIP "+ socketServerIP);
			socketServerPort=Integer.parseInt(socketDetailsMap.get("SocketServerPort"));
			logger.debug("SocketServerPort "+ socketServerPort);

	   		if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort==0))
	   		{

    			socket = new Socket(socketServerIP, socketServerPort);
    			socket.setSoTimeout(connection_timeout*1000);
    			out = socket.getOutputStream();
    			socketInputStream = socket.getInputStream();
    			dout = new DataOutputStream(out);
    			din = new DataInputStream(socketInputStream);
    			logger.debug("Dout " + dout);
    			logger.debug("Din " + din);

    			outputResponse = "";

    			inputRequest = getRequestXML( cabinetName,sessionID ,processInstanceID, ws_name, username, sInputXML);


    			if (inputRequest != null && inputRequest.length() > 0)
    			{
    				int inputRequestLen = inputRequest.getBytes("UTF-16LE").length;
    				logger.debug("RequestLen: "+inputRequestLen + "");
    				inputRequest = inputRequestLen + "##8##;" + inputRequest;
    				logger.debug("InputRequest"+"Input Request Bytes : "+ inputRequest.getBytes("UTF-16LE"));
    				dout.write(inputRequest.getBytes("UTF-16LE"));dout.flush();
    			}
    			byte[] readBuffer = new byte[500];
    			int num = din.read(readBuffer);
    			if (num > 0)
    			{

    				byte[] arrayBytes = new byte[num];
    				System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
    				outputResponse = outputResponse+ new String(arrayBytes, "UTF-16LE");
					inputMessageID = outputResponse;
    				logger.debug("OutputResponse: "+outputResponse);

    				if(!"".equalsIgnoreCase(outputResponse))
    					outputResponse = getResponseXML(cabinetName,sJtsIp,iJtsPort,sessionID, processInstanceID,outputResponse,integrationWaitTime );

    				if(outputResponse.contains("&lt;"))
    				{
    					outputResponse=outputResponse.replaceAll("&lt;", "<");
    					outputResponse=outputResponse.replaceAll("&gt;", ">");
    				}
    			}
    			socket.close();

				outputResponse = outputResponse.replaceAll("</MessageId>","</MessageId>/n<InputMessageId>"+inputMessageID+"</InputMessageId>");

				//logger.debug("outputResponse "+outputResponse);
				return outputResponse;

    	 		}

    		else
    		{
    			logger.debug("SocketServerIp and SocketServerPort is not maintained "+"");
    			logger.debug("SocketServerIp is not maintained "+	socketServerIP);
    			logger.debug(" SocketServerPort is not maintained "+	socketServerPort);
    			return "Socket Details not maintained";
    		}

		}

		catch (Exception e)
		{
			logger.debug("Exception Occured Mq_connection_CC"+e.getStackTrace());
			return "";
		}
		finally
		{
			try
			{
				if(out != null)
				{
					out.close();
					out=null;
				}
				if(socketInputStream != null)
				{

					socketInputStream.close();
					socketInputStream=null;
				}
				if(dout != null)
				{

					dout.close();
					dout=null;
				}
				if(din != null)
				{

					din.close();
					din=null;
				}
				if(socket != null)
				{
					if(!socket.isClosed())
						socket.close();
					socket=null;
				}

			}

			catch(Exception e)
			{
				logger.debug("Final Exception Occured Mq_connection_CC"+e.getStackTrace());
				//printException(e);
			}
		}


	}
	private void updateExternalTable(String tablename, String columnname,String sMessage, String sWhere, String jtsIP, String jtsPort, String cabinetName)
	{
		int sessionCheckInt=0;
		int loopCount=50;
		int mainCode = 0;
		
		logger.debug("Inside update EXT table: ");
		
		while(sessionCheckInt<loopCount)
		{
			try
			{
				XMLParser objXMLParser = new XMLParser();
				String inputXmlcheckAPUpdate = CommonMethods.getAPUpdateIpXML(tablename,columnname,sMessage,sWhere,cabinetName,sessionID);
				logger.debug(("inputXmlcheckAPUpdate : " + inputXmlcheckAPUpdate));
				String outXmlCheckAPUpdate=null;
				outXmlCheckAPUpdate=WFNGExecute(inputXmlcheckAPUpdate,jtsIP,jtsPort,1);
				logger.debug(("outXmlCheckAPUpdate : " + outXmlCheckAPUpdate));
				objXMLParser.setInputXML(outXmlCheckAPUpdate);
				String mainCodeforCheckUpdate = null;
				mainCodeforCheckUpdate=objXMLParser.getValueOf("MainCode");
				if (!mainCodeforCheckUpdate.equalsIgnoreCase("0"))
				{
					logger.debug(("Exception in ExecuteQuery_APUpdate updating "+tablename+" table"));
				}
				else
				{
					logger.debug(("Succesfully updated "+tablename+" table"));
				}
				mainCode=Integer.parseInt(mainCodeforCheckUpdate);
				if (mainCode == 11)
				{
					sessionID  = CommonConnection.getSessionID(logger, false);
				}
				else
				{
					sessionCheckInt++;
					break;
				}

				if (outXmlCheckAPUpdate.equalsIgnoreCase("") || outXmlCheckAPUpdate == "" || outXmlCheckAPUpdate == null)
					break;

			}
			catch(Exception e)
			{
				logger.debug(("Inside create validateSessionID exception"+e.getMessage()));
			}
		}
	}

	
	
	private String getResponseXML(String cabinetName,String sJtsIp,String iJtsPort, String sessionId, String processInstanceID,String message_ID, int integrationWaitTime)
	{

		String outputResponseXML="";
		try
		{
			String QueryString = "select OUTPUT_XML from NG_DAO_XMLLOG_HISTORY with (nolock) where MESSAGE_ID ='"+message_ID+"' and WI_NAME = '"+processInstanceID+"'";

			String responseInputXML =CommonMethods.apSelectWithColumnNames(QueryString, cabinetName, sessionID);
			logger.debug("Response APSelect InputXML: "+responseInputXML);

			int Loop_count=0;
			do
			{
				String responseOutputXML=CommonMethods.WFNGExecute(responseInputXML,sJtsIp,iJtsPort,1);
				logger.debug("Response APSelect OutputXML: "+responseOutputXML);

			    XMLParser xmlParserSocketDetails= new XMLParser(responseOutputXML);
			    String responseMainCode = xmlParserSocketDetails.getValueOf("MainCode");
			    logger.debug("ResponseMainCode: "+responseMainCode);



			    int responseTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
			    logger.debug("ResponseTotalRecords: "+responseTotalRecords);

			    if (responseMainCode.equals("0") && responseTotalRecords > 0)
				{

					String responseXMLData=xmlParserSocketDetails.getNextValueOf("Record");
					responseXMLData =responseXMLData.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

	        		XMLParser xmlParserResponseXMLData = new XMLParser(responseXMLData);
	        		//logger.debug("ResponseXMLData: "+responseXMLData);

	        		outputResponseXML=xmlParserResponseXMLData.getValueOf("OUTPUT_XML");
	        		//logger.debug("OutputResponseXML: "+outputResponseXML);

	        		if("".equalsIgnoreCase(outputResponseXML)){
	        			outputResponseXML="Error";
	    			}
	        		break;
				}
			    Loop_count++;
			    Thread.sleep(1000);
			}
			while(Loop_count<integrationWaitTime);
			logger.debug("integrationWaitTime: "+integrationWaitTime);

		}
		catch(Exception e)
		{
			logger.debug("Exception occurred in outputResponseXML" + e.getMessage());
			outputResponseXML="Error";
		}

		return outputResponseXML;

	}
	
	private String getRequestXML(String cabinetName, String sessionId,
			String processInstanceID, String ws_name, String userName, StringBuilder sInputXML)
	{
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>NG_DAO_XMLLOG_HISTORY</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + processInstanceID + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(sInputXML);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		logger.debug("GetRequestXML: "+ strBuff.toString());
		return strBuff.toString();
	}
	
	
	// one pager mail method
	
	private String downloadAttachDocuments(String processInstanceID){
	try
	{
			
			String query_doc="Select top 1  name as DOCUMENTNAME, AppName as APPNAME,ISnull(ImageIndex,'') as ImageIndex, volumeId from pdbdocument with (nolock) "
				+ "WHERE DocumentIndex in (select DocumentIndex from PDBDocumentContent with (nolock) where ParentFolderIndex =(select FolderIndex from PDBFolder with (nolock) where Name = '"+processInstanceID+"'))and"
				+ " name like 'stl%' order by DocumentIndex desc";

			
			//String sessionID = CommonConnection.getSessionID(DAONotifyAPPLog.DAONotifyAPPLogger, false);
			String sInputXML_doc = "<?xml version=\"1.0\"?>"+
					"<APSelectWithColumnNames_Input>"+ 
					"<Option>APSelectWithColumnNames</Option>"+
					"<EngineName>" + cabinetName + "</EngineName> "+
					"<SessionId>" + sessionID + "</SessionId>"+
					"<Query>" + query_doc + "</Query>"+
					"</APSelectWithColumnNames_Input>";
					
			logger.debug("Input:sInputXML_doc"+sInputXML_doc);	
			String sOutputXml = CommonMethods.WFNGExecute(sInputXML_doc,jtsIP,jtsPort,1);
			logger.debug("sOutputXml"+sOutputXml);
			XMLParser xmlParserData = new XMLParser(sOutputXml);
			String mainCode=xmlParserData.getValueOf("MainCode");
			if("0".equalsIgnoreCase(mainCode) && Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"))>0)
			{
				String Records = xmlParserData.getNextValueOf("Records");
				logger.debug("TotalRecords: "+Records);
				String parseStringArray[]=CommonMethods.getTagValues(Records, "Record").split("`");
				logger.debug("Total no of documents: "+parseStringArray.length);
//				File file = new File(OCR_STL_document_download_path+System.getProperty("file.separator")+processInstanceID);
//				if (!file.exists()) 
//				{
//					file.mkdir();
//				}
				
				String pathTodownload=OCR_STL_document_download_path+System.getProperty("file.separator");
					WFXmlResponse parsergetlist = new WFXmlResponse(parseStringArray[0]);
					String docname=parsergetlist.getVal("DOCUMENTNAME");
					String imageindex=parsergetlist.getVal("ImageIndex");
					int volid=Integer.parseInt(parsergetlist.getVal("volumeId"));
					String ext =parsergetlist.getVal("APPNAME");
				
				
					logger.debug("sOutputXml docname : "+docname);
					logger.debug("sOutputXml imageindex : "+imageindex);
					logger.debug("sOutputXml volid : "+volid);
					logger.debug("sOutputXml  ext: "+ext);
					
					logger.debug("parseStringArray.length: "+parseStringArray.length);
									
					logger.debug("pathTodownload : "+pathTodownload);
					logger.debug("imageindex: "+imageindex);
					logger.debug("jtsPort: "+jtsPort);
					logger.debug("IP"+jtsIP);
					try
					{
						CImageServer cImageServer=null;
						try 
						{
							cImageServer = new CImageServer(null,jtsIP, Short.parseShort(jtsPort));
						}
						catch (JPISException e) 
						{
							logger.debug("inside Catch ");
							logger.debug(e.toString());
							return null;
			
						}
						logger.debug("inside tryyyy ");
						try{
						   
							logger.debug("jtsPort : "+jtsPort);
							logger.debug("cabinetName  : "+cabinetName);
							logger.debug("volid volid : "+volid);
							logger.debug("doc location: "+pathTodownload+docname+"."+ext);
							int odDownloadCode=cImageServer.JPISGetDocInFile_MT(null,jtsIP, Short.parseShort(jtsPort), cabinetName, Short.parseShort("1"),Short.parseShort(String.valueOf(volid)), 
							Integer.parseInt(imageindex),"",pathTodownload+processInstanceID+"."+ext, new JPDBString());
							logger.debug("odDownloadCode--"+odDownloadCode);
							if(odDownloadCode==1)
							{
								logger.debug("DOWNLOAD_CALL_COMPLETE");
								return "Done";
							}
							else
							{
								logger.debug("DOWNLOAD_CALL_Not_COMPLETE");
								return null;
							}
						}catch(Exception e)
						{
							logger.debug("Exception-"+e.toString());
							return null;	
					}
				
			}
					catch(Exception e)
					{
						logger.debug("Exception-"+e.toString());
						return null;
					}
			}
			else
			{
				logger.debug("No documents records received from apselect-"+mainCode);
			}
		}
		catch(Exception e)
		{
			logger.debug("Exception-"+e.toString());
			return null;
		}
		return "";
	}
	
	private void doneWiDPL(String processInstanceID,String WorkItemID,String ActivityID,String ProcessDefId ,String ActivityType,String attributesTag,String sJtsIp,String iJtsPort, String ErrDesc ,String decisionValue,String MsgId,String ActivityName,String entryDateTime,HashMap<String, String> CheckGridDataMap){
		try
		{
		String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, processInstanceID,WorkItemID);
		String getWorkItemOutputXml = WFNGExecute(getWorkItemInputXML,sJtsIp,iJtsPort,1);
		logger.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

		XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
		String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
		logger.debug("WmgetWorkItemCall Maincode:  "+ getWorkItemMainCode);

		if (getWorkItemMainCode.trim().equals("0"))
		{
			logger.debug("WMgetWorkItemCall Successful: "+getWorkItemMainCode);

			//String assignWorkitemAttributeInputXML=CommonMethods.assignWorkitemAttributeInput(cabinetName, sessionId,processInstanceID,WorkItemID,attributesTag);
			
			String assignWorkitemAttributeInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
					+ "<Option>WMAssignWorkItemAttributes</Option>"
					+ "<EngineName>"+cabinetName+"</EngineName>"
					+ "<SessionId>"+sessionID+"</SessionId>"
					+ "<ProcessInstanceId>"+processInstanceID+"</ProcessInstanceId>"
					+ "<WorkItemId>"+WorkItemID+"</WorkItemId>"
					+ "<ActivityId>"+ActivityID+"</ActivityId>"
					+ "<ProcessDefId>"+ProcessDefId+"</ProcessDefId>"
					+ "<LastModifiedTime></LastModifiedTime>"
					+ "<ActivityType>"+ActivityType+"</ActivityType>"
					+ "<complete>D</complete>"
					+ "<AuditStatus></AuditStatus>"
					+ "<Comments></Comments>"
					+ "<UserDefVarFlag>Y</UserDefVarFlag>"
					+ "<Attributes>"+attributesTag+"</Attributes>"
					+ "</WMAssignWorkItemAttributes_Input>";
			
			logger.debug("InputXML for assignWorkitemAttribute Call Notify: "+assignWorkitemAttributeInputXML);

			String assignWorkitemAttributeOutputXML=WFNGExecute(assignWorkitemAttributeInputXML,sJtsIp,
					iJtsPort,1);
			
			logger.debug("OutputXML for assignWorkitemAttribute Call Notify: "+assignWorkitemAttributeOutputXML);
			
			XMLParser xmlParserWorkitemAttribute = new XMLParser(assignWorkitemAttributeOutputXML);
			String assignWorkitemAttributeMainCode = xmlParserWorkitemAttribute.getValueOf("MainCode");
			logger.debug("AssignWorkitemAttribute MainCode: "+assignWorkitemAttributeMainCode);

			if(assignWorkitemAttributeMainCode.trim().equalsIgnoreCase("0")){
				logger.debug("AssignWorkitemAttribute Successful: "+assignWorkitemAttributeMainCode);				
				logger.debug("WorkItem moved to next Workstep.");
			}
			else{
				logger.debug("decisionValue : "+decisionValue);
				ErrDesc="Done WI Failed";
				sendMail(cabinetName,sessionID,processInstanceID,jtsIP,jtsPort,ErrDesc,assignWorkitemAttributeMainCode,ProcessDefId,MsgId);
			}
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			Date current_date = new Date();
			String formattedEntryDatetime=dateFormat.format(current_date);
			logger.debug("FormattedEntryDatetime: "+formattedEntryDatetime);
	
			
			Date d1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(entryDateTime);
			String entrydatetime_format = dateFormat.format(d1);

			String columnNames="wi_name,decision_date_time,workstep,username,Decision,Remarks,entry_date_time";
			String columnValues="'"+processInstanceID+"','"+formattedEntryDatetime+"','"+ActivityName+"','"
			+CommonConnection.getUsername()+"','"+decisionValue+"','"+ErrDesc+"','"+entrydatetime_format+"'";

			String apInsertInputXML=CommonMethods.apInsert(cabinetName, sessionID, columnNames, columnValues,"NG_DPL_GR_DECISION_HISTORY");
			logger.debug("APInsertInputXML: "+apInsertInputXML);

			String apInsertOutputXML = WFNGExecute(apInsertInputXML,sJtsIp,iJtsPort,1);
			logger.debug("APInsertOutputXML: "+ apInsertInputXML);

			XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
			String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
			logger.debug("Status of apInsertMaincode  "+ apInsertMaincode);

			logger.debug("Completed On "+ ActivityName);
			
			if(apInsertMaincode.equalsIgnoreCase("0")){
				logger.debug("ApInsert successful: "+apInsertMaincode);
				logger.debug("Inserted in WiHistory table successfully.");
			}
			else
			{
				logger.debug("ApInsert failed: "+apInsertMaincode);
			}
		}
		else
		{
			getWorkItemMainCode="";
			logger.debug("WmgetWorkItem failed: "+getWorkItemMainCode);
			ErrDesc="WI Failed";
			sendMail(cabinetName,sessionID,processInstanceID,jtsIP,jtsPort,ErrDesc,getWorkItemMainCode,ProcessDefId,MsgId);
		}
	}
		catch(Exception e)
		{
			logger.debug("Exception-"+e.toString());
			
		}
	}
	
}
