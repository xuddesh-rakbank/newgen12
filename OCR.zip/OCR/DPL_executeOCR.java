package com.newgen.DPL.OCR;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;

public class DPL_executeOCR {
	

	
	public static int retCode = 0;
	public static String uuid = "";
	public static String authURL = "";
	public static String authBody = "";
	
	public static String postKongToken(String URL, String requestBody, Logger logger,String Kong_API_KEY,String Kong_API_JKS_Password) {
		try {
			// Load SSL certs or custom trust settings
			loadSSL(logger,Kong_API_JKS_Password);

			// Open URL connection
			URL postUrl = new URL(URL);
			HttpURLConnection postConnection = (HttpURLConnection) postUrl.openConnection();
			logger.debug("After URL connection:");

			// Set request method and headers
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Accept", "application/json");
			postConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			postConnection.setRequestProperty("apikey", Kong_API_KEY);
			postConnection.setDoOutput(true);

			// Send request
			//logger.debug("After JSON Request Construction: " + requestBody);
			try (DataOutputStream outputStream = new DataOutputStream(postConnection.getOutputStream())) {
				outputStream.writeBytes(requestBody);
				outputStream.flush();
			}

			logger.debug("After Output Stream flush");
			

			// Read response
			int postResponseCode = postConnection.getResponseCode();
			logger.debug("Response Code: " + postResponseCode);

			StringBuilder postResponse = new StringBuilder();
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(
					postResponseCode >= 400 ? postConnection.getErrorStream() : postConnection.getInputStream()))) {
				logger.debug("Inside Response from Input Stream");
				String inputLine;
				while ((inputLine = reader.readLine()) != null) {
					postResponse.append(inputLine);
				}
			}

			logger.debug("Final JSON Response: " + postResponse);
			postConnection.disconnect();

			return postResponse.toString()+"~"+postResponseCode;
			

		} catch (IOException ioEx) {
			logger.error("HTTP Connection Error: " + ioEx.getMessage(), ioEx);
			return "Failure" + ioEx.getMessage()+"~"+"0"; // indicate connection failure
		}
	}
	
	public static void loadSSL(Logger logger,String Kong_API_JKS_Password) {
		
		String certFilePass =Kong_API_JKS_Password;
		String workingDirectory = System.getProperty("user.dir");
		logger.debug("certFilePass: " + certFilePass);
		String cacertsFile = workingDirectory + File.separator + "Certificates" + File.separator + "KongSSL.jks";
		logger.debug("CacertsFile: " + cacertsFile);
		
		String packageHndStr = "javax.net.ssl";
		java.lang.System.setProperty("java.protocol.handler.pkgs", packageHndStr);
		java.lang.System.setProperty("Content-Type", "text/html");
		java.lang.System.setProperty("Content-Type", "application/soap+xml; charset=utf-8");
		java.lang.System.setProperty("javax.net.ssl.keyStore", cacertsFile);
		java.lang.System.setProperty("javax.net.ssl.keyStoreType", java.security.KeyStore.getDefaultType());
		java.lang.System.setProperty("javax.net.ssl.keyStorePassword", certFilePass);
		java.lang.System.setProperty("javax.net.ssl.trustStore", cacertsFile);
		java.lang.System.setProperty("javax.net.ssl.trustStoreType", java.security.KeyStore.getDefaultType());
		java.lang.System.setProperty("javax.net.ssl.trustStorePassword", certFilePass);
	}
	
	public static String callOCRAPI(String authToken,String Kong_API_KEY, String URL, Logger logger,String Kong_API_JKS_Password,String OCR_STL_document_download_path,String cabinetName,String processInstanceID, String sessionID,String CIF,String OCR_STL_API_Expected_Tags) {
		try {
			// Load SSL certs or custom trust settings
			loadSSL(logger,Kong_API_JKS_Password);

			
			String filePath = OCR_STL_document_download_path+System.getProperty("file.separator")+processInstanceID+".pdf";

	        String param1 = CIF;
	        
	        String requestId= UUID.randomUUID().toString();
	        String boundary = UUID.randomUUID().toString();
	        String LINE_FEED = "\r\n";
	        
	        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date current_date = new Date();
			String formattedEntryDatetime = dateFormat.format(current_date);
	        
            URL url = new URL(URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setUseCaches(false);
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setRequestMethod("POST");

            connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Authorization", "Bearer "+ authToken);
            connection.setRequestProperty("apikey", Kong_API_KEY);

            OutputStream outputStream = connection.getOutputStream();
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream, "UTF-8"), true);

            // ================== param1 ==================
            writer.append("--" + boundary).append(LINE_FEED);
            writer.append("Content-Disposition: form-data; name=\"client\"").append(LINE_FEED);
            writer.append("Content-Type: text/plain; charset=UTF-8").append(LINE_FEED);
            writer.append(LINE_FEED);
            writer.append(param1).append(LINE_FEED);
            writer.flush();

            // ================== param2 ==================
            writer.append("--" + boundary).append(LINE_FEED);
            writer.append("Content-Disposition: form-data; name=\"ref_id\"").append(LINE_FEED);
            writer.append("Content-Type: text/plain; charset=UTF-8").append(LINE_FEED);
            writer.append(LINE_FEED);
            writer.append(boundary).append(LINE_FEED);
            writer.flush();

            // ================== FILE ==================
            File uploadFile = new File(filePath);
            String fileName = uploadFile.getName();

            writer.append("--" + boundary).append(LINE_FEED);
            writer.append("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"").append(LINE_FEED);
            writer.append("Content-Type: " + Files.probeContentType(uploadFile.toPath())).append(LINE_FEED);
            writer.append(LINE_FEED);
            writer.flush();

            FileInputStream inputStream = new FileInputStream(uploadFile);
            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            outputStream.flush();
            inputStream.close();

            writer.append(LINE_FEED);
            writer.flush();

            // ================== END BOUNDARY ==================
            writer.append("--" + boundary + "--").append(LINE_FEED);
            writer.close();

			logger.debug("After Output Stream flush");

			// Read response
			int postResponseCode = connection.getResponseCode();
			logger.debug("Response Code: " + postResponseCode);
			
			 String Outputmessage="";
			 String ResponseOutputmessage="";
			 if(postResponseCode==200){	        	
		        	
		        	logger.debug("Inside 200 return code: " );
		        	
		        	InputStream is = connection.getInputStream();
		            BufferedReader br = new BufferedReader(new InputStreamReader(is));

		            StringBuilder responseStrBuilder = new StringBuilder();
		            String line;
		            while ((line = br.readLine()) != null) {
		                responseStrBuilder.append(line);
		            }
		            
		            logger.debug("responseStrBuilder: " + responseStrBuilder);
		             Outputmessage= responseStrBuilder.toString();	            
		            connection.disconnect();
		            
		            JSONObject responseJson = new JSONObject(responseStrBuilder.toString());//actual
		           // JSONObject responseJson = new JSONObject(jsonResponse);//for test , for actual uncomment upper line
		
		            String status = responseJson.getString("status");
		
		            JSONObject extracted_data = responseJson.getJSONObject("extracted_data");
		            String score = extracted_data.getString("score");
		            JSONObject dataToRead = extracted_data.getJSONObject("data");
		            
		            Map<String, String> parsedMap = new HashMap<>();
		            Iterator<String> keys = dataToRead.keys();
		            String columnName="";
		            String columnValue="";
		            
		            columnName=columnName+"WI_NAME,integration_status,final_score,";
		            columnValue=columnValue+"'"+processInstanceID+"','"+status+"','"+score+"',";
		           
		            while (keys.hasNext()) {
		                String key = keys.next();                 
		                JSONArray arr = dataToRead.getJSONArray(key);  
		                
		                List<String> list=Arrays.asList(OCR_STL_API_Expected_Tags.split(","));
			            if(list.contains(key.toLowerCase())) {
			                
			                columnName=columnName+key+","+key+"_score,";
			                
			                String value = arr.getString(0);
			                String confidence_score = String.valueOf(arr.getDouble(1));
	
			                columnValue=columnValue+"'" + value + "','" + confidence_score + "',";
			            }
		            }
		            
		            if(columnName.length()>2 && columnValue.length()>2) {
		            	columnName=columnName.substring(0, columnName.length()-1);
			            columnValue=columnValue.substring(0, columnValue.length()-1);
		            }
		            
		            
		            logger.debug("status: " + status);
		            logger.debug("score " + score);
		            logger.debug("columnName: " + columnName);
		            logger.debug("columnValue " + columnValue);
		            
		            ResponseOutputmessage=status;
		            
		            String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, columnValue,
							"NG_DPL_STL_OCR_Details");
		            
					logger.debug("APInsertInputXML: " + apInsertInputXML);
		
					String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(),1);
					logger.debug("APInsertOutputXML: " + apInsertInputXML);
							
					logger.debug("apInsertOutputXML: " + apInsertOutputXML);
		
					XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
					String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
					logger.debug("Status of apInsertMaincode  " + apInsertMaincode);
		
					if (apInsertMaincode.equalsIgnoreCase("0"))
					{
							logger.debug("ApInsert successful: " + apInsertMaincode);
							logger.debug("Inserted in NG_DPL_XMLLOG_HISTORY table successfully.");
					}
					else
					{
							logger.debug("ApInsert failed: " + apInsertMaincode);
					}	
		            
				}
	            else if(postResponseCode==400 || postResponseCode==422 || postResponseCode==429 || postResponseCode==498
	            		|| postResponseCode==500 || postResponseCode==503){
	            	logger.debug("Inside 400/401/402/500 return code:" );
	            	
	            	InputStream is = connection.getErrorStream();
	            	 logger.debug("InputStream " + is);
	            	 logger.debug("error message " + connection.getResponseMessage());
		            BufferedReader br = new BufferedReader(new InputStreamReader(is));

		            StringBuilder responseStrBuilder = new StringBuilder();
		            String line;
		            while ((line = br.readLine()) != null) {
		                responseStrBuilder.append(line);
		            }
		            
		            logger.debug("responseStrBuilder: " + responseStrBuilder);
		            Outputmessage= responseStrBuilder.toString();	            
		            connection.disconnect();            
		           
		            JSONObject responseJson = new JSONObject(responseStrBuilder.toString());
		            String detail = responseJson.getString("detail");
		            logger.debug("detail: " + detail);
		            ResponseOutputmessage=detail;
		            
		           String columnName="WI_NAME,integration_status,Error_description";
		           String columnValue="'"+processInstanceID+"','Failure','"+detail+"'";
		           
			        String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, columnValue,
									"NG_DPL_STL_OCR_Details");
					logger.debug("APInsertInputXML: " + apInsertInputXML);

					String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(),1);
					logger.debug("APInsertOutputXML: " + apInsertInputXML);
							
					logger.debug("apInsertOutputXML: " + apInsertOutputXML);

					XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
					String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
					logger.debug("Status of apInsertMaincode  " + apInsertMaincode);

					if (apInsertMaincode.equalsIgnoreCase("0")) {
								logger.debug("ApInsert successful: " + apInsertMaincode);
								logger.debug("Inserted in NG_DPL_XMLLOG_HISTORY table successfully.");
					}
					else {
								logger.debug("ApInsert failed: " + apInsertMaincode);
					}	
		           
	            }
	            else{
	            	connection.disconnect(); 
	            	Outputmessage = "Unable to get the Response Code from OCR";
	            	ResponseOutputmessage=Outputmessage;
	            	logger.debug("Inside else condition of get Response code " );
	            	String columnName="WI_NAME,integration_status,Error_description";
			        String columnValue="'"+processInstanceID+"','Failure','"+Outputmessage+"'";
			        
			        String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnName, columnValue,
							"NG_DPL_STL_OCR_Details");
					logger.debug("APInsertInputXML: " + apInsertInputXML);

					String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(),1);
					logger.debug("APInsertOutputXML: " + apInsertInputXML);
					
					logger.debug("apInsertOutputXML: " + apInsertOutputXML);

					XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
					String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
					logger.debug("Status of apInsertMaincode  " + apInsertMaincode);

					if (apInsertMaincode.equalsIgnoreCase("0")) {
						logger.debug("ApInsert successful: " + apInsertMaincode);
						logger.debug("Inserted in NG_DPL_XMLLOG_HISTORY table successfully.");
					} else {
						logger.debug("ApInsert failed: " + apInsertMaincode);
					}
	            }
			 
			 
			  insertIntoDb("",Outputmessage,requestId,processInstanceID,cabinetName,sessionID,formattedEntryDatetime,logger);
			 
			 return ResponseOutputmessage;
			 
		} 
		catch (IOException ioEx) 
		{
			logger.debug("HTTP Connection Error: " + ioEx.getMessage(), ioEx);		
			
			return "Failure: " + ioEx.getMessage(); // indicate connection failure
		}
		catch (Exception e)
		{
			logger.debug("Error: " + e.getMessage(), e);
			e.printStackTrace();
			String ResponseOutputmessage = "Unable to connect To OCR";
			
			return ResponseOutputmessage;
		}
	}
	
	protected static String getUUID() {
		UUID uid = UUID.randomUUID();
		uuid = uid.toString();
		return uuid;
	}
	
public static void insertIntoDb(String inputbody,String output,String requestId,String wi_name,String cabinetName,
		String sessionID,String formattedReqDatetime,Logger logger){
		
		try {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			Date current_date = new Date();
			String formattedEntryDatetime = dateFormat.format(current_date);
			logger.debug("FormattedEntryDatetime: " + formattedEntryDatetime);

			String columnNames = "WI_NAME,ACT_DATE_TIME,REQ_DATE_TIME,INPUT_XML,OUTPUT_XML,callname,WORKSTEP_NAME,USER_NAME,MESSAGE_ID";
			String columnValues = "'" + wi_name + "','" + formattedEntryDatetime + "','" + formattedReqDatetime + "','" + inputbody + "','" + output
					+ "','OCR_Integration','Sys_STL_OCR','Utility','"+requestId+"'";

			
			String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnNames, columnValues,
					"NG_DPL_XMLLOG_HISTORY");
			logger.debug("APInsertInputXML: " + apInsertInputXML);

			String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(),1);
			logger.debug("APInsertOutputXML: " + apInsertInputXML);
			
			logger.debug("apInsertOutputXML: " + apInsertOutputXML);

			XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
			String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
			logger.debug("Status of apInsertMaincode  " + apInsertMaincode);

			if (apInsertMaincode.equalsIgnoreCase("0")) {
				logger.debug("ApInsert successful: " + apInsertMaincode);
				logger.debug("Inserted in NG_DPL_XMLLOG_HISTORY table successfully.");
			} else {
				logger.debug("ApInsert failed: " + apInsertMaincode);
			}
		}
		catch (Exception e)
		{
			logger.debug("Error: " + e.getMessage(), e);
			e.printStackTrace();
			
		}
		
	}


	
	public static String getAuthToken(Logger logger,String Kong_API_JKS_Password,String Kong_Endpoint,String Kong_API_KEY,String Kong_API_client_id
			,String Kong_API_client_secret,String Kong_API_resource_type) {
		
		String token = "";
		int expiry = 0;
		token  = getExistingAuthToken(logger);
		String AuthBody="client_id="+Kong_API_client_id+"&client_secret="+Kong_API_client_secret+"&resource_type="+Kong_API_resource_type+"";
		
		if(token.equalsIgnoreCase("") && token.length()==0) {
		
		String output = postKongToken(Kong_Endpoint,AuthBody,logger,Kong_API_KEY,Kong_API_JKS_Password);
		
		String[] output_arr = output.split("~");
		
		String ResponseBody=output_arr[0];
		String ReturnCode=output_arr[1];
		
		JSONObject responseJson = new JSONObject(ResponseBody);//actual
		
		logger.debug("Response from CPF Doc API: " + output);
		
		if(ReturnCode.equalsIgnoreCase("200")) {
			
			token = responseJson.getString("access_token");
			expiry = responseJson.getInt("expires_in");
			
			
		}
		
		String colNames = "AuthToken,GenDateTime,ExpiryDateTime";
		String colValues = "'"+token+"',getDate(),DATEADD(second,"+expiry+",getDate())";
		
		try {
			String apInsertInputXML = CommonMethods.apInsert(CommonConnection.getCabinetName(),
					CommonConnection.getSessionID(logger, false), colNames, colValues, "NG_DPL_KONG_AUTH_TOKEN"); // toDo
			logger.debug("APInsertInputXML: " + apInsertInputXML);

			String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(),1);
			logger.debug("APInsertOutputXML: " + apInsertOutputXML);

			XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
			String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
			logger.debug("Status of apInsertMaincode  " + apInsertMaincode);

			if (apInsertMaincode.equalsIgnoreCase("0")) {
				logger.debug("ApInsert successful: " + apInsertMaincode);
				logger.debug("Inserted in Auth table successfully.");
			} else {
				logger.debug("ApInsert failed: " + apInsertMaincode);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		return token;
	}
	
	public static String getExistingAuthToken(Logger logger) {
		
		String AuthToken = "";
		try {
			String tokenQuery = "SELECT AuthToken from NG_DPL_KONG_AUTH_TOKEN with(NOLOCK) where expiryDateTime>GETDATE()";
			String tokenIPXML = CommonMethods.apSelectWithColumnNames(tokenQuery, CommonConnection.getCabinetName(),
					CommonConnection.getSessionID(logger, false));;
			String tokenOPXML = CommonMethods.WFNGExecute(tokenIPXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);;
			XMLParser tokenXML = new XMLParser(tokenOPXML);
			int totalRet = Integer.parseInt(tokenXML.getValueOf("TotalRetrieved"));
			if (tokenXML.getValueOf("MainCode").equalsIgnoreCase("0") && totalRet > 0) {
				AuthToken = tokenXML.getValueOf("AuthToken");
			}
			//AuthToken="";
			logger.debug("Got exisiting token: "+ AuthToken);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return AuthToken;
	}


}
