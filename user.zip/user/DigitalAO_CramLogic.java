package com.newgen.iforms.user;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.newgen.omni.jts.cmgr.XMLParser;

import com.newgen.iforms.custom.IFormReference;

public class DigitalAO_CramLogic extends DigitalAO_Common {

	public String triggerRiskCalculation(IFormReference iform) {

		String wiName = getWorkitemName(iform);
		DigitalAO.mLogger.info("[CRAM-Logic][" + wiName + "] Starting CRAM request build.");

		try {

			JSONObject req = new JSONObject();
			String wiNumber = wiName.split("-")[1];
			String timeStamp = new SimpleDateFormat("ddMMyyHHmmss").format(new Date());
			String requestId = wiNumber + "_" + timeStamp;
			// String requestId = "CRAM_" + UUID.randomUUID().toString().substring(0, 8);

			// =========================================================
			// DEFAULT FIELDS
			// =========================================================
			req.put("serviceId", "CRAM_DecisionEngine_V1");
			req.put("serviceType", "DecisionEngineCRAM");
			req.put("serviceChannelId", "EBC.WBA");
			req.put("requestId", requestId);
			req.put("timeStamp", new SimpleDateFormat("MM/dd/yyyy HH:mm").format(new Date()));
			req.put("journey", "DAO");
			req.put("custType", "Individual");

			req.put("userid", "System");
			req.put("PersonalAccountsUtilizedForCommercialActivity", "N");

			// CUSTOMER TYPE LOGIC (NTB / ETB)

			String isNtb = nvl(iform.getValue("is_Ntb"));
			String customerType = nvl(iform.getValue("Customer_Type"));

			if ("Y".equalsIgnoreCase(isNtb) && !"Y".equalsIgnoreCase(nvl(iform.getValue("Dedupe_Match_found")))) {

				req.put("type", "NTB");
				req.put("custIdType", "EMID");
				req.put("custIdValue", nvl(iform.getValue("Emirates_id")));
				if ("NR".equalsIgnoreCase(customerType)) {
					req.put("custIdType", "PPT");
					req.put("custIdValue", nvl(iform.getValue("Passport_No")));
					DigitalAO.mLogger.debug("[CRAM][" + wiName + "] NR NTB Customer Flow");
				}
				req.put("maturityRelationship", new SimpleDateFormat("dd.MM.yyyy").format(new Date()));

				DigitalAO.mLogger.debug("[CRAM][" + wiName + "] NTB Customer Flow");

			} else {

				req.put("type", "ETB");
				req.put("custIdType", "CIF");
				req.put("custIdValue", nvl(iform.getValue("CIF")));

				if ("NR".equalsIgnoreCase(customerType)) {
					req.put("custIdType", "PPT");
					req.put("custIdValue", nvl(iform.getValue("Passport_No")));
					DigitalAO.mLogger.debug("[CRAM][" + wiName + "] NR ETB Customer Flow");
				}

				String cifCreationDate;

				String dedupeMatchFound = nvl(iform.getValue("Dedupe_Match_found"));

				if ("Y".equalsIgnoreCase(dedupeMatchFound)) {

					DigitalAO.mLogger.info(
							"[CRAM][" + wiName + "] Dedupe case detected → fetching latest CIF creation date from DB");

					cifCreationDate = getCifCreationDateFromDB(iform, wiName);

				} else {

					cifCreationDate = nvl(iform.getValue("cifCreationDate"));

					if (cifCreationDate.isEmpty()) {

						DigitalAO.mLogger.info("[CRAM][" + wiName + "] CIF date not found in form → fetching from DB");

						cifCreationDate = getCifCreationDateFromDB(iform, wiName);
					}
				}

				// ✅ FORMAT + SAFETY
				String maturity = formatToCramDate(cifCreationDate);

				// ✅ FINAL FALLBACK (VERY IMPORTANT)
				if (maturity == null || maturity.isEmpty()) {

					maturity = new SimpleDateFormat("dd.MM.yyyy").format(new Date());

					DigitalAO.mLogger.warn("[CRAM][" + wiName
							+ "] CIF Date empty after parsing → defaulting to current date: " + maturity);
				}

				req.put("maturityRelationship", maturity);

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Final maturityRelationship: " + maturity);
				DigitalAO.mLogger.debug("maturityRelationship sent to CRAM: " + formatToCramDate(cifCreationDate));

				DigitalAO.mLogger.debug("[CRAM][" + wiName + "] ETB Customer Flow");
			}

			// =========================================================
			// CUSTOMER DETAILS
			// =========================================================
			String customerName = getCustomerName(iform, wiName);
			req.put("customerName", customerName);

			// =========================================================
			// ARRAY FIELDS
			// =========================================================
			// req.put("nationality", toJsonArray(iform.getValue("Nationality")));

			JSONArray nationalityArr = getFinalNationality(iform, wiName);

			if (nationalityArr != null && nationalityArr.length() > 0) {
				req.put("nationality", nationalityArr);
			}
//            req.put("demographic", toJsonArraySplitSafe(
//                    iform.getValue("Money_send_and_received_Countries_final_IBPS")));

			req.put("demographic", getFinalDemographic(iform, wiName));
			req.put("industry", getIndustryClmCode(iform, wiName));
			req.put("countryOfBirth", toJsonArray(iform.getValue("Country_of_birth")));
			// =========================================================
			// PERSONA LOGIC (DB-DRIVEN)
			// =========================================================
			String persona = derivePersona(iform, wiName);
			req.put("persona", persona);
			req.put("deliveryChannel", "NF");
			double annualTurnover = Math.round(Double.parseDouble(nvl(iform.getValue("Average_Expected_Turnover"))));
			req.put("annualTurnoverExpected", annualTurnover);
			if ("NR".equalsIgnoreCase(customerType)) {
				req.put("nonResidentUboOrCustomer", "Y");
			} else {
				req.put("nonResidentUboOrCustomer", "N");
			}

			String pepStatus = nvl(iform.getValue("PEP"));
			String pepVal = nvl(iform.getValue("pepValue"));

			if ("N".equalsIgnoreCase(pepStatus)) {

				pepVal = "NPEP";

			} else {

				pepVal = getPepCode(iform, pepVal, wiName);
			}

			req.put("pepStatus", pepVal);

			// HNWI FLAG
			String grossMonthly = (String) iform.getValue("gross_monthly_salary_income");
			double annualIncome = Math.round(Double.parseDouble(grossMonthly) * 12);
			req.put("hnwi", annualIncome);

			// hnwe
			req.put("hnwe", 0);
			// =========================================================
			// DEFAULT REQUIRED FIELDS
			// =========================================================
			req.put("adverseMediaResults", "N");
			req.put("customerReportedToRegulator", "N");
			req.put("lengthOfEstablishment", JSONObject.NULL);
			req.put("complexOwnershipStructure", "");
			req.put("layersInComplexOwnershipStructure", JSONObject.NULL);
			req.put("countryOfEstablishment", new JSONArray());
			req.put("businessSegment", "PBD");
			req.put("businessSubsegment", "Null");
			req.put("licensingAuthority", JSONObject.NULL);

			JSONArray currencyList;

			// NTB → Static AED
			boolean isNtbFlow = "Y".equalsIgnoreCase(isNtb)
					&& !"Y".equalsIgnoreCase(nvl(iform.getValue("Dedupe_Match_found")));

			if (isNtbFlow) {
				DigitalAO.mLogger
						.info("[CRAM][" + wiName + "] currency Logic -> isNtb=" + isNtb + ", Dedupe_Match_found="
								+ nvl(iform.getValue("Dedupe_Match_found")) + ", isNtbFlow=" + isNtbFlow);

				currencyList = new JSONArray();
				currencyList.put("AED");

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] NTB → Currency set to AED");

			} else {

				// ETB → Fetch from Account Summary
				currencyList = getCurrencyFromDB(iform, wiName);

				// Fallback (important for safety)
				if (currencyList.length() == 0) {
					currencyList.put("AED");
					DigitalAO.mLogger.warn("[CRAM][" + wiName + "] No currency found → default AED");
				}

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] ETB → Currency from Account Summary: " + currencyList);
			}

			req.put("currency", currencyList);

			JSONArray productList = getCramProductList(iform, wiName, isNtb);
			req.put("product", productList);

			JSONArray cashTurnoverPerc = getCashTurnoverPerc(iform, wiName);
			req.put("cashTurnoverPerc", cashTurnoverPerc);
			String lengthOfResidency = getLengthOfResidency(iform, wiName);
			req.put("lengthOfResidency", lengthOfResidency);

			DigitalAO.mLogger.debug("[CRAM][" + wiName + "] Final Request JSON: " + req.toString());

			// =========================================================
			// CALL INTEGRATION
			// =========================================================
			String response = new DigitalAO_CramIntegration().callCramGateway(req.toString(), requestId, iform);

			// ADD THIS LINE HERE
			insertRiskSheetData(iform, wiName, req, response);

			return processCramResponse(iform, response, wiName);

		} catch (Exception e) {

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Exception: " + e.getMessage(), e);
			return "9999~Logic Error";
		}
	}

	// PERSONA DERIVATION

	private String derivePersona(IFormReference iform, String wiName) {

		String rulingFlag = nvl(iform.getValue("is_Ruling_Family"));
		String empType = nvl(iform.getValue("employement_type"));
		String customerType = nvl(iform.getValue("Customer_Type"));
		String personaCode;

		DigitalAO.mLogger.debug(
				"[CRAM][" + wiName + "] Persona Inputs → RulingFlag: " + rulingFlag + ", EmploymentType: " + empType);

		if ("Y".equalsIgnoreCase(rulingFlag)) {
			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Persona: Ruling Family → RF");
			return "RF";
		}
		if ("NR".equalsIgnoreCase(customerType) && "Self employed".equalsIgnoreCase(empType)) {
			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Persona: NR self employed → RF");
			return "SRN";
		}
		if ("NR".equalsIgnoreCase(customerType) && "Salaried".equalsIgnoreCase(empType)) {
			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Persona: NR self salaried → RF");
			return "ENR";
		}

		if ("Self employed".equalsIgnoreCase(empType)) {
			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Persona: Self Employed - Resident → SER");
			return "SER";
		}

		if ("Salaried".equalsIgnoreCase(empType)) {
			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Persona: Employed - Resident → ER");
			return "ER";
		}

		DigitalAO.mLogger.warn("[CRAM][" + wiName + "] Persona defaulted → ER");
		return "ER";
	}

	// RESPONSE PROCESSING

	private String processCramResponse(IFormReference iform, String response, String wiName) {

		try {

			JSONObject res = new JSONObject(response);

			if (res.has("totalRiskScore")) {

				double scoreVal = res.optDouble("totalRiskScore", 0.0);
				String score = String.valueOf(scoreVal);

				String riskCategory = res.optString("riskCategory", "N");
				String rating = String.valueOf(res.optDouble("overallRiskRating", 0.0));

				iform.setValue("risk_score", score);
				iform.setValue("risk_category", riskCategory);
				iform.setValue("overall_risk_rating", rating);
				iform.setValue("high_risk", scoreVal > 4 ? "Y" : "N");

				JSONObject info = res.optJSONObject("riskScoreInfo");
				if (info != null) {
					DigitalAO.mLogger.debug("[CRAM][" + wiName + "] Risk Info: " + info.toString());
				}

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Score: " + score + ", Category: " + riskCategory
						+ ", Rating: " + rating);

				return "0000~SUCCESS~" + score + "~" + riskCategory;
			}

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Invalid response: " + response);
			return "9999~Invalid Response";

		} catch (Exception e) {

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Parsing Error: " + e.getMessage());
			return "9999~Parsing Error";
		}
	}

	private JSONArray toJsonArray(Object value) {

		JSONArray arr = new JSONArray();

		if (value != null && !value.toString().trim().isEmpty()) {
			arr.put(value.toString().trim());
		}

		return arr;
	}

	private String nvl(Object val) {
		return val == null ? "" : val.toString().trim();
	}

	private String formatToCramDate(String inputDate) {
		try {
			Date date = new SimpleDateFormat("yyyy-MM-dd").parse(inputDate);
			return new SimpleDateFormat("dd.MM.yyyy").format(date);
		} catch (Exception e) {
			DigitalAO.mLogger.error("Error formatting CIF creation date", e);
			return "";
		}
	}

	public static String parseDate(String sdate, String ipFormat, String opFormat) {

		try {
			DateFormat format = new SimpleDateFormat(ipFormat, Locale.ENGLISH);
			Date date = format.parse(sdate);

			DateFormat dateFormat = new SimpleDateFormat(opFormat);
			return dateFormat.format(date);

		} catch (Exception e) {
			return "";
		}
	}

	private JSONArray getCurrencyFromDB(IFormReference iform, String wiName) {

		JSONArray currencyArr = new JSONArray();

		try {

			String query = "SELECT DISTINCT CrnCode FROM NG_DAO_ACCOUNT_SUMMARY WITH (NOLOCK) WHERE WI_NAME='" + wiName
					+ "'";

			List<List<String>> result = iform.getDataFromDB(query);

			if (result != null && result.size() > 0) {

				for (List<String> row : result) {
					String currency = row.get(0);

					if (currency != null && !currency.trim().isEmpty()) {
						currencyArr.put(currency);
					}
				}
			}

			DigitalAO.mLogger.debug("[CRAM][" + wiName + "] Currency List: " + currencyArr);

		} catch (Exception e) {
			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error fetching currency", e);
		}

		return currencyArr;
	}

	private JSONArray getProductFromDB(IFormReference iform, String wiName) {

		JSONArray productArr = new JSONArray();

		try {

			// String query = "SELECT DISTINCT AcctType, AccountCategory FROM
			// NG_DAO_ACCOUNT_SUMMARY WITH (NOLOCK) WHERE WI_NAME='" + wiName + "'";

			String query = "SELECT DISTINCT AcctType, AccountCategory " + "FROM NG_DAO_ACCOUNT_SUMMARY WITH (NOLOCK) "
					+ "WHERE WI_NAME='" + wiName + "' " + "AND ISNULL(AccountCategory,'') NOT IN "
					+ "(SELECT SchemeCode " + " FROM NG_DAO_LDACCOUNTS_MST WITH (NOLOCK))";

			List<List<String>> result = iform.getDataFromDB(query);

			if (result != null && result.size() > 0) {

				for (List<String> row : result) {

					String acctType = nvl(row.get(0));
					String accountCategory = nvl(row.get(1));

					// Special Requirement
					if ("CCD".equalsIgnoreCase(acctType)) {

						productArr.put("PBIC");

						DigitalAO.mLogger.info("[CRAM][" + wiName + "] CCD found -> Sending PBIC");

					}
//            	    else if ("PL".equalsIgnoreCase(accountCategory)) {
//
//            	    	productArr.put("PBPL");
//            	    	DigitalAO.mLogger.info("[CRAM][" + wiName + "] Account Category PL found -> Sending PBPL");
//            	    	}
					else {

						if (!accountCategory.isEmpty()) {
							productArr.put(accountCategory);
						}
					}
				}
			}

			DigitalAO.mLogger.debug("[CRAM][" + wiName + "] Product List: " + productArr);

		} catch (Exception e) {
			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error fetching product", e);
		}

		return productArr;
	}

	private JSONArray getCashTurnoverPerc(IFormReference iform, String wiName) {

		JSONArray arr = new JSONArray();

		try {

			// ✅ SAFE PARSING (avoid crash)
			double salary = 0.0;
			double cashTurnover = 0.0;

			try {
				salary = Double.parseDouble(nvl(iform.getValue("gross_monthly_salary_income")));
			} catch (Exception e) {
				salary = 0.0;
			}

			try {
				cashTurnover = Double.parseDouble(nvl(iform.getValue("Monthly_expected_turnover_Cash")));
			} catch (Exception e) {
				cashTurnover = 0.0;
			}

			double perc = 0.0;

			// ✅ UPDATED FORMULA (percentage)
			if (salary > 0) {
				perc = (cashTurnover / salary) * 100;
			}

			// ✅ HARD VALIDATION (MANDATORY)
			if (perc < 0) {
				perc = 0;
			} else if (perc > 100) {
				perc = 100;
			}

			// ✅ ROUND TO 2 DECIMAL
			perc = Math.round(perc * 100.0) / 100.0;

			arr.put(perc);

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] CashTurnoverPerc (Percentage): " + perc);

		} catch (Exception e) {

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error calculating CashTurnoverPerc. Defaulting to 0", e);
			arr.put(0);
		}

		return arr;
	}

	private String getLengthOfResidency(IFormReference iform, String wiName) {

		try {

			String input = nvl(iform.getValue("LengthofResidency")); // MM.YYYY

			if (input.isEmpty() || !input.contains(".")) {
				return "";
			}

			String[] parts = input.split("\\.");

			int inputMonth = Integer.parseInt(parts[0]);
			int inputYear = Integer.parseInt(parts[1]);

			Date currentDate = new Date();
			SimpleDateFormat sdfMonth = new SimpleDateFormat("MM");
			SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy");

			int currentMonth = Integer.parseInt(sdfMonth.format(currentDate));
			int currentYear = Integer.parseInt(sdfYear.format(currentDate));

			// Calculate difference
			int totalMonths = (currentYear - inputYear) * 12 + (currentMonth - inputMonth);

			if (totalMonths < 0) {
				totalMonths = 0;
			}

			int years = totalMonths / 12;
			int months = totalMonths % 12;

			// Format → MM.YY
			String result = String.format("%02d.%02d", months, years);

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] LengthOfResidency: " + result);
			String customerType = nvl(iform.getValue("Customer_Type"));
			if ("NR".equalsIgnoreCase(customerType)) {
				result = "00.00";
			}

			return result;

		} catch (Exception e) {

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error in LengthOfResidency", e);
			return "";
		}
	}

	private String getCustomerName(IFormReference iform, String wiName) {

		try {

			String firstName = nvl(iform.getValue("Given_Name"));
			String middleName = nvl(iform.getValue("Middle_Name"));
			String lastName = nvl(iform.getValue("Surname"));

			String customerName;

			// Build Full Name
			if (middleName.isEmpty()) {
				customerName = firstName + " " + lastName;
			} else {
				customerName = firstName + " " + middleName + " " + lastName;
			}

			// Trim extra spaces
			customerName = customerName.trim().replaceAll("\\s+", " ");

			// Length restriction (300 chars)
			if (customerName.length() > 300) {
				customerName = customerName.substring(0, 300);
				DigitalAO.mLogger.warn("[CRAM][" + wiName + "] CustomerName trimmed to 300 chars");
			}

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] CustomerName: " + customerName);

			return customerName;

		} catch (Exception e) {

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error building CustomerName", e);
			return "";
		}
	}

	private String getCifCreationDateFromDB(IFormReference iform, String wiName) {

		String cifDate = "";

		try {

			String cif = nvl(iform.getValue("CIF"));

			String query = "SELECT TOP 1 CIF_CREATED_DATE " + "FROM NG_DAO_CUSTOMER_SUMMARY WITH (NOLOCK) "
					+ "WHERE WI_NAME='" + wiName + "' " + "AND CIF_ID='" + cif + "' "
					+ "ORDER BY CIF_CREATED_DATE DESC";

			List<List<String>> result = iform.getDataFromDB(query);

			if (result != null && result.size() > 0) {

				cifDate = result.get(0).get(0);

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] CIF=" + cif + ", CIF Creation Date=" + cifDate);
			}

		} catch (Exception e) {
			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error fetching CIFCreationDate from DB", e);
		}

		return nvl(cifDate);
	}

	private void insertRiskSheetData(IFormReference iform, String wiName, JSONObject req, String response) {

		long startTime = System.currentTimeMillis();

		try {

			String cabinetName = getCabinetName(iform);
			String sessionID = getSessionId(iform);
			String serverIp = iform.getServerIp();
			String serverPort = iform.getServerPort();

			// SAFE FUNCTION (escape + trim)
			java.util.function.Function<String, String> safe = val -> val == null ? "" : val.replace("'", "''").trim();

			// ARRAY → CSV FUNCTION
			java.util.function.Function<JSONArray, String> toCSV = arr -> {
				if (arr == null || arr.length() == 0)
					return "";
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < arr.length(); i++) {
					if (i > 0)
						sb.append(",");
					sb.append(arr.optString(i));
				}
				return sb.toString();
			};

			// FORM VALUES
			String CIF = safe.apply(nvl(iform.getValue("CIF")));
			String name = safe.apply(nvl(iform.getValue("Given_Name")) + " " + nvl(iform.getValue("Surname")));

			// Response values will be populated from CRAM response
			String persona = "";
			String product = "";
			String currency = safe.apply(toCSV.apply(req.optJSONArray("currency")));
			String cashRisk = "";
			String pepStatus = "";

			String maturity = "";
			String lengthResidency = "";

			// FORM EXTRA
			String countryOfBirth = "";
			String avgTxn = "";
			String nationality = "";
			String demographic = "";
			String industry = "";
			String deliveryChannel = "";

			// RESPONSE SAFE PARSE
			String score = "0";
			String riskType = "";
			String adverseMedia = "";
			String personalAccountFlag = "";
			String sarFlag = "";
			String nonResident = "";
			String hnwiFlag = "";

			try {
				JSONObject res = new JSONObject(response);
				score = safe.apply(String.valueOf(res.optDouble("totalRiskScore", 0.0)));
				riskType = safe.apply(res.optString("riskCategory", ""));
				// added
				JSONObject riskInfo = res.optJSONObject("riskScoreInfo");

				if (riskInfo != null) {

					persona = safe.apply(riskInfo.optString("persona"));
					product = safe.apply(riskInfo.optString("product"));
					currency = safe.apply(riskInfo.optString("currency"));
					cashRisk = safe.apply(riskInfo.optString("cashTurnoverPerc"));
					pepStatus = safe.apply(riskInfo.optString("pepStatus"));

					maturity = safe.apply(riskInfo.optString("maturityRelationship"));
					lengthResidency = safe.apply(riskInfo.optString("lengthOfResidency"));

					countryOfBirth = safe.apply(riskInfo.optString("countryOfBirth"));
					avgTxn = safe.apply(riskInfo.optString("annualTurnoverExpected"));
					nationality = safe.apply(riskInfo.optString("nationality"));
					demographic = safe.apply(riskInfo.optString("demographic"));
					industry = safe.apply(riskInfo.optString("industry"));
					deliveryChannel = safe.apply(riskInfo.optString("deliveryChannel"));
					DigitalAO.mLogger.info("[RISK_SHEET][" + wiName + "] Response Values => Persona=" + persona
							+ ", Product=" + product + ", Currency=" + currency + ", CashRisk=" + cashRisk
							+ ", PepStatus=" + pepStatus + ", Maturity=" + maturity + ", LengthResidency="
							+ lengthResidency + ", CountryOfBirth=" + countryOfBirth + ", AvgTxn=" + avgTxn);
					DigitalAO.mLogger.info("[RISK_SHEET][" + wiName + "] Nationality=" + nationality + ", Demographic="
							+ demographic + ", Industry=" + industry);
					adverseMedia = safe.apply(riskInfo.optString("adverseMediaResults"));
					personalAccountFlag = safe
							.apply(riskInfo.optString("personalAccountsUtilizedForCommercialActivity"));
					sarFlag = safe.apply(riskInfo.optString("customerReportedToRegulator"));
					nonResident = safe.apply(riskInfo.optString("nonResidentUboOrCustomer"));
					hnwiFlag = safe.apply(riskInfo.optString("hnwi"));

					DigitalAO.mLogger.debug("[RISK_SHEET][" + wiName + "] adverseMediaResults: " + adverseMedia);
					DigitalAO.mLogger
							.debug("[RISK_SHEET][" + wiName + "] personalAccountsFlag: " + personalAccountFlag);
					DigitalAO.mLogger.debug("[RISK_SHEET][" + wiName + "] SAR/STR Flag: " + sarFlag);
					DigitalAO.mLogger.debug("[RISK_SHEET][" + wiName + "] nonResidentIndicator: " + nonResident);
				} else {
					DigitalAO.mLogger.warn("[RISK_SHEET][" + wiName + "] riskScoreInfo is NULL in response");
				}
			} catch (Exception ex) {
				DigitalAO.mLogger.warn("[RISK_SHEET][" + wiName + "] Response parsing failed");
			}

			// DELETE OLD RECORD
			String whereClause = "WI_NAME='" + wiName + "'";

			String deleteInputXML = DigitalAO_Common.apDeleteInput(cabinetName, sessionID, "NG_DAO_RISK_SHEET_DATA",
					whereClause);

			String deleteResp = WFNGExecute(deleteInputXML, serverIp, serverPort, 1);

			DigitalAO.mLogger.debug("[RISK_SHEET][DELETE-RESP] " + deleteResp);

			// COLUMNS
			String cols = "WI_NAME,CIF_ID,CUSTOMER_NAME,PERSONA,PRODUCT_TYPE,CURRENCY,"
					+ "CASH_RISK,LENGTH_OF_RESIDENCY,MATURITY_RELATIONSHIP,COUNTRY_OF_BIRTH,"
					+ "AVG_EXPECTED_TXN,HNWI_FLAG,DELIVERY_CHANNEL,RISK_SCORE,RISK_TYPE,"
					+ "ADVERSE_MEDIA_FLAG,PERSONAL_ACCOUNT_FLAG,SAR_FLAG,NON_RESIDENT_FLAG,PEP_STATUS,"
					+ "NATIONALITY,DEMOGRAPHIC,INDUSTRY";

			// VALUES
			String vals = "'" + wiName + "'," + "'" + CIF + "'," + "'" + name + "'," + "'" + persona + "'," + "'"
					+ product + "'," + "'" + currency + "'," + "'" + cashRisk + "'," + "'" + lengthResidency + "',"
					+ "'" + maturity + "'," + "'" + countryOfBirth + "'," + "'" + avgTxn + "'," + "'" + hnwiFlag + "',"
					+ "'" + deliveryChannel + "'," + "'" + score + "'," + "'" + riskType + "'," + "'" + adverseMedia
					+ "'," + "'" + personalAccountFlag + "'," + "'" + sarFlag + "'," + "'" + nonResident + "'," + "'"
					+ pepStatus + "'," + "'" + nationality + "'," + "'" + demographic + "'," + "'" + industry + "'";

			DigitalAO.mLogger.debug("[RISK_SHEET][INSERT-VALUES] " + vals);

			// INSERT
			String inXML = DigitalAO_Common.apInsert(cabinetName, sessionID, cols, vals, "NG_DAO_RISK_SHEET_DATA");

			String outXML = WFNGExecute(inXML, serverIp, serverPort, 1);

			DigitalAO.mLogger.debug("[RISK_SHEET][INSERT-RESP] " + outXML);

			XMLParser parser = new XMLParser(outXML);
			String mainCode = parser.getValueOf("MainCode");

			long duration = System.currentTimeMillis() - startTime;

			if ("0".equals(mainCode)) {
				DigitalAO.mLogger.info("[RISK_SHEET][" + wiName + "] Insert success | Duration=" + duration + "ms");
			} else {
				DigitalAO.mLogger.error("[RISK_SHEET][" + wiName + "] Insert failed | Response=" + outXML);
			}

		} catch (Exception e) {
			DigitalAO.mLogger.error("[RISK_SHEET][" + wiName + "] Exception in insertRiskSheetData", e);
		}
	}

	private JSONArray getCramProductList(IFormReference iform, String wiName, String isNtb) {

		JSONArray productList = new JSONArray();

		try {

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] ----- START getCramProductList -----");

			// GET APPLIED PRODUCT (FROM FORM)
			String productTyp = nvl(iform.getValue("product_type"));
			DigitalAO.mLogger.info("[CRAM][" + wiName + "] product_type (from form): " + productTyp);

			String appliedProduct = "";

			// ✅ DIRECT MAPPING (NO DB - FIX)
			if (productTyp.toLowerCase().contains("current")) {
				appliedProduct = "PBCA";
				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Mapping CURRENT → PBCA");

			} else if (productTyp.toLowerCase().contains("saving")) {
				appliedProduct = "SAVAC";
				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Mapping SAVING → SAVAC");
			}

			// fallback
			if (appliedProduct.isEmpty()) {
				appliedProduct = "N";
				DigitalAO.mLogger.warn("[CRAM][" + wiName + "] Applied product empty → default NA");
			}

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Final Applied Product: " + appliedProduct);

			// ===============================
			// NTB LOGIC
			// ===============================
			// if ("Y".equalsIgnoreCase(isNtb)) {
			boolean isNtbFlow = "Y".equalsIgnoreCase(isNtb)
					&& !"Y".equalsIgnoreCase(nvl(iform.getValue("Dedupe_Match_found")));

			if (isNtbFlow) {
				DigitalAO.mLogger
						.info("[CRAM][" + wiName + "] Product Logic -> isNtb=" + isNtb + ", Dedupe_Match_found="
								+ nvl(iform.getValue("Dedupe_Match_found")) + ", isNtbFlow=" + isNtbFlow);
				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Customer Type: NTB");

				productList.put(appliedProduct);
				DigitalAO.mLogger.info("[CRAM][" + wiName + "] NTB Product Added: " + appliedProduct);

			} else {

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Customer Type: ETB");

				// ETB LOGIC → EXISTING + APPLIED
				JSONArray existingProducts = getProductFromDB(iform, wiName);
				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Existing Products from DB: " + existingProducts);

				// use set-like logic (avoid duplicates)
				java.util.Set<String> productSet = new java.util.HashSet<>();

				// existing
				if (existingProducts != null) {
					for (int i = 0; i < existingProducts.length(); i++) {
						String p = existingProducts.optString(i);
						if (!p.isEmpty()) {
							productSet.add(p);
							DigitalAO.mLogger.debug("[CRAM][" + wiName + "] Added existing product to set: " + p);
						}
					}
				}

				// applied
				if (!appliedProduct.isEmpty()) {
					productSet.add(appliedProduct);
					DigitalAO.mLogger.debug("[CRAM][" + wiName + "] Added applied product to set: " + appliedProduct);
				}

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Final Product Set: " + productSet);

				// convert set → JSON
				for (String p : productSet) {
					productList.put(p);
				}

				// fallback
				if (productList.length() == 0) {
					productList.put(JSONObject.NULL);
					DigitalAO.mLogger.warn("[CRAM][" + wiName + "] ETB Product empty → default NULL");
				}

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Final ETB Product List: " + productList);
			}

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] ----- END getCramProductList -----");

		} catch (Exception e) {
			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error in product building", e);

			// absolute fallback
			productList.put("N");
		}

		return productList;
	}

	private JSONArray getIndustryClmCode(IFormReference iform, String wiName) {

		JSONArray industryArr = new JSONArray();
		Set<String> uniqueIndustryCodes = new LinkedHashSet<String>();

		try {

			// for self employed case
			String empType = nvl(iform.getValue("employement_type")); // confirm field name

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Employment Type: " + empType);

			if (empType.equalsIgnoreCase("Self employed")) {

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Self Employed case → using company grid");

				int compnay_grid = iform.getDataFromGrid("company_detail").size();

				for (int i = 0; i < compnay_grid; i++) {

					String industry_value = nvl(iform.getTableCellValue("company_detail", i, 3));

					if (industry_value.isEmpty())
						continue;

					String query = "SELECT clm_code FROM NG_DAO_RCC_Industry_master WITH (NOLOCK) "
							+ "WHERE (UPPER(LTRIM(RTRIM(description))) = UPPER(LTRIM(RTRIM('"
							+ industry_value.replace("'", "''") + "'))) "
							+ "OR UPPER(LTRIM(RTRIM(code))) = UPPER(LTRIM(RTRIM('" + industry_value.replace("'", "''")
							+ "')))) " + "AND isActive = 'Y'";

					List<List<String>> result = iform.getDataFromDB(query);

					if (result != null && !result.isEmpty()) {

						for (List<String> row : result) {

							String clmCode = nvl(row.get(0));

							if (!clmCode.isEmpty() && uniqueIndustryCodes.add(clmCode)) {
								industryArr.put(clmCode);
							}
						}
					}
				}

				if (industryArr.length() == 0) {
					industryArr.put("N");
				}

				return industryArr; // ✅ IMPORTANT EXIT
			}
			// ✅ ADD THIS BLOCK HERE (END)

			// non self employed
			String industryDesc = nvl(iform.getValue("industry_subsegment"));

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Industry Description from form: " + industryDesc);

			if (industryDesc.isEmpty()) {
				DigitalAO.mLogger.warn("[CRAM][" + wiName + "] Industry description empty → sending NA");
				industryArr.put("N");
				return industryArr;
			}

			String industryValue = industryDesc.replace("'", "''");

			String query = "SELECT TOP 1 clm_code FROM NG_DAO_RCC_Industry_master WITH (NOLOCK) "
					+ "WHERE (description = '" + industryValue + "' " + "OR code = '" + industryValue + "') "
					+ "AND isActive = 'Y'";

			DigitalAO.mLogger.debug("[CRAM][" + wiName + "] Industry Query: " + query);

			List<List<String>> result = iform.getDataFromDB(query);

			if (result != null && !result.isEmpty()) {

				for (List<String> row : result) {

					if (row != null && !row.isEmpty()) {

						String clmCode = nvl(row.get(0));

						if (!clmCode.isEmpty() && uniqueIndustryCodes.add(clmCode)) {
							industryArr.put(clmCode);
						}
					}
				}

				// ✅ safety fallback
				if (industryArr.length() == 0) {
					industryArr.put("N");
					DigitalAO.mLogger.warn("[CRAM][" + wiName + "] CLM code empty after fetch → NA");
				}

			} else {

				industryArr.put("N");
				DigitalAO.mLogger.warn("[CRAM][" + wiName + "] No CLM mapping found → NA");
			}

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Final Industry CLM Code: " + industryArr);

		} catch (Exception e) {

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error in getIndustryClmCode", e);

			industryArr = new JSONArray();
			industryArr.put("N"); // ✅ fail-safe
		}

		return industryArr;
	}

	private JSONArray toJsonArraySplitSafe(Object value) {

		JSONArray arr = new JSONArray();

		try {
			if (value != null && !value.toString().trim().isEmpty()) {

				java.util.Set<String> unique = new java.util.LinkedHashSet<>();

				String[] values = value.toString().split(",");

				for (String v : values) {

					String code = v.trim();

					if (!code.isEmpty()) {
						unique.add(code); // ✅ removes duplicates
					}
				}

				for (String code : unique) {
					arr.put(code);
				}
			}

		} catch (Exception e) {
			DigitalAO.mLogger.error("Error in toJsonArraySplitSafe", e);
		}

		return arr;
	}

	private JSONArray getFinalNationality(IFormReference iform, String wiName) {

		JSONArray arr = new JSONArray();

		try {

			String primary = nvl(iform.getValue("Nationality"));
			String secondary = nvl(iform.getValue("Secondary_Nationality"));

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Primary Nationality: " + primary);
			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Secondary Nationality: " + secondary);

			// ✅ Use Set to avoid duplicates
			java.util.Set<String> unique = new java.util.LinkedHashSet<>();

			// ✅ FUNCTION to process comma-separated values
			java.util.function.Consumer<String> process = (val) -> {
				if (val != null && !val.trim().isEmpty()) {

					String[] split = val.split(",");

					for (String s : split) {

						String code = s.trim();

						if (!code.isEmpty()) {
							unique.add(code);
						}
					}
				}
			};

			// Add both fields
			process.accept(primary);
			process.accept(secondary);

			// Convert to JSONArray
			for (String code : unique) {
				arr.put(code);
			}

			// FINAL CHECK
			if (arr.length() == 0) {
				DigitalAO.mLogger.warn("[CRAM][" + wiName + "] No nationality found → NOT sending field");
				return null; // IMPORTANT → do not send
			}

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Final Nationality Payload: " + arr);

		} catch (Exception e) {
			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error in getFinalNationality", e);
			return null; // safest fallback
		}

		return arr;
	}

	private JSONArray getFinalDemographic(IFormReference iform, String wiName) {

		JSONArray arr = new JSONArray();

		try {

			String formDemographic = nvl(iform.getValue("Money_send_and_received_Countries_final_IBPS"));

			if (formDemographic != null && !formDemographic.trim().isEmpty()) {

				String[] splitValues = formDemographic.split(",");

				for (String s : splitValues) {

					String code = s.trim();

					if (code.isEmpty() || "N".equalsIgnoreCase(code))
						continue;

					boolean exists = false;

					for (int i = 0; i < arr.length(); i++) {
						if (code.equalsIgnoreCase(arr.optString(i))) {
							exists = true;
							break;
						}
					}

					if (!exists) {
						arr.put(code);
					}
				}
			}

			String empType = nvl(iform.getValue("employement_type"));

			if ("Self employed".equalsIgnoreCase(empType)) {

				int gridSize = iform.getDataFromGrid("company_detail").size();

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] Self Employed → Processing Grid: " + gridSize);

				for (int i = 0; i < gridSize; i++) {

					String countries = nvl(iform.getTableCellValue("company_detail", i, 8));

					if (countries.isEmpty())
						continue;

					String[] splitCountries = countries.split(",");

					for (String s : splitCountries) {

						String code = s.trim();

						if (code.isEmpty())
							continue;

						// ✅ FETCH VALID CM_CODE (same logic you used)
						String query = "SELECT CM_CODE FROM NG_MASTER_DAO_COUNTRY_OF_RESIDENCE WITH (NOLOCK) "
								+ "WHERE UPPER(CM_CODE) = UPPER('" + code.replace("'", "''") + "')";

						List<List<String>> result = iform.getDataFromDB(query);

						if (result != null && !result.isEmpty()) {

							String cmCode = nvl(result.get(0).get(0));

							if (cmCode.isEmpty())
								continue;

							boolean exists = false;

							for (int j = 0; j < arr.length(); j++) {
								if (cmCode.equalsIgnoreCase(arr.optString(j))) {
									exists = true;
									break;
								}
							}

							if (!exists) {
								arr.put(cmCode);
							}

						} else {
							DigitalAO.mLogger.warn("[CRAM][" + wiName + "] No CM_CODE found for: " + code);
						}
					}
				}
			}

			if (arr.length() == 0) {
				arr.put("N");
				DigitalAO.mLogger.warn("[CRAM][" + wiName + "] Demographic empty → sending NA");
			}

			DigitalAO.mLogger.info("[CRAM][" + wiName + "] Final Demographic: " + arr);

		} catch (Exception e) {

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error in getFinalDemographic", e);

			arr = new JSONArray();
			arr.put("N");
		}

		return arr;
	}

	private String getPepCode(IFormReference iform, String pepDesc, String wiName) {

		try {

			if (pepDesc == null || pepDesc.trim().isEmpty()) {
				return "NPEP";
			}

			String query = "SELECT TOP 1 CM_CODE " + "FROM NG_MASTER_DAO_PEP_VALUE WITH (NOLOCK) "
					+ "WHERE UPPER(CM_DESC)=UPPER('" + pepDesc.replace("'", "''") + "')";

			List<List<String>> result = iform.getDataFromDB(query);

			if (result != null && !result.isEmpty()) {

				String code = nvl(result.get(0).get(0));

				DigitalAO.mLogger.info("[CRAM][" + wiName + "] PEP Desc=" + pepDesc + ", PEP Code=" + code);

				return code;
			}

		} catch (Exception e) {

			DigitalAO.mLogger.error("[CRAM][" + wiName + "] Error fetching PEP Code", e);
		}

		return "NPEP";
	}

}
