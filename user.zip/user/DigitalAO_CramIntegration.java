package com.newgen.iforms.user;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.json.JSONObject;

import com.newgen.iforms.custom.IFormReference;

public class DigitalAO_CramIntegration extends DigitalAO_Common {

    public String callCramGateway(String requestBody, String requestId, IFormReference iform) throws Exception {

        String wiName = getWorkitemName(iform);
        DigitalAO.mLogger.info("[CRAM-Int][" + wiName + "] Initializing CRAM API call");

    
        Map<String, String> config = fetchConfigFromDB(iform);
        DigitalAO.mLogger.debug("[CRAM-Int][" + wiName + "] Config fetched successfully");

        DigitalAO.mLogger.info("[CRAM-Int][" + wiName + "] SSL not required. Using direct API call.");

       
        String token = null;

        if ("Y".equalsIgnoreCase(config.get("TOKEN_REQUIRED"))) {
            DigitalAO.mLogger.info("[CRAM-Int][" + wiName + "] Token required. Fetching...");
            token = getAuthToken(iform, config);
        } else {
            DigitalAO.mLogger.info("[CRAM-Int][" + wiName + "] Token NOT required.");
        }

        DigitalAO.mLogger.info("[CRAM-Int][" + wiName + "] Calling CRAM endpoint");

        URL url = new URL(config.get("cramURL"));
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setRequestMethod("POST");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(30000);

        // Kong Authentication
        conn.setRequestProperty("apikey", config.get("cramAPIKey"));

     
        if (token != null) {
            conn.setRequestProperty("Authorization", "Bearer " + token);
        }

        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(requestBody.getBytes("UTF-8"));
            DigitalAO.mLogger.debug("[CRAM-Int][" + wiName + "] Request JSON payload streamed.");
        }

        int status = conn.getResponseCode();
        DigitalAO.mLogger.info("[CRAM-Int][" + wiName + "] CRAM API Response Code: " + status);

        InputStream is = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder responseBody = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
			responseBody.append(line.trim());
		}
        conn.disconnect();

        // audit in  NG_DAO_XMLLOG_HISTORY
        insertCramAudit(iform, requestBody, responseBody.toString(), requestId, status, wiName);

        return responseBody.toString();
    }

    private void loadSSL(String wiName, String pwd) throws Exception {
        // Updated to point to your WAR structure: DAO.war/WEB-INF/Certificates/
        String jksPath = System.getProperty("user.dir") + File.separator + "WEB-INF" + File.separator + "Certificates" + File.separator + "KongSSL.jks";
        DigitalAO.mLogger.debug("[CRAM-SSL][" + wiName + "] Accessing JKS at: " + jksPath);

        File jksFile = new File(jksPath);
        if (!jksFile.exists()) {
            DigitalAO.mLogger.error("[CRAM-SSL][" + wiName + "] File not found at provided path.");
            throw new FileNotFoundException("JKS Missing: " + jksPath);
        }

        KeyStore ks = KeyStore.getInstance("JKS");
        try (FileInputStream fis = new FileInputStream(jksFile)) {
            ks.load(fis, pwd.toCharArray());
        }

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ks);
        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, tmf.getTrustManagers(), new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        DigitalAO.mLogger.info("[CRAM-SSL][" + wiName + "] SSL Socket Factory initialized.");
    }

    private String getAuthToken(IFormReference iform, Map<String, String> config) throws Exception {
        URL url = new URL(config.get("Kong_Token_Endpoint"));
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        conn.setRequestProperty("apikey", config.get("cramAPIKey"));
        conn.setDoOutput(true);

        String params = "grant_type=client_credentials&client_id=" + config.get("Kong_API_client_id") +
                        "&client_secret=" + config.get("Kong_API_client_secret");

        try (OutputStream os = conn.getOutputStream()) {
            os.write(params.getBytes("UTF-8"));
        }

        if (conn.getResponseCode() != 200) {
            DigitalAO.mLogger.error("[CRAM-Token] Failed status: " + conn.getResponseCode());
            throw new Exception("SAS Token Error");
        }

        JSONObject json = new JSONObject(readStream(conn.getInputStream()));
        return json.getString("access_token");
    }

    private Map<String, String> fetchConfigFromDB(IFormReference iform) {
        Map<String, String> configMap = new HashMap<>();
        String query = "SELECT CONST_FIELD_NAME,CONST_FIELD_VALUE FROM USR_0_BPM_CONSTANTS";
        List<List<String>> result = iform.getDataFromDB(query);
        if (result != null) {
            for (List<String> row : result) { configMap.put(row.get(0), row.get(1)); }
        }
        return configMap;
    }

    private void insertCramAudit(IFormReference iform, String req, String res, String msgId, int status, String wi) {

        DigitalAO.mLogger.info("[CRAM-Audit] Entering insertCramAudit()");
        DigitalAO.mLogger.debug("[CRAM-Audit] WI: " + wi + ", MsgId: " + msgId + ", Status: " + status);

        try {
        	String workstepName = getActivityName(iform);
        	String userName = getUserName(iform);

            //  handling of null values
            String safeReq = (req != null) ? req.replace("'", "''") : "";
            String safeRes = (res != null) ? res.replace("'", "''") : "";

            DigitalAO.mLogger.debug("[CRAM-Audit] Request Payload: " + safeReq);
            DigitalAO.mLogger.debug("[CRAM-Audit] Response Payload: " + safeRes);
            String col = "WI_NAME,WORKSTEP_NAME,INPUT_XML,OUTPUT_XML,MESSAGE_ID,REQ_DATE_TIME,ACT_DATE_TIME,CALLNAME,USER_NAME";
           
            String reqDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());



            String val = "'" + wi + "','" + workstepName + "','" + safeReq + "','" + safeRes + "','" + msgId + "','" +
            		reqDateTime + "',GETDATE(),'CRAM_RISK_SCORE','" + userName + "'";


            
            DigitalAO.mLogger.info("[CRAM-Audit] Preparing insert query");

            String insertXml = apInsert(
                    getCabinetName(iform),
                    getSessionId(iform),
                    col,
                    val,
                    "NG_DAO_XMLLOG_HISTORY"
            );

            DigitalAO.mLogger.debug("[CRAM-Audit] Insert XML: " + insertXml);

            String response = WFNGExecute(insertXml, iform.getServerIp(), iform.getServerPort(), 1);

            DigitalAO.mLogger.info("[CRAM-Audit] Insert executed successfully");
            DigitalAO.mLogger.debug("[CRAM-Audit] WF Response: " + response);

        } catch (Exception e) {
            DigitalAO.mLogger.error("[CRAM-Audit] Exception in insertCramAudit()", e);
        }

        DigitalAO.mLogger.info("[CRAM-Audit] Exiting insertCramAudit()");
    }

    private String readStream(InputStream is) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
			sb.append(line);
		}
        return sb.toString();
    }
}
