package com.newgen.iforms.user;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.newgen.iforms.custom.IFormReference;

public class DigitalAO_Click extends DigitalAO_Common {

	public String clickEvent(IFormReference iform, String controlName, String data) throws FileNotFoundException, IOException, ParserConfigurationException, SAXException {
		DigitalAO.mLogger.debug("DigitalAO_Clicks");
		DigitalAO.mLogger.debug("WINAME : " + getWorkitemName(iform) + ", WSNAME: " + getActivityName(iform) + ", controlName " + controlName + ", data " + data);
		DigitalAO.mLogger.debug("controlName" + controlName);
		String successIndicator = "FAIL";

		if (controlName.equalsIgnoreCase("template_generate"))
		{
			return new DAOTemplate().clickEvent(iform, "template_generate", data);

		} else if (controlName.equalsIgnoreCase("Risk_score_trigger"))
		{
			DigitalAO.mLogger.debug("RISK_SCORE_DETAILS : Click: ");
			String currDate = new SimpleDateFormat("dd/MM/YYYY").format(new Date());
			DigitalAO.mLogger.debug("currDate KYC : " + currDate);
			setControlValue("KYC_review_Date", currDate, iform);

			return new DigitalAO_Integration().onclickevent(iform, controlName, data);

		} else if (controlName.equalsIgnoreCase("sign_upload"))
		{
			return new DigitalAO_Integration().onclickevent(iform, controlName, data);
		}
		else if (controlName.equalsIgnoreCase("CIF_update"))
		{
			return new DigitalAO_Integration().onclickevent(iform, controlName, data);
		}else if(controlName.equalsIgnoreCase("Generate_firco_temp"))
		{
			return new DAOTemplate().clickEvent(iform, "Generate_firco_temp", data);
		}
		//added by gaurav for dedupe template
		else if(controlName.equalsIgnoreCase("template_generate_dedupe"))
		{
			return new DAOTemplate().clickEvent(iform, "template_generate_dedupe", data);
		}
		//REPLACING WIH CRAM
//		else if(controlName.equalsIgnoreCase("Generate_RiskScore")){
//			return new DAOTemplate().clickEvent(iform, "Generate_RiskScore", data);
//		}

		//vinayak chnage starts internal exposure
		else if(controlName.equalsIgnoreCase("InternalExposure"))
		{
			return new DigitalAO_InternalExposure().onclickevent(iform, "InternalExposure", data);
		}
//		// Inside DigitalAO_Click.java -> onclickevent()
//		else if (controlName.equalsIgnoreCase("Generate_RiskScore"))
//		{
//		    DigitalAO.mLogger.info("[Click-Event] Routing manual risk trigger to DAOTemplate.");
//
//		    // Business Rule: Standard KYC Date update
//		    String currDate = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
//		    iform.setValue("KYC_review_Date", currDate);
//
//		    // DELEGATED CALL: Triggers the logic inside the Template class
//		    return new DAOTemplate().clickEvent(iform, "Generate_RiskScore", data);
//		}
		//CRAM SWITCHING 
		else if (controlName.equalsIgnoreCase("Generate_RiskScore"))
		{
		    String currDate = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		    iform.setValue("KYC_review_Date", currDate);

		    String cramFlag = getCramSwitchFlag(iform);

		    DigitalAO.mLogger.info(
		            "[DAO_CRAM_SWITCH] WI : "
		            + getWorkitemName(iform)
		            + ", Flag : "
		            + cramFlag);

		    if ("Y".equalsIgnoreCase(cramFlag))
		    {
		        DigitalAO.mLogger.info(
		                "[DAO_CRAM_SWITCH] Routing request to CRAM");

		        return new DigitalAO_CramLogic()
		                .triggerRiskCalculation(iform);
		    }
		    else
		    {
		        DigitalAO.mLogger.info(
		                "[DAO_CRAM_SWITCH] Routing request to Existing Risk API");

		        return new DAOTemplate()
		                .clickEvent(iform,
		                        "Generate_RiskScore",
		                        data);
		    }
		}
		
		else if(controlName.equalsIgnoreCase("AccountSummary"))
		{
			return new DigitalAO_AccountSummary().onclickevent(iform, "AccountSummary", data);
		}
		else if(controlName.equalsIgnoreCase("CustomerSummary"))
		{
			return new DigitalAO_CustomerSummary().onclickevent(iform, "CustomerSummary", data);
		}
		

		return successIndicator;
	}

	private String getCramSwitchFlag(IFormReference iform)
	{
	    try
	    {
	        String query =
	            "SELECT CONST_FIELD_VALUE " +
	            "FROM USR_0_BPM_CONSTANTS WITH (NOLOCK) " +
	            "WHERE CONST_FIELD_NAME='DAO_CRAM_SWITCH'";

	        List<List<String>> result = iform.getDataFromDB(query);

	        if (result != null && !result.isEmpty())
	        {
	            return result.get(0).get(0);
	        }
	    }
	    catch (Exception e)
	    {
	        DigitalAO.mLogger.error("[DAO_CRAM_SWITCH] Error fetching switch flag", e);
	    }

	    return "N";
	}


}
