package com.newgen.iforms.user;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

public class DigitalAO_CustomerSummary extends DigitalAO_Common {

    private static NGEjbClient ngEjbClient;

    public String onclickevent(IFormReference iform, String control, String data) {

        DigitalAO.mLogger.info("Entered onclickevent method");

        try {
            ngEjbClient = NGEjbClient.getSharedInstance();

            String wi_name = getWorkitemName(iform);
            String sessionID = getSessionId(iform);
            String cabinetName = getCabinetName(iform);
            String userName = getUserName(iform);
            String serverIp = iform.getServerIp();
            String serverPort = iform.getServerPort();

            DigitalAO.mLogger.info("WI_Name: " + wi_name + ", User: " + userName);

            String cifId = (String) iform.getValue("CIF");
            DigitalAO.mLogger.info("CIF fetched from form: " + cifId);

            int timeout = 60;
            int waitTime = 65;

            HashMap<String, String> socketDetails =
                    socketConnectionDetails(cabinetName, serverIp, serverPort, sessionID);

            if (socketDetails.isEmpty()) {
                DigitalAO.mLogger.error("Socket details are empty, cannot proceed");
                return "NotInserted";
            }

            DigitalAO.mLogger.info("Socket details fetched successfully");

            StringBuilder requestXml = buildCustomerRequest(cifId);
            DigitalAO.mLogger.info("CustomerSummary Request XML: " + requestXml);

            String responseXML = socketConnection(
                    cabinetName, userName, sessionID,
                    serverIp, serverPort,
                    wi_name, "CustomerSummary",
                    timeout, waitTime,
                    requestXml, socketDetails
            );

            DigitalAO.mLogger.info("CustomerSummary Response XML: " + responseXML);

            if (responseXML == null || !responseXML.contains("<CIFDet")) {
                DigitalAO.mLogger.error("Invalid response received from CustomerSummary API");
                return "NotInserted";
            }

            String result = parseCustomerSummary(
                    responseXML, wi_name, sessionID,
                    cabinetName, cifId, serverIp, serverPort
            );

            DigitalAO.mLogger.info("Parse result: " + result);

            if ("true".equalsIgnoreCase(result)) {
                DigitalAO.mLogger.info("CustomerSummary inserted successfully for WI: " + wi_name);
                return "Inserted";
            } else {
                DigitalAO.mLogger.error("CustomerSummary insert failed for WI: " + wi_name);
                return "NotInserted";
            }

        } catch (Exception e) {
            DigitalAO.mLogger.error("CustomerSummary Exception", e);
            return "NotInserted";
        }
    }

    /* ================= BUILD REQUEST ================= */
    private static StringBuilder buildCustomerRequest(String cifId) {

        Date d = new Date();
        String extra2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(d) + "+04:00";

        StringBuilder sb = new StringBuilder();

        sb.append("<EE_EAI_MESSAGE>")
          .append("<EE_EAI_HEADER>")
          .append("<MsgFormat>CUSTOMER_DETAILS</MsgFormat>")
          .append("<MsgVersion>0000</MsgVersion>")
          .append("<RequestorChannelId>BPM</RequestorChannelId>")
          .append("<RequestorUserId>RAKUSER</RequestorUserId>")
          .append("<RequestorLanguage>E</RequestorLanguage>")
          .append("<RequestorSecurityInfo>secure</RequestorSecurityInfo>")
          .append("<ReturnCode>911</ReturnCode>")
          .append("<ReturnDesc>Issuer Timeout</ReturnDesc>")
          .append("<MessageId>CUSTOMER_").append(cifId).append("</MessageId>")
          .append("<Extra1>REQ||RAK.VTUSER</Extra1>")
          .append("<Extra2>").append(extra2).append("</Extra2>")
          .append("</EE_EAI_HEADER>")
          .append("<FetchCustomerDetailsReq>")
          .append("<BankId>RAK</BankId>")
          .append("<RCIFID>").append(cifId).append("</RCIFID>")
          .append("<DealProdType>A</DealProdType>")
          .append("<FetchExpired>Y</FetchExpired>")
          .append("</FetchCustomerDetailsReq>")
          .append("</EE_EAI_MESSAGE>");

        return sb;
    }

    private static String parseCustomerSummary(
            String xml,
            String wi_name,
            String sessionID,
            String cabinetName,
            String cifId,
            String serverIp,
            String serverPort) {

        try {

            // Remove illegal nested XML declarations
            xml = xml.replaceAll("<\\?xml.*?\\?>", "");

            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = db.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));

            NodeList list = doc.getElementsByTagName("CIFDet"); // ✅ FIXED TAG

            DigitalAO.mLogger.debug("CIFDet count=" + list.getLength() + " | WI=" + wi_name);

            if (list.getLength() == 0) {
                DigitalAO.mLogger.warn("No CIFDet nodes found | WI=" + wi_name);
                return "false";
            }

            for (int i = 0; i < list.getLength(); i++) {

                Element e = (Element) list.item(i);

                // ✅ Correct field extraction
                String CIFID = getValue(e, "CIFID");
                String status = getValue(e, "CustomerStatus");
                String segment = getValue(e, "CustomerSegment");
                String risk = getValue(e, "RiskProfile");
                String created = getValue(e, "CIFCreatedDate");

                //  Nested values
                String name = getNestedValue(e, "RetAddnlDet", "CustomerName");
                String nationality = getNestedValue(e, "RetAddnlDet", "Nationality");
                String salary = getNestedValue(e, "EmploymentDet", "GrossSal");

                //  Logging fixed
                DigitalAO.mLogger.debug(
                        "\n--- CUSTOMER DETAILS ---" +
                        "\nCIFID            : " + CIFID +
                        "\nCustomerStatus   : " + status +
                        "\nRiskProfile      : " + risk +
                        "\nCustomerSegment  : " + segment +
                        "\nCIFCreatedDate   : " + created +
                        "\nName             : " + name +
                        "\nNationality      : " + nationality +
                        "\nSalary           : " + salary +
                        "\nWI               : " + wi_name
                );

             //  Call correct insert method (updated)
                String insertFlag = insertRow(
                        wi_name,
                        CIFID,
                        status,
                        segment,
                        risk,
                        nationality,
                        name,
                        created,
                        cabinetName,
                        sessionID,
                        serverIp,
                        serverPort
                );
                
                if (!"true".equalsIgnoreCase(insertFlag)) {
                    DigitalAO.mLogger.error("Customer insert failed | WI=" + wi_name + " | CIF=" + CIFID);
                    return "false";
                }
            }

            DigitalAO.mLogger.info("Customer summary parsed successfully | WI=" + wi_name);
            return "true";

        } catch (Exception e) {
            DigitalAO.mLogger.error("Parse exception | WI=" + wi_name, e);
            return "false";
        }
    }
    
    private static String getNestedValue(Element parent, String parentTag, String childTag) {
        NodeList list = parent.getElementsByTagName(parentTag);
        if (list != null && list.getLength() > 0) {
            Element e = (Element) list.item(0);
            NodeList childList = e.getElementsByTagName(childTag);
            if (childList != null && childList.getLength() > 0) {
                return childList.item(0).getTextContent();
            }
        }
        return "";
    }

    /* ================= INSERT ================= */
    private static String insertRow(
            String wi_name,
            String cifId,
            String STATUS,
            String SEGMENT,
            String RISK_PROFILE,
            String NATIONALITY,
            String CUSTOMER_NAME,
            String CIF_CREATED_DATE,
            String cabinetName,
            String sessionID,
            String serverIp,
            String serverPort) {

        long startTime = System.currentTimeMillis();

        try {

            String createdOn = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

            //  SAFE VALUES
            CUSTOMER_NAME = (CUSTOMER_NAME == null) ? "" : CUSTOMER_NAME.trim();
            STATUS = (STATUS == null) ? "" : STATUS.trim();
            SEGMENT = (SEGMENT == null) ? "" : SEGMENT.trim();
            RISK_PROFILE = (RISK_PROFILE == null) ? "0" : RISK_PROFILE.trim();
            NATIONALITY = (NATIONALITY == null) ? "" : NATIONALITY.trim();

            // DATE FIX (only yyyy-MM-dd for DATE column)
            if (CIF_CREATED_DATE != null && CIF_CREATED_DATE.length() >= 10) {
                CIF_CREATED_DATE = CIF_CREATED_DATE.substring(0, 10);
            } else {
                CIF_CREATED_DATE = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            }

            //UPDATED COLUMNS (SALARY REMOVED)
            String cols =
                    "WI_NAME,CIF_ID,CUSTOMER_NAME,STATUS,SEGMENT," +
                    "RISK_PROFILE,NATIONALITY,CIF_CREATED_DATE";

            String vals =
                    "'" + wi_name + "'," +
                    "'" + cifId + "'," +
                    "'" + CUSTOMER_NAME + "'," +
                    "'" + STATUS + "'," +
                    "'" + SEGMENT + "'," +
                    "'" + RISK_PROFILE + "'," +
                    "'" + NATIONALITY + "'," +
                    "'" + CIF_CREATED_DATE + "'";

            DigitalAO.mLogger.debug("\n[DB-INSERT-VALUES] " + vals);

            String inXML = DigitalAO_Common.apInsert(
                    cabinetName,
                    sessionID,
                    cols,
                    vals,
                    "NG_DAO_CUSTOMER_SUMMARY"
            );

            DigitalAO.mLogger.debug("[DB-INSERT-REQUEST] " + inXML);

            String outXML = WFNGExecute(inXML, serverIp, serverPort, 1);

            DigitalAO.mLogger.debug("[DB-INSERT-RESPONSE] " + outXML);

            XMLParser parser = new XMLParser(outXML);
            String mainCode = parser.getValueOf("MainCode");

            long duration = System.currentTimeMillis() - startTime;

            if ("0".equals(mainCode)) {
                DigitalAO.mLogger.info(
                        "Insert successful | WI=" + wi_name +
                        " | CIF=" + cifId +
                        " | Duration=" + duration + "ms"
                );
                return "true";
            } else {
                DigitalAO.mLogger.error(
                        "Insert failed | WI=" + wi_name +
                        " | CIF=" + cifId +
                        " | MainCode=" + mainCode +
                        " | Response=" + outXML
                );
                return "false";
            }

        } catch (Exception e) {
            DigitalAO.mLogger.error("DB insert exception | WI=" + wi_name, e);
            return "false";
        }
    }
   
    
    
    /* ================= UTIL ================= */
    private static String getValue(Node node, String tag) {
        NodeList nl = (node instanceof Document)
                ? ((Document) node).getElementsByTagName(tag)
                : ((Element) node).getElementsByTagName(tag);

        return (nl != null && nl.getLength() > 0) ? nl.item(0).getTextContent() : "";
    }

    protected static String WFNGExecute(String xml, String ip, String port, int flag) {
        try {
            if (port.startsWith("33"))
                return WFCallBroker.execute(xml, ip, Integer.parseInt(port), flag);
            return ngEjbClient.makeCall(ip, port, "WebSphere", xml);
        } catch (Exception e) {
            return "";
        }
    }

    /* ================= SOCKET DETAILS ================= */
    private HashMap<String, String> socketConnectionDetails(String cab, String ip, String port, String session) {

        HashMap<String, String> map = new HashMap<>();

        try {

            String query = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName='DigitalAO' and CallingSource='Form'";

            String inXML = DigitalAO_Common.apSelectWithColumnNames(query, cab, session);
            String outXML = WFNGExecute(inXML, ip, port, 1);

            XMLParser parser = new XMLParser(outXML);

            if ("0".equals(parser.getValueOf("MainCode"))) {
            	String socketIP = parser.getValueOf("SocketServerIP");
            	String socketPort = parser.getValueOf("SocketServerPort");

            	DigitalAO.mLogger.info("Parsed Socket IP: " + socketIP);
            	DigitalAO.mLogger.info("Parsed Socket Port: " + socketPort);

            	if (socketIP != null && !socketIP.isEmpty()
            	        && socketPort != null && !socketPort.isEmpty()) {

            	    map.put("SocketServerIP", socketIP);
            	    map.put("SocketServerPort", socketPort);
            	}

            }

        } catch (Exception e) {}

        return map;
    }

    /* ================= SOCKET CONNECTION ================= */
    public static String socketConnection(String cabinetName, String username, String sessionID, String sJtsIp, String iJtsPort, String processInstanceID, String ws_name,
			int connection_timeout, int integrationWaitTime,StringBuilder sInputXML,HashMap<String, String> socketDetailsMap)
	{

		String socketServerIP;
		int socketServerPort;
		Socket socket = null;
		OutputStream out = null;
		InputStream socketInputStream = null;
		DataOutputStream dout = null;
		DataInputStream din = null;
		String outputResponse = null;
		String inputRequest = null;
		String inputMessageID = null;



		try
		{

			DigitalAO.mLogger.debug("userName "+ username);
			DigitalAO.mLogger.debug("SessionId "+ sessionID);

			socketServerIP=socketDetailsMap.get("SocketServerIP");
			DigitalAO.mLogger.debug("SocketServerIP "+ socketServerIP);
			socketServerPort=Integer.parseInt(socketDetailsMap.get("SocketServerPort"));
			DigitalAO.mLogger.debug("SocketServerPort "+ socketServerPort);

	   		if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort==0))
	   		{

    			socket = new Socket(socketServerIP, socketServerPort);
    			socket.setSoTimeout(connection_timeout*1000);
    			out = socket.getOutputStream();
    			socketInputStream = socket.getInputStream();
    			dout = new DataOutputStream(out);
    			din = new DataInputStream(socketInputStream);
    			DigitalAO.mLogger.debug("Dout " + dout);
    			DigitalAO.mLogger.debug("Din " + din);

    			outputResponse = "";

    			inputRequest = getRequestXML( cabinetName,sessionID ,processInstanceID, ws_name, username, sInputXML);


    			if (inputRequest != null && inputRequest.length() > 0)
    			{
    				int inputRequestLen = inputRequest.getBytes("UTF-16LE").length;
    				DigitalAO.mLogger.debug("RequestLen: "+inputRequestLen + "");
    				inputRequest = inputRequestLen + "##8##;" + inputRequest;
    				DigitalAO.mLogger.debug("InputRequest"+"Input Request Bytes : "+ inputRequest.getBytes("UTF-16LE"));
    				dout.write(inputRequest.getBytes("UTF-16LE"));dout.flush();
    			}
    			byte[] readBuffer = new byte[500];
    			int num = din.read(readBuffer);
    			if (num > 0)
    			{

    				byte[] arrayBytes = new byte[num];
    				System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
    				outputResponse = outputResponse+ new String(arrayBytes, "UTF-16LE");
					inputMessageID = outputResponse;
    				DigitalAO.mLogger.debug("OutputResponse: "+outputResponse);

    				if(!"".equalsIgnoreCase(outputResponse)) {
						outputResponse = getResponseXML(cabinetName,sJtsIp,iJtsPort,sessionID, processInstanceID,outputResponse,integrationWaitTime );
					}

    				if(outputResponse.contains("&lt;"))
    				{
    					outputResponse=outputResponse.replaceAll("&lt;", "<");
    					outputResponse=outputResponse.replaceAll("&gt;", ">");
    				}
    			}
    			socket.close();

				outputResponse = outputResponse.replaceAll("</MessageId>","</MessageId><InputMessageId>"+inputMessageID+"</InputMessageId>");

				return outputResponse;

    	 		}

    		else
    		{
    			DigitalAO.mLogger.debug("SocketServerIp and SocketServerPort is not maintained "+"");
    			DigitalAO.mLogger.debug("SocketServerIp is not maintained "+	socketServerIP);
    			DigitalAO.mLogger.debug(" SocketServerPort is not maintained "+	socketServerPort);
    			return "Socket Details not maintained";
    		}

		}

		catch (Exception e)
		{
			DigitalAO.mLogger.debug("Exception Occured Mq_connection_CC"+e.getStackTrace());
			return "";
		}
		finally
		{
			try
			{
				if(out != null)
				{
					out.close();
					out=null;
				}
				if(socketInputStream != null)
				{

					socketInputStream.close();
					socketInputStream=null;
				}
				if(dout != null)
				{

					dout.close();
					dout=null;
				}
				if(din != null)
				{

					din.close();
					din=null;
				}
				if(socket != null)
				{
					if(!socket.isClosed()) {
						socket.close();
					}
					socket=null;
				}

			}

			catch(Exception e)
			{
				DigitalAO.mLogger.debug("Final Exception Occured Mq_connection_CC"+e.getStackTrace());
				//printException(e);
			}
		}


	}

    private static String getRequestXML(String cab, String session, String wi, String ws, String user, StringBuilder input) {

        return "<APMQPUTGET_Input>" +
                "<SessionId>" + session + "</SessionId>" +
                "<EngineName>" + cab + "</EngineName>" +
                "<XMLHISTORY_TABLENAME>NG_DAO_XMLLOG_HISTORY</XMLHISTORY_TABLENAME>" +
                "<WI_NAME>" + wi + "</WI_NAME>" +
                "<WS_NAME>" + ws + "</WS_NAME>" +
                "<USER_NAME>" + user + "</USER_NAME>" +
                "<MQ_REQUEST_XML>" + input + "</MQ_REQUEST_XML>" +
                "</APMQPUTGET_Input>";
    }

    private static String getResponseXML(String cab, String ip, String port,
                                         String session, String wi,
                                         String msgId, int wait) {

        String output = "";

        try {

            String query = "select OUTPUT_XML from NG_DAO_XMLLOG_HISTORY where MESSAGE_ID='" + msgId + "' and WI_NAME='" + wi + "'";

            String inXML = DigitalAO_Common.apSelectWithColumnNames(query, cab, session);

            for (int i = 0; i < wait; i++) {

                String outXML = WFNGExecute(inXML, ip, port, 1);

                XMLParser parser = new XMLParser(outXML);

                if ("0".equals(parser.getValueOf("MainCode")) &&
                        Integer.parseInt(parser.getValueOf("TotalRetrieved")) > 0) {

                    String rec = parser.getNextValueOf("Record");
                    XMLParser p = new XMLParser(rec);

                    output = p.getValueOf("OUTPUT_XML");
                    break;
                }

                Thread.sleep(1000);
            }

        } catch (Exception e) {}

        return output;
    }
}