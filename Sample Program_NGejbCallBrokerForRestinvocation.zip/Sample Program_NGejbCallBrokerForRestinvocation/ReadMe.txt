This is a sample Utility used to test product apis calling machenism through HTTP calls. Once its working on your system you can refer the changes for your custom utility:

Step-by-Step Instructions:

1. Update Application Server Details in config.ini File of sample program.

2. Update JDK Path in compile.bat, run.bat, compile.sh, or run.sh:

For Windows:
Open compile.bat and run.bat files, and ensure the path to your JDK is correct. You can find your JDK installation path on your system and replace the existing path if it’s incorrect.
For Linux:
Similarly, in compile.sh and run.sh, ensure the path to the JDK is accurate for your Linux environment.
This ensures that the Java programs are compiled and run using the correct JDK.

3. Modify Flags in NGError.properties:

RESTInvocation Flag:
Find the NGError.properties file inside the NGEjbCallBroker.jar and look for the RESTInvocation flag.
Set its value to Y to enable RESTful API invocation.
DomainURL Flag:
Update the DomainURL with the correct IP address of your domain or application server. This tells the utility where to send the API requests.

4. Verify Deployment of iBPSRestFulWebservice.war:
Ensure that the iBPSRestFulWebservice.war file is correctly deployed on your application server. This WAR file should be accessible by the utility when making the HTTP requests.

---------------------------------------------------
Additional Notes:
1. Using Jars from the Sample Program:
Once the setup is working on your system, you can copy the relevant JAR files from the lib folder of this sample program to use in your custom utility. These JARs contain the necessary dependencies to interact with the APIs.
2. Referencing the EAPCallBroker.java File:
For the NGEjbcallbroker method, refer to the code in Sample Program_Working\src\EAPCallBroker.java. This file contains the logic for interacting with the product APIs and should guide you in replicating the necessary functionality for your own utility.

3. Provided NGEjbCallBroker.jar Purpose:
The NGEjbCallBroker.jar is intended for use in custom utilities or web servers but not in the context of EJB (Enterprise JavaBeans) or application servers. Make sure it’s used only in the appropriate context.