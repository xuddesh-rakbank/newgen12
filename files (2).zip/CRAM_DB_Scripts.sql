-- =============================================================================
-- CRAM Integration - DB Scripts
-- Project: IBPS CRAM Integration
-- =============================================================================


-- =============================================================================
-- TABLE 1: NG_DAO_CRAM_AUTH_TOKEN
-- Purpose : Cache the SAS/CRAM OAuth2 Bearer token to avoid fetching on every
--           API call. Token is reused until ExpiryDateTime <= GETDATE().
-- =============================================================================
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_NAME = 'NG_DAO_CRAM_AUTH_TOKEN'
)
BEGIN
    CREATE TABLE NG_DAO_CRAM_AUTH_TOKEN (
        ID              INT IDENTITY(1,1)   NOT NULL PRIMARY KEY,
        AuthToken       NVARCHAR(MAX)       NOT NULL,
        GenDateTime     DATETIME            NOT NULL DEFAULT GETDATE(),
        ExpiryDateTime  DATETIME            NOT NULL
    );

    CREATE INDEX IX_CRAM_AUTH_EXPIRY ON NG_DAO_CRAM_AUTH_TOKEN (ExpiryDateTime);

    PRINT 'NG_DAO_CRAM_AUTH_TOKEN created successfully.';
END
ELSE
BEGIN
    PRINT 'NG_DAO_CRAM_AUTH_TOKEN already exists.';
END
GO


-- =============================================================================
-- TABLE 2: NG_DAO_CRAM_WI_DATA
-- Purpose : Stores all dynamic CRAM input fields per work item (WI_NAME).
--           Populated by IBPS when CF staff updates data / DEH sends createWI.
--           Fields map directly to CRAM API request parameters.
-- =============================================================================
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_NAME = 'NG_DAO_CRAM_WI_DATA'
)
BEGIN
    CREATE TABLE NG_DAO_CRAM_WI_DATA (
        ID                              INT IDENTITY(1,1)   NOT NULL PRIMARY KEY,
        WI_NAME                         NVARCHAR(100)       NOT NULL,   -- ProcessInstanceID

        -- Customer Identity
        CIF                             NVARCHAR(50)        NULL,
        CUST_TYPE                       NVARCHAR(50)        NULL,       -- Individual / Corporate
        NTB_ETB                         NVARCHAR(10)        NULL,       -- NTB / ETB
        CUST_NAME                       NVARCHAR(255)       NULL,

        -- Risk Parameters (pipe-separated for array fields)
        NATIONALITY                     NVARCHAR(500)       NULL,       -- e.g. AE|SA
        DEMOGRAPHIC                     NVARCHAR(500)       NULL,       -- e.g. AE|NR
        LENGTH_OF_RESIDENCY             NVARCHAR(20)        NULL,       -- e.g. 5.09
        PERSONA                         NVARCHAR(50)        NULL,       -- e.g. CO
        INDUSTRY                        NVARCHAR(500)       NULL,       -- e.g. GAA|FAA (pipe separated)
        PEP_STATUS                      NVARCHAR(50)        NULL,       -- NPEP / PEP / etc. (updated by Ops post-FIRCO)
        HNWI                            NVARCHAR(50)        NULL,       -- numeric string
        HNWE                            NVARCHAR(50)        NULL,       -- numeric string
        CASH_TURNOVER_PERC              NVARCHAR(200)       NULL,       -- e.g. 50|32.5
        ADVERSE_MEDIA                   NVARCHAR(5)         NULL,       -- Y / N
        COUNTRY_OF_BIRTH                NVARCHAR(500)       NULL,       -- e.g. AE (pipe separated)
        LICENSING_AUTHORITY             NVARCHAR(500)       NULL,

        -- Corporate/BBG specific
        ANNUAL_TURNOVER_EXPECTED        NVARCHAR(50)        NULL,
        PERSONAL_ACC_FOR_COMMERCIAL     NVARCHAR(5)         NULL,       -- Y / N
        CUST_REPORTED_TO_REGULATOR      NVARCHAR(5)         NULL,       -- Y / N
        LENGTH_OF_ESTABLISHMENT         NVARCHAR(20)        NULL,
        COUNTRY_OF_ESTABLISHMENT        NVARCHAR(500)       NULL,       -- pipe separated
        LAYERS_OWNERSHIP                NVARCHAR(20)        NULL,
        NON_RESIDENT_UBO                NVARCHAR(5)         NULL,       -- Y / N

        -- Dedupe fields
        IS_DEDUPE                       NVARCHAR(5)         NULL,       -- Y / N
        CIF_CREATED_DATE                NVARCHAR(50)        NULL,       -- BOCIFCREATEDDATE from DEH createWI

        -- Audit
        CREATED_DATE                    DATETIME            NOT NULL DEFAULT GETDATE(),
        UPDATED_DATE                    DATETIME            NULL
    );

    CREATE INDEX IX_CRAM_WI_NAME ON NG_DAO_CRAM_WI_DATA (WI_NAME);

    PRINT 'NG_DAO_CRAM_WI_DATA created successfully.';
END
ELSE
BEGIN
    PRINT 'NG_DAO_CRAM_WI_DATA already exists.';
END
GO


-- =============================================================================
-- TABLE 3: NG_DAO_CRAM_RISK_RESULT
-- Purpose : Stores the CRAM API response (risk score, category, rating) per WI.
--           IBPS UI reads this to display risk result to CF staff.
-- =============================================================================
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_NAME = 'NG_DAO_CRAM_RISK_RESULT'
)
BEGIN
    CREATE TABLE NG_DAO_CRAM_RISK_RESULT (
        ID                  INT IDENTITY(1,1)   NOT NULL PRIMARY KEY,
        WI_NAME             NVARCHAR(100)       NOT NULL,   -- ProcessInstanceID
        RISK_CATEGORY       NVARCHAR(100)       NULL,       -- e.g. High Risk / Low Risk
        TOTAL_RISK_SCORE    NVARCHAR(50)        NULL,       -- e.g. 4.05
        OVERALL_RISK_RATING NVARCHAR(50)        NULL,       -- e.g. 18
        CRAM_REQUEST_ID     NVARCHAR(100)       NULL,       -- UUID of the CRAM API request
        UPDATED_DATE        DATETIME            NOT NULL DEFAULT GETDATE()
    );

    CREATE INDEX IX_CRAM_RESULT_WI ON NG_DAO_CRAM_RISK_RESULT (WI_NAME);

    PRINT 'NG_DAO_CRAM_RISK_RESULT created successfully.';
END
ELSE
BEGIN
    PRINT 'NG_DAO_CRAM_RISK_RESULT already exists.';
END
GO


-- =============================================================================
-- NOTE: Existing tables referenced but NOT created here (already in IBPS):
--   NG_DPL_XMLLOG_HISTORY   - Audit log (already exists from OCR integration)
--   NG_DPL_GR_DECISION_HISTORY - Decision history (already exists)
--   WFMAILQUEUETABLE        - Mail queue (Newgen standard table)
--   NG_DAO_ACCOUNT_SUMMARY  - Account summary from MW (adjust to your schema)
--   NG_DAO_ECIF_DETAILS     - ECIF details from Crystal/MW (adjust to your schema)
-- =============================================================================
