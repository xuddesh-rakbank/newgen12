package com.newgen.DPL.CRAM;

/**
 * CRAM Response POJO
 * Maps to CRAMResponse + CRAMResponse_riskScoreInfo schemas in CRAM.yaml
 */
public class CRAMResponse {

    // ── Top-level response fields ──────────────────────────────────────────────
    private String  serviceId;
    private String  requestId;
    private String  serviceChannelId;
    private String  timeStamp;
    private String  journey;
    private String  custType;
    private String  type;
    private String  custIdType;
    private String  custIdValue;
    private Double  totalRiskScore;
    private String  riskCategory;       // e.g. "High Risk"
    private Integer overallRiskRating;  // e.g. 18
    private RiskScoreInfo riskScoreInfo;

    // ── Inner class: riskScoreInfo ─────────────────────────────────────────────
    public static class RiskScoreInfo {
        private String nationality;
        private String demographic;
        private String industry;
        private String deliveryChannel;
        private String product;
        private String hnwi;
        private String hnwe;
        private String pepStatus;
        private String currency;
        private String cashTurnoverPerc;
        private String maturityRelationship;
        private String lengthOfResidency;
        private String persona;
        private String licensingAuthority;
        private String adverseMediaResults;
        private String countryOfBirth;
        private String annualTurnoverExpected;
        private String personalAccountsUtilizedForCommercialActivity;
        private String customerreportedtoRegulator;   // note: lowercase 'r' as per CRAM spec
        private String lengthOfEstablishment;
        private String countryOfEstablishment;
        private String layersInComplexOwnershipStructure;
        private String nonResidentUboOrCustomer;

        public String getNationality() { return nationality; }
        public void setNationality(String nationality) { this.nationality = nationality; }

        public String getDemographic() { return demographic; }
        public void setDemographic(String demographic) { this.demographic = demographic; }

        public String getIndustry() { return industry; }
        public void setIndustry(String industry) { this.industry = industry; }

        public String getDeliveryChannel() { return deliveryChannel; }
        public void setDeliveryChannel(String deliveryChannel) { this.deliveryChannel = deliveryChannel; }

        public String getProduct() { return product; }
        public void setProduct(String product) { this.product = product; }

        public String getHnwi() { return hnwi; }
        public void setHnwi(String hnwi) { this.hnwi = hnwi; }

        public String getHnwe() { return hnwe; }
        public void setHnwe(String hnwe) { this.hnwe = hnwe; }

        public String getPepStatus() { return pepStatus; }
        public void setPepStatus(String pepStatus) { this.pepStatus = pepStatus; }

        public String getCurrency() { return currency; }
        public void setCurrency(String currency) { this.currency = currency; }

        public String getCashTurnoverPerc() { return cashTurnoverPerc; }
        public void setCashTurnoverPerc(String cashTurnoverPerc) { this.cashTurnoverPerc = cashTurnoverPerc; }

        public String getMaturityRelationship() { return maturityRelationship; }
        public void setMaturityRelationship(String maturityRelationship) { this.maturityRelationship = maturityRelationship; }

        public String getLengthOfResidency() { return lengthOfResidency; }
        public void setLengthOfResidency(String lengthOfResidency) { this.lengthOfResidency = lengthOfResidency; }

        public String getPersona() { return persona; }
        public void setPersona(String persona) { this.persona = persona; }

        public String getLicensingAuthority() { return licensingAuthority; }
        public void setLicensingAuthority(String licensingAuthority) { this.licensingAuthority = licensingAuthority; }

        public String getAdverseMediaResults() { return adverseMediaResults; }
        public void setAdverseMediaResults(String adverseMediaResults) { this.adverseMediaResults = adverseMediaResults; }

        public String getCountryOfBirth() { return countryOfBirth; }
        public void setCountryOfBirth(String countryOfBirth) { this.countryOfBirth = countryOfBirth; }

        public String getAnnualTurnoverExpected() { return annualTurnoverExpected; }
        public void setAnnualTurnoverExpected(String annualTurnoverExpected) { this.annualTurnoverExpected = annualTurnoverExpected; }

        public String getPersonalAccountsUtilizedForCommercialActivity() { return personalAccountsUtilizedForCommercialActivity; }
        public void setPersonalAccountsUtilizedForCommercialActivity(String v) { this.personalAccountsUtilizedForCommercialActivity = v; }

        public String getCustomerreportedtoRegulator() { return customerreportedtoRegulator; }
        public void setCustomerreportedtoRegulator(String v) { this.customerreportedtoRegulator = v; }

        public String getLengthOfEstablishment() { return lengthOfEstablishment; }
        public void setLengthOfEstablishment(String lengthOfEstablishment) { this.lengthOfEstablishment = lengthOfEstablishment; }

        public String getCountryOfEstablishment() { return countryOfEstablishment; }
        public void setCountryOfEstablishment(String countryOfEstablishment) { this.countryOfEstablishment = countryOfEstablishment; }

        public String getLayersInComplexOwnershipStructure() { return layersInComplexOwnershipStructure; }
        public void setLayersInComplexOwnershipStructure(String v) { this.layersInComplexOwnershipStructure = v; }

        public String getNonResidentUboOrCustomer() { return nonResidentUboOrCustomer; }
        public void setNonResidentUboOrCustomer(String nonResidentUboOrCustomer) { this.nonResidentUboOrCustomer = nonResidentUboOrCustomer; }
    }

    // ── Getters & Setters ──────────────────────────────────────────────────────

    public String getServiceId() { return serviceId; }
    public void setServiceId(String serviceId) { this.serviceId = serviceId; }

    public String getRequestId() { return requestId; }
    public void setRequestId(String requestId) { this.requestId = requestId; }

    public String getServiceChannelId() { return serviceChannelId; }
    public void setServiceChannelId(String serviceChannelId) { this.serviceChannelId = serviceChannelId; }

    public String getTimeStamp() { return timeStamp; }
    public void setTimeStamp(String timeStamp) { this.timeStamp = timeStamp; }

    public String getJourney() { return journey; }
    public void setJourney(String journey) { this.journey = journey; }

    public String getCustType() { return custType; }
    public void setCustType(String custType) { this.custType = custType; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getCustIdType() { return custIdType; }
    public void setCustIdType(String custIdType) { this.custIdType = custIdType; }

    public String getCustIdValue() { return custIdValue; }
    public void setCustIdValue(String custIdValue) { this.custIdValue = custIdValue; }

    public Double getTotalRiskScore() { return totalRiskScore; }
    public void setTotalRiskScore(Double totalRiskScore) { this.totalRiskScore = totalRiskScore; }

    public String getRiskCategory() { return riskCategory; }
    public void setRiskCategory(String riskCategory) { this.riskCategory = riskCategory; }

    public Integer getOverallRiskRating() { return overallRiskRating; }
    public void setOverallRiskRating(Integer overallRiskRating) { this.overallRiskRating = overallRiskRating; }

    public RiskScoreInfo getRiskScoreInfo() { return riskScoreInfo; }
    public void setRiskScoreInfo(RiskScoreInfo riskScoreInfo) { this.riskScoreInfo = riskScoreInfo; }
}
