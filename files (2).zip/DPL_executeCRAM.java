package com.newgen.DPL.CRAM;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;

/**
 * DPL_executeCRAM
 *
 * HTTP utility class for CRAM integration via Kong Internal API Gateway.
 * Handles:
 *   1. SSL/JKS loading
 *   2. SAS token fetch via POST /SASLogon/oauth/token  (client_credentials)
 *   3. Token caching in DB table NG_DAO_CRAM_AUTH_TOKEN
 *   4. CRAM risk calculation via POST /viya-cram-0/rrc
 *   5. Audit logging to NG_DPL_XMLLOG_HISTORY
 *
 * Pattern mirrors DPL_executeOCR.java from OCR integration reference.
 */
public class DPL_executeCRAM {

    // ── Response delimiter (mirrors OCR pattern: "body~httpCode") ─────────────
    private static final String RESP_DELIMITER = "~";

    // =========================================================================
    // 1. SSL / JKS Loader
    // =========================================================================

    /**
     * Loads the Kong SSL JKS certificate into JVM system properties.
     * JKS file expected at: {user.dir}/Certificates/KongSSL.jks
     */
    public static void loadSSL(Logger logger, String kongApiJksPassword) {
        try {
            String workingDirectory = System.getProperty("user.dir");
            String cacertsFile = workingDirectory + File.separator
                    + "Certificates" + File.separator + "KongSSL.jks";

            logger.debug("[CRAM-SSL] JKS Path: " + cacertsFile);

            System.setProperty("java.protocol.handler.pkgs", "javax.net.ssl");
            System.setProperty("javax.net.ssl.keyStore",          cacertsFile);
            System.setProperty("javax.net.ssl.keyStoreType",      java.security.KeyStore.getDefaultType());
            System.setProperty("javax.net.ssl.keyStorePassword",  kongApiJksPassword);
            System.setProperty("javax.net.ssl.trustStore",        cacertsFile);
            System.setProperty("javax.net.ssl.trustStoreType",    java.security.KeyStore.getDefaultType());
            System.setProperty("javax.net.ssl.trustStorePassword",kongApiJksPassword);

            logger.debug("[CRAM-SSL] SSL properties set successfully.");
        } catch (Exception e) {
            logger.error("[CRAM-SSL] Failed to load SSL: " + e.getMessage(), e);
        }
    }

    // =========================================================================
    // 2. Token Management  (DB cache: NG_DAO_CRAM_AUTH_TOKEN)
    // =========================================================================

    /**
     * Master token entry point.
     * Returns a valid Bearer token — fetches from DB cache first,
     * calls Kong /SASLogon/oauth/token only if cache is empty/expired.
     *
     * @param logger
     * @param kongApiJksPassword  JKS keystore password
     * @param kongTokenEndpoint   Full URL: https://apiinternal-uat.rakbanktst.ae/SASLogon/oauth/token
     * @param kongApiKey          x-api-key value for Kong
     * @param clientId            SAS OAuth client_id
     * @param clientSecret        SAS OAuth client_secret
     * @return Bearer access token string, or "" on failure
     */
    public static String getAuthToken(Logger logger,
                                      String kongApiJksPassword,
                                      String kongTokenEndpoint,
                                      String kongApiKey,
                                      String clientId,
                                      String clientSecret) {

        logger.debug("[CRAM-TOKEN] Checking cached token in NG_DAO_CRAM_AUTH_TOKEN...");
        String token = getExistingAuthToken(logger);

        if (token != null && !token.trim().isEmpty()) {
            logger.debug("[CRAM-TOKEN] Valid cached token found. Reusing.");
            return token;
        }

        logger.debug("[CRAM-TOKEN] No valid cached token. Fetching new token from Kong...");

        // Build form-encoded body per SASLogon.yaml oauth_token_body schema
        // grant_type=client_credentials&client_id=xxx&client_secret=xxx
        String authBody = "grant_type=client_credentials"
                + "&client_id="     + clientId
                + "&client_secret=" + clientSecret;

        String rawResponse = postKongToken(kongTokenEndpoint, authBody, logger,
                                           kongApiKey, kongApiJksPassword);

        String[] parts      = rawResponse.split(RESP_DELIMITER, 2);
        String responseBody = parts[0];
        String httpCode     = parts.length > 1 ? parts[1] : "0";

        logger.debug("[CRAM-TOKEN] HTTP Code: " + httpCode);

        if (!"200".equalsIgnoreCase(httpCode)) {
            logger.error("[CRAM-TOKEN] Token fetch failed. HTTP=" + httpCode
                    + " Body=" + responseBody);
            return "";
        }

        try {
            JSONObject json   = new JSONObject(responseBody);
            token             = json.getString("access_token");
            int expiresIn     = json.optInt("expires_in", 3600); // default 1hr if not returned

            logger.debug("[CRAM-TOKEN] Token fetched. expires_in=" + expiresIn + "s");

            // Persist token to DB cache
            persistTokenToDb(token, expiresIn, logger);

        } catch (Exception e) {
            logger.error("[CRAM-TOKEN] Error parsing token response: " + e.getMessage(), e);
            return "";
        }

        return token;
    }

    /**
     * Queries NG_DAO_CRAM_AUTH_TOKEN for a non-expired token.
     * Returns empty string if none found.
     */
    public static String getExistingAuthToken(Logger logger) {
        String authToken = "";
        try {
            // Only fetch if ExpiryDateTime is still in the future
            String query = "SELECT TOP 1 AuthToken FROM NG_DAO_CRAM_AUTH_TOKEN WITH(NOLOCK) "
                         + "WHERE ExpiryDateTime > GETDATE() ORDER BY GenDateTime DESC";

            String ipXml = CommonMethods.apSelectWithColumnNames(
                    query,
                    CommonConnection.getCabinetName(),
                    CommonConnection.getSessionID(logger, false));

            String opXml = CommonMethods.WFNGExecute(
                    ipXml,
                    CommonConnection.getJTSIP(),
                    CommonConnection.getJTSPort(), 1);

            XMLParser parser     = new XMLParser(opXml);
            String mainCode      = parser.getValueOf("MainCode");
            int totalRetrieved   = Integer.parseInt(parser.getValueOf("TotalRetrieved"));

            if ("0".equalsIgnoreCase(mainCode) && totalRetrieved > 0) {
                authToken = parser.getValueOf("AuthToken");
                logger.debug("[CRAM-TOKEN] Cached token retrieved from DB.");
            } else {
                logger.debug("[CRAM-TOKEN] No valid token in cache. MainCode=" + mainCode
                        + " TotalRetrieved=" + totalRetrieved);
            }
        } catch (Exception e) {
            logger.error("[CRAM-TOKEN] Error querying token cache: " + e.getMessage(), e);
        }
        return authToken;
    }

    /**
     * Persists a freshly obtained token to NG_DAO_CRAM_AUTH_TOKEN.
     * ExpiryDateTime is calculated as GETDATE() + expiresIn seconds.
     */
    private static void persistTokenToDb(String token, int expiresIn, Logger logger) {
        try {
            // Clean up expired tokens first to keep table lean
            String deleteOldQuery = "DELETE FROM NG_DAO_CRAM_AUTH_TOKEN WHERE ExpiryDateTime <= GETDATE()";
            String deleteIpXml = CommonMethods.apSelectWithColumnNames(
                    deleteOldQuery,
                    CommonConnection.getCabinetName(),
                    CommonConnection.getSessionID(logger, false));
            CommonMethods.WFNGExecute(deleteIpXml, CommonConnection.getJTSIP(),
                    CommonConnection.getJTSPort(), 1);

            // Insert new token
            String colNames  = "AuthToken, GenDateTime, ExpiryDateTime";
            String colValues = "'" + token + "', GETDATE(), DATEADD(second, " + expiresIn + ", GETDATE())";

            String insertIpXml = CommonMethods.apInsert(
                    CommonConnection.getCabinetName(),
                    CommonConnection.getSessionID(logger, false),
                    colNames, colValues,
                    "NG_DAO_CRAM_AUTH_TOKEN");

            logger.debug("[CRAM-TOKEN] Insert InputXML: " + insertIpXml);

            String insertOpXml = CommonMethods.WFNGExecute(
                    insertIpXml,
                    CommonConnection.getJTSIP(),
                    CommonConnection.getJTSPort(), 1);

            XMLParser parser = new XMLParser(insertOpXml);
            String mainCode  = parser.getValueOf("MainCode");
            logger.debug("[CRAM-TOKEN] Token persist MainCode=" + mainCode);

        } catch (Exception e) {
            logger.error("[CRAM-TOKEN] Error persisting token to DB: " + e.getMessage(), e);
        }
    }

    // =========================================================================
    // 3. Kong Token HTTP POST  (POST /SASLogon/oauth/token)
    // =========================================================================

    /**
     * Makes HTTP POST to Kong token endpoint.
     * Content-Type: application/x-www-form-urlencoded  (as per SASLogon.yaml)
     * Header: apikey = Kong x-api-key value
     *
     * @return "responseBody~httpStatusCode"
     */
    public static String postKongToken(String tokenUrl,
                                       String requestBody,
                                       Logger logger,
                                       String kongApiKey,
                                       String kongApiJksPassword) {
        try {
            loadSSL(logger, kongApiJksPassword);

            logger.debug("[CRAM-TOKEN-HTTP] POST to: " + tokenUrl);

            URL url = new URL(tokenUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Accept",       "application/json");
            conn.setRequestProperty("apikey",       kongApiKey);   // Kong x-api-key header
            conn.setDoOutput(true);

            try (DataOutputStream out = new DataOutputStream(conn.getOutputStream())) {
                out.writeBytes(requestBody);
                out.flush();
            }

            int httpCode = conn.getResponseCode();
            logger.debug("[CRAM-TOKEN-HTTP] Response Code: " + httpCode);

            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    httpCode >= 400 ? conn.getErrorStream() : conn.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }

            conn.disconnect();
            logger.debug("[CRAM-TOKEN-HTTP] Response: " + sb);
            return sb.toString() + RESP_DELIMITER + httpCode;

        } catch (IOException ioEx) {
            logger.error("[CRAM-TOKEN-HTTP] IO Error: " + ioEx.getMessage(), ioEx);
            return "Failure:" + ioEx.getMessage() + RESP_DELIMITER + "0";
        }
    }

    // =========================================================================
    // 4. CRAM Risk API Call  (POST /viya-cram-0/rrc)
    // =========================================================================

    /**
     * Calls CRAM Decision Engine via Kong Internal.
     *
     * Flow:
     *   - Builds JSON payload from CRAMRequest
     *   - POSTs to kongCramEndpoint with Bearer token + apikey header
     *   - Parses JSON response into CRAMResponse
     *   - Logs full request/response to NG_DPL_XMLLOG_HISTORY
     *
     * @param authToken           Bearer token from getAuthToken()
     * @param kongApiKey          Kong x-api-key
     * @param kongCramEndpoint    Full URL: https://apiinternal-uat.rakbanktst.ae/viya-cram-0/rrc
     * @param cramRequest         Populated CRAMRequest object
     * @param processInstanceID   IBPS work item ID (for logging)
     * @param cabinetName         Newgen cabinet name
     * @param sessionID           Newgen session ID
     * @param logger
     * @param kongApiJksPassword  JKS password
     * @return CRAMResponse on success, null on failure
     */
    public static CRAMResponse callCRAMRiskAPI(String authToken,
                                               String kongApiKey,
                                               String kongCramEndpoint,
                                               CRAMRequest cramRequest,
                                               String processInstanceID,
                                               String cabinetName,
                                               String sessionID,
                                               Logger logger,
                                               String kongApiJksPassword) {

        String requestId         = cramRequest.getRequestId();
        String requestBodyJson   = "";
        String rawResponseBody   = "";
        int    httpCode          = 0;
        CRAMResponse cramResponse = null;

        DateFormat dateFormat       = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedRequestTime = dateFormat.format(new Date());

        try {
            loadSSL(logger, kongApiJksPassword);

            // Build JSON payload from CRAMRequest
            requestBodyJson = buildCRAMRequestJson(cramRequest, logger);
            logger.debug("[CRAM-RISK] RequestId=" + requestId + " Payload=" + requestBodyJson);

            URL url = new URL(kongCramEndpoint);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept",        "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + authToken);
            conn.setRequestProperty("apikey",        kongApiKey);  // Kong x-api-key
            conn.setDoOutput(true);

            // Write request body
            try (DataOutputStream out = new DataOutputStream(conn.getOutputStream())) {
                byte[] bodyBytes = requestBodyJson.getBytes("UTF-8");
                out.write(bodyBytes);
                out.flush();
            }

            httpCode = conn.getResponseCode();
            logger.debug("[CRAM-RISK] HTTP Response Code: " + httpCode);

            // Read response (error stream for 4xx/5xx)
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    httpCode >= 400 ? conn.getErrorStream() : conn.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }

            rawResponseBody = sb.toString();
            logger.debug("[CRAM-RISK] Raw Response: " + rawResponseBody);
            conn.disconnect();

            if (httpCode == 200) {
                // Parse successful response
                cramResponse = parseCRAMResponse(rawResponseBody, logger);
                logger.debug("[CRAM-RISK] Risk Category=" + cramResponse.getRiskCategory()
                        + " TotalScore=" + cramResponse.getTotalRiskScore()
                        + " OverallRating=" + cramResponse.getOverallRiskRating());
            } else {
                logger.error("[CRAM-RISK] Non-200 response. HTTP=" + httpCode
                        + " Body=" + rawResponseBody);
            }

        } catch (IOException ioEx) {
            logger.error("[CRAM-RISK] IO Error: " + ioEx.getMessage(), ioEx);
            rawResponseBody = "IOException: " + ioEx.getMessage();
        } catch (Exception e) {
            logger.error("[CRAM-RISK] Unexpected error: " + e.getMessage(), e);
            rawResponseBody = "Exception: " + e.getMessage();
        } finally {
            // Always audit log the request/response
            insertAuditLog(requestBodyJson, rawResponseBody, requestId,
                    processInstanceID, String.valueOf(httpCode),
                    cabinetName, sessionID, formattedRequestTime, logger);
        }

        return cramResponse;
    }

    // =========================================================================
    // 5. JSON Builder  (CRAMRequest → JSON string)
    // =========================================================================

    /**
     * Manually builds JSON from CRAMRequest to avoid external Jackson/Gson dependency,
     * keeping consistent with the project's existing pattern (no Spring, plain Java).
     */
    public static String buildCRAMRequestJson(CRAMRequest req, Logger logger) {
        try {
            JSONObject json = new JSONObject();

            // Static / config fields
            putIfNotNull(json, "serviceId",        req.getServiceId());
            putIfNotNull(json, "serviceType",       req.getServiceType());
            putIfNotNull(json, "serviceChannelId",  req.getServiceChannelId());
            putIfNotNull(json, "requestId",         req.getRequestId());
            putIfNotNull(json, "timeStamp",         req.getTimeStamp());
            putIfNotNull(json, "userId",            req.getUserId());
            putIfNotNull(json, "journey",           req.getJourney());
            putIfNotNull(json, "businessSegment",   req.getBusinessSegment());
            putIfNotNull(json, "businessSubsegment",req.getBusinessSubsegment());
            putIfNotNull(json, "deliveryChannel",   req.getDeliveryChannel());

            // Customer identity
            putIfNotNull(json, "custType",     req.getCustType());
            putIfNotNull(json, "type",         req.getType());
            putIfNotNull(json, "custIdType",   req.getCustIdType());
            putIfNotNull(json, "custIdValue",  req.getCustIdValue());
            putIfNotNull(json, "customerName", req.getCustomerName());

            // Array fields
            putStringArrayIfNotEmpty(json, "nationality",        req.getNationality());
            putStringArrayIfNotEmpty(json, "demographic",        req.getDemographic());
            putStringArrayIfNotEmpty(json, "industry",           req.getIndustry());
            putStringArrayIfNotEmpty(json, "product",            req.getProduct());
            putStringArrayIfNotEmpty(json, "currency",           req.getCurrency());
            putStringArrayIfNotEmpty(json, "countryOfBirth",     req.getCountryOfBirth());
            putStringArrayIfNotEmpty(json, "countryOfEstablishment", req.getCountryOfEstablishment());

            // Numeric array
            if (req.getCashTurnoverPerc() != null && !req.getCashTurnoverPerc().isEmpty()) {
                JSONArray arr = new JSONArray();
                for (Double val : req.getCashTurnoverPerc()) {
                    arr.put(val);
                }
                json.put("cashTurnoverPerc", arr);
            }

            // Scalar dynamic fields
            putIfNotNull(json, "lengthOfResidency",  req.getLengthOfResidency());
            putIfNotNull(json, "persona",            req.getPersona());
            putIfNotNull(json, "pepStatus",          req.getPepStatus());
            putIfNotNull(json, "maturityRelationship", req.getMaturityRelationship());
            putIfNotNull(json, "licensingAuthority", req.getLicensingAuthority());
            putIfNotNull(json, "adverseMediaResults",req.getAdverseMediaResults());
            putIfNotNull(json, "lengthOfEstablishment", req.getLengthOfEstablishment());
            putIfNotNull(json, "layersInComplexOwnershipStructure", req.getLayersInComplexOwnershipStructure());
            putIfNotNull(json, "nonResidentUboOrCustomer", req.getNonResidentUboOrCustomer());
            putIfNotNull(json, "personalAccountsUtilizedForCommercialActivity",
                    req.getPersonalAccountsUtilizedForCommercialActivity());
            putIfNotNull(json, "customerReportedToRegulator", req.getCustomerReportedToRegulator());

            // Numeric scalars
            if (req.getHnwi() != null) json.put("hnwi", req.getHnwi());
            if (req.getHnwe() != null) json.put("hnwe", req.getHnwe());
            if (req.getAnnualTurnoverExpected() != null) json.put("annualTurnoverExpected", req.getAnnualTurnoverExpected());

            return json.toString();

        } catch (Exception e) {
            logger.error("[CRAM-JSON] Error building CRAM request JSON: " + e.getMessage(), e);
            return "{}";
        }
    }

    /** Puts a string key/value only if value is non-null and non-empty */
    private static void putIfNotNull(JSONObject json, String key, String value) {
        if (value != null && !value.trim().isEmpty()) {
            try { json.put(key, value); } catch (Exception ignored) {}
        }
    }

    /** Puts a String array only if list is non-null and non-empty */
    private static void putStringArrayIfNotEmpty(JSONObject json, String key, List<String> list) {
        if (list != null && !list.isEmpty()) {
            try {
                JSONArray arr = new JSONArray();
                for (String s : list) { arr.put(s); }
                json.put(key, arr);
            } catch (Exception ignored) {}
        }
    }

    // =========================================================================
    // 6. JSON Parser  (raw response string → CRAMResponse)
    // =========================================================================

    /**
     * Parses the CRAM API JSON response into a CRAMResponse POJO.
     */
    public static CRAMResponse parseCRAMResponse(String rawJson, Logger logger) {
        CRAMResponse response = new CRAMResponse();
        try {
            JSONObject json = new JSONObject(rawJson);

            response.setServiceId(       json.optString("serviceId",       ""));
            response.setRequestId(       json.optString("requestId",       ""));
            response.setServiceChannelId(json.optString("serviceChannelId",""));
            response.setTimeStamp(       json.optString("timeStamp",       ""));
            response.setJourney(         json.optString("journey",         ""));
            response.setCustType(        json.optString("custType",        ""));
            response.setType(            json.optString("type",            ""));
            response.setCustIdType(      json.optString("custIdType",      ""));
            response.setCustIdValue(     json.optString("custIdValue",     ""));

            if (!json.isNull("totalRiskScore"))   response.setTotalRiskScore(json.getDouble("totalRiskScore"));
            if (!json.isNull("overallRiskRating")) response.setOverallRiskRating(json.getInt("overallRiskRating"));
            response.setRiskCategory(json.optString("riskCategory", ""));

            // Parse nested riskScoreInfo
            if (json.has("riskScoreInfo") && !json.isNull("riskScoreInfo")) {
                JSONObject rsi = json.getJSONObject("riskScoreInfo");
                CRAMResponse.RiskScoreInfo info = new CRAMResponse.RiskScoreInfo();

                info.setNationality(              rsi.optString("nationality",              ""));
                info.setDemographic(              rsi.optString("demographic",              ""));
                info.setIndustry(                 rsi.optString("industry",                 ""));
                info.setDeliveryChannel(          rsi.optString("deliveryChannel",          ""));
                info.setProduct(                  rsi.optString("product",                  ""));
                info.setHnwi(                     rsi.optString("hnwi",                     ""));
                info.setHnwe(                     rsi.optString("hnwe",                     ""));
                info.setPepStatus(                rsi.optString("pepStatus",                ""));
                info.setCurrency(                 rsi.optString("currency",                 ""));
                info.setCashTurnoverPerc(         rsi.optString("cashTurnoverPerc",         ""));
                info.setMaturityRelationship(     rsi.optString("maturityRelationship",     ""));
                info.setLengthOfResidency(        rsi.optString("lengthOfResidency",        ""));
                info.setPersona(                  rsi.optString("persona",                  ""));
                info.setLicensingAuthority(       rsi.optString("licensingAuthority",       ""));
                info.setAdverseMediaResults(      rsi.optString("adverseMediaResults",      ""));
                info.setCountryOfBirth(           rsi.optString("countryOfBirth",           ""));
                info.setAnnualTurnoverExpected(   rsi.optString("annualTurnoverExpected",   ""));
                info.setPersonalAccountsUtilizedForCommercialActivity(
                        rsi.optString("personalAccountsUtilizedForCommercialActivity", ""));
                info.setCustomerreportedtoRegulator(
                        rsi.optString("customerreportedtoRegulator", ""));
                info.setLengthOfEstablishment(    rsi.optString("lengthOfEstablishment",    ""));
                info.setCountryOfEstablishment(   rsi.optString("countryOfEstablishment",   ""));
                info.setLayersInComplexOwnershipStructure(
                        rsi.optString("layersInComplexOwnershipStructure", ""));
                info.setNonResidentUboOrCustomer( rsi.optString("nonResidentUboOrCustomer", ""));

                response.setRiskScoreInfo(info);
            }

        } catch (Exception e) {
            logger.error("[CRAM-PARSE] Error parsing CRAM response: " + e.getMessage(), e);
        }
        return response;
    }

    // =========================================================================
    // 7. Audit Logging  → NG_DPL_XMLLOG_HISTORY
    // =========================================================================

    /**
     * Logs each CRAM API interaction to NG_DPL_XMLLOG_HISTORY.
     * Mirrors insertIntoDb() from DPL_executeOCR.java.
     */
    public static void insertAuditLog(String inputBody,
                                      String outputBody,
                                      String requestId,
                                      String wiName,
                                      String httpCode,
                                      String cabinetName,
                                      String sessionID,
                                      String reqDateTime,
                                      Logger logger) {
        try {
            DateFormat dateFormat           = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String formattedEntryDatetime   = dateFormat.format(new Date());

            // Sanitize for SQL - escape single quotes
            String safeInput  = (inputBody  != null) ? inputBody.replace("'", "''")  : "";
            String safeOutput = (outputBody != null) ? outputBody.replace("'", "''") : "";

            String columnNames  = "WI_NAME, ACT_DATE_TIME, REQ_DATE_TIME, INPUT_XML, OUTPUT_XML, "
                                + "CALLNAME, WORKSTEP_NAME, USER_NAME, MESSAGE_ID";
            String columnValues = "'" + wiName                 + "',"
                                + "'" + formattedEntryDatetime + "',"
                                + "'" + reqDateTime            + "',"
                                + "'" + safeInput              + "',"
                                + "'" + safeOutput             + "',"
                                + "'CRAM_Integration',"
                                + "'Sys_CRAM',"
                                + "'Utility',"
                                + "'" + requestId              + "'";

            String ipXml = CommonMethods.apInsert(cabinetName, sessionID,
                    columnNames, columnValues, "NG_DPL_XMLLOG_HISTORY");
            logger.debug("[CRAM-AUDIT] Insert InputXML: " + ipXml);

            String opXml   = CommonMethods.WFNGExecute(ipXml,
                    CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);
            XMLParser parser = new XMLParser(opXml);
            String mainCode  = parser.getValueOf("MainCode");

            if ("0".equalsIgnoreCase(mainCode)) {
                logger.debug("[CRAM-AUDIT] Audit log inserted successfully. RequestId=" + requestId);
            } else {
                logger.warn("[CRAM-AUDIT] Audit log insert failed. MainCode=" + mainCode);
            }
        } catch (Exception e) {
            logger.error("[CRAM-AUDIT] Exception in audit log: " + e.getMessage(), e);
        }
    }
}
