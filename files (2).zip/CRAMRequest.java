package com.newgen.DPL.CRAM;

import java.util.List;

/**
 * CRAM Request POJO
 * Maps to CRAM Decision Engine API - POST /viya-cram-0/rrc
 * Spec: CRAM.yaml v1.0.0
 */
public class CRAMRequest {

    // ── Static / Config-driven fields ─────────────────────────────────────────
    private String serviceId;           // e.g. CRAM_DecisionEngine_V1
    private String serviceType;         // e.g. DecisionEngineCRAM
    private String serviceChannelId;    // e.g. WBA
    private String journey;             // e.g. DAO
    private String businessSegment;     // e.g. PBD
    private String businessSubsegment;  // e.g. PBN
    private String deliveryChannel;     // e.g. FF (Face to Face)

    // ── Request metadata ──────────────────────────────────────────────────────
    private String requestId;           // UUID generated per request
    private String timeStamp;           // dd/MM/yyyy H:mm
    private String userId;              // IBPS operator/system user

    // ── Customer identity ─────────────────────────────────────────────────────
    private String custType;            // REQUIRED - Individual / Corporate
    private String type;                // NTB / ETB
    private String custIdType;          // e.g. CIF
    private String custIdValue;         // CIF number
    private String customerName;

    // ── Risk parameters - dynamic, sourced from IBPS workflow ─────────────────
    private List<String> nationality;           // from IBPS workflow data
    private List<String> demographic;           // from IBPS workflow data
    private String      lengthOfResidency;      // from DEH createWorkItem (NTB non-UAE)
    private String      persona;                // e.g. CO (Card Only)
    private List<String> industry;              // from DEH createWorkItem (salaried)
    private String      pepStatus;              // updated by ops user in IBPS UI after FIRCO
    private Double      hnwi;                   // High Net Worth Individual indicator
    private Double      hnwe;                   // High Net Worth Entity indicator
    private List<Double> cashTurnoverPerc;      // list of cash turnover percentages
    private String      maturityRelationship;   // BOCIFCREATEDDATE from inquireECIFDetails (Dedupe only)
    private String      licensingAuthority;     // BBG/corporate customers
    private List<String> product;               // from Account Summary API - ACTIVE only
    private List<String> currency;              // from Account Summary API
    private String      adverseMediaResults;    // Y / N
    private List<String> countryOfBirth;        // NTB: from EFR; ETB: from Finacle

    // ── Corporate/BBG specific fields ─────────────────────────────────────────
    private Double      annualTurnoverExpected;
    private String      personalAccountsUtilizedForCommercialActivity; // Y / N
    private String      customerReportedToRegulator;                   // Y / N
    private String      lengthOfEstablishment;
    private List<String> countryOfEstablishment;
    private String      layersInComplexOwnershipStructure;
    private String      nonResidentUboOrCustomer;                      // Y / N

    // ── Getters & Setters ─────────────────────────────────────────────────────

    public String getServiceId() { return serviceId; }
    public void setServiceId(String serviceId) { this.serviceId = serviceId; }

    public String getServiceType() { return serviceType; }
    public void setServiceType(String serviceType) { this.serviceType = serviceType; }

    public String getServiceChannelId() { return serviceChannelId; }
    public void setServiceChannelId(String serviceChannelId) { this.serviceChannelId = serviceChannelId; }

    public String getJourney() { return journey; }
    public void setJourney(String journey) { this.journey = journey; }

    public String getBusinessSegment() { return businessSegment; }
    public void setBusinessSegment(String businessSegment) { this.businessSegment = businessSegment; }

    public String getBusinessSubsegment() { return businessSubsegment; }
    public void setBusinessSubsegment(String businessSubsegment) { this.businessSubsegment = businessSubsegment; }

    public String getDeliveryChannel() { return deliveryChannel; }
    public void setDeliveryChannel(String deliveryChannel) { this.deliveryChannel = deliveryChannel; }

    public String getRequestId() { return requestId; }
    public void setRequestId(String requestId) { this.requestId = requestId; }

    public String getTimeStamp() { return timeStamp; }
    public void setTimeStamp(String timeStamp) { this.timeStamp = timeStamp; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getCustType() { return custType; }
    public void setCustType(String custType) { this.custType = custType; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getCustIdType() { return custIdType; }
    public void setCustIdType(String custIdType) { this.custIdType = custIdType; }

    public String getCustIdValue() { return custIdValue; }
    public void setCustIdValue(String custIdValue) { this.custIdValue = custIdValue; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public List<String> getNationality() { return nationality; }
    public void setNationality(List<String> nationality) { this.nationality = nationality; }

    public List<String> getDemographic() { return demographic; }
    public void setDemographic(List<String> demographic) { this.demographic = demographic; }

    public String getLengthOfResidency() { return lengthOfResidency; }
    public void setLengthOfResidency(String lengthOfResidency) { this.lengthOfResidency = lengthOfResidency; }

    public String getPersona() { return persona; }
    public void setPersona(String persona) { this.persona = persona; }

    public List<String> getIndustry() { return industry; }
    public void setIndustry(List<String> industry) { this.industry = industry; }

    public String getPepStatus() { return pepStatus; }
    public void setPepStatus(String pepStatus) { this.pepStatus = pepStatus; }

    public Double getHnwi() { return hnwi; }
    public void setHnwi(Double hnwi) { this.hnwi = hnwi; }

    public Double getHnwe() { return hnwe; }
    public void setHnwe(Double hnwe) { this.hnwe = hnwe; }

    public List<Double> getCashTurnoverPerc() { return cashTurnoverPerc; }
    public void setCashTurnoverPerc(List<Double> cashTurnoverPerc) { this.cashTurnoverPerc = cashTurnoverPerc; }

    public String getMaturityRelationship() { return maturityRelationship; }
    public void setMaturityRelationship(String maturityRelationship) { this.maturityRelationship = maturityRelationship; }

    public String getLicensingAuthority() { return licensingAuthority; }
    public void setLicensingAuthority(String licensingAuthority) { this.licensingAuthority = licensingAuthority; }

    public List<String> getProduct() { return product; }
    public void setProduct(List<String> product) { this.product = product; }

    public List<String> getCurrency() { return currency; }
    public void setCurrency(List<String> currency) { this.currency = currency; }

    public String getAdverseMediaResults() { return adverseMediaResults; }
    public void setAdverseMediaResults(String adverseMediaResults) { this.adverseMediaResults = adverseMediaResults; }

    public List<String> getCountryOfBirth() { return countryOfBirth; }
    public void setCountryOfBirth(List<String> countryOfBirth) { this.countryOfBirth = countryOfBirth; }

    public Double getAnnualTurnoverExpected() { return annualTurnoverExpected; }
    public void setAnnualTurnoverExpected(Double annualTurnoverExpected) { this.annualTurnoverExpected = annualTurnoverExpected; }

    public String getPersonalAccountsUtilizedForCommercialActivity() { return personalAccountsUtilizedForCommercialActivity; }
    public void setPersonalAccountsUtilizedForCommercialActivity(String v) { this.personalAccountsUtilizedForCommercialActivity = v; }

    public String getCustomerReportedToRegulator() { return customerReportedToRegulator; }
    public void setCustomerReportedToRegulator(String customerReportedToRegulator) { this.customerReportedToRegulator = customerReportedToRegulator; }

    public String getLengthOfEstablishment() { return lengthOfEstablishment; }
    public void setLengthOfEstablishment(String lengthOfEstablishment) { this.lengthOfEstablishment = lengthOfEstablishment; }

    public List<String> getCountryOfEstablishment() { return countryOfEstablishment; }
    public void setCountryOfEstablishment(List<String> countryOfEstablishment) { this.countryOfEstablishment = countryOfEstablishment; }

    public String getLayersInComplexOwnershipStructure() { return layersInComplexOwnershipStructure; }
    public void setLayersInComplexOwnershipStructure(String v) { this.layersInComplexOwnershipStructure = v; }

    public String getNonResidentUboOrCustomer() { return nonResidentUboOrCustomer; }
    public void setNonResidentUboOrCustomer(String nonResidentUboOrCustomer) { this.nonResidentUboOrCustomer = nonResidentUboOrCustomer; }
}
