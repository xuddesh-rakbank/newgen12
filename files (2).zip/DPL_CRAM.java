package com.newgen.DPL.CRAM;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.newgen.DPL.Digital_PL_Log;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;

/**
 * DPL_CRAM
 *
 * Main orchestrator Runnable for CRAM risk calculation integration from IBPS.
 *
 * DESIGN: Generic workstep trigger.
 * ──────────────────────────────────────────────────────────────────────────────
 * IBPS can trigger CRAM from ANY workstep / button click.
 * The workstep name(s) to monitor are configured in DPL_CRAM.properties
 * under key: CRAM_TRIGGER_WORKSTEPS  (comma-separated list)
 * e.g. CRAM_TRIGGER_WORKSTEPS=SYS_CRAM_RISK,SYS_CRAM_RETRIGGER
 *
 * Flow per work item:
 *   1. Fetch work items from configured queue(s)
 *   2. For each WI - fetch CIF and all dynamic fields from IBPS DB
 *   3. Call ACCOUNT_SUMMARY via MW to get active products + currencies
 *   4. [Dedupe cases only] Call CUSTOMER_DETAILS via MW for CIF created date
 *   5. Build CRAMRequest, call DPL_executeCRAM.callCRAMRiskAPI()
 *   6. Store risk result back into IBPS WI attributes
 *   7. Done WI (move to next workstep)
 * ──────────────────────────────────────────────────────────────────────────────
 */
public class DPL_CRAM implements Runnable {

    private static NGEjbClient ngEjbClient;
    private static Logger      logger;

    // Config map loaded from DPL_CRAM.properties
    static Map<String, String> configMap = new HashMap<>();

    // ── Instance-level config fields ──────────────────────────────────────────
    private String  cabinetName;
    private String  jtsIP;
    private String  jtsPort;
    private String  sessionID;
    private int     sleepIntervalInMin;

    // Kong config
    private String  kongTokenEndpoint;      // POST /SASLogon/oauth/token
    private String  kongCramEndpoint;       // POST /viya-cram-0/rrc
    private String  kongApiKey;
    private String  kongApiJksPassword;
    private String  kongApiClientId;
    private String  kongApiClientSecret;

    // CRAM static/config fields (set once, used in every request)
    private String  cramServiceId;
    private String  cramServiceType;
    private String  cramServiceChannelId;
    private String  cramUserId;
    private String  cramJourney;
    private String  cramBusinessSegment;
    private String  cramBusinessSubsegment;
    private String  cramDeliveryChannel;

    // Queue and workstep config
    private String  queueID;
    private List<String> cramTriggerWorksteps;   // generic - multiple worksteps supported

    // Mail config
    private String  fromMailID;
    private String  toMailID;
    private String  mailSubject;
    private String  mailStr;

    // =========================================================================
    // Constructor
    // =========================================================================
    public DPL_CRAM() throws NGException {
        Digital_PL_Log.setLogger(getClass().getSimpleName());
        this.ngEjbClient = NGEjbClient.getSharedInstance();
        logger = Digital_PL_Log.getLogger(getClass().getSimpleName());
    }

    // =========================================================================
    // Runnable Entry Point
    // =========================================================================
    @Override
    public void run() {
        try {
            logger.debug("[CRAM] ===== DPL_CRAM Utility Started =====");

            int configStatus = readConfig();
            if (configStatus != 0) {
                logger.error("[CRAM] Failed to read config. Aborting.");
                return;
            }

            cabinetName = CommonConnection.getCabinetName();
            jtsIP       = CommonConnection.getJTSIP();
            jtsPort     = CommonConnection.getJTSPort();

            sessionID   = CommonConnection.getSessionID(logger, false);
            if (sessionID == null || sessionID.trim().isEmpty()) {
                logger.error("[CRAM] Could not obtain Newgen session. Aborting.");
                return;
            }

            logger.debug("[CRAM] Session acquired. Cabinet=" + cabinetName);

            // Continuous polling loop
            while (true) {
                logger.debug("[CRAM] ===== Poll Cycle Start =====");
                try {
                    processCRAMWorkItems();
                } catch (Exception loopEx) {
                    logger.error("[CRAM] Error in poll cycle: " + loopEx.getMessage(), loopEx);
                }
                logger.debug("[CRAM] Sleeping " + sleepIntervalInMin + " min(s)...");
                Thread.sleep(sleepIntervalInMin * 60L * 1000L);
            }

        } catch (Exception e) {
            final Writer sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            logger.error("[CRAM] Fatal error: " + sw.toString());
        }
    }

    // =========================================================================
    // Config Reader
    // =========================================================================
    private int readConfig() {
        try {
            Properties p = new Properties();
            String configPath = System.getProperty("user.dir")
                    + File.separator + "ConfigFiles"
                    + File.separator + "DPL_CRAM.properties";

            logger.debug("[CRAM-CONFIG] Loading: " + configPath);
            p.load(new FileInputStream(new File(configPath)));

            Enumeration<?> names = p.propertyNames();
            while (names.hasMoreElements()) {
                String key = (String) names.nextElement();
                configMap.put(key, p.getProperty(key));
            }

            // ── Assign all config fields ───────────────────────────────────
            sleepIntervalInMin      = Integer.parseInt(getConf("SleepIntervalInMin", "5"));
            queueID                 = getConf("QueueID", "");

            kongTokenEndpoint       = getConf("Kong_Token_Endpoint", "");
            kongCramEndpoint        = getConf("Kong_CRAM_Endpoint",  "");
            kongApiKey              = getConf("Kong_API_KEY",        "");
            kongApiJksPassword      = getConf("Kong_API_JKS_Password","");
            kongApiClientId         = getConf("Kong_API_client_id",  "");
            kongApiClientSecret     = getConf("Kong_API_client_secret","");

            cramServiceId           = getConf("CRAM_ServiceId",           "CRAM_DecisionEngine_V1");
            cramServiceType         = getConf("CRAM_ServiceType",          "DecisionEngineCRAM");
            cramServiceChannelId    = getConf("CRAM_ServiceChannelId",     "WBA");
            cramUserId              = getConf("CRAM_UserId",               "IBPS_SYSTEM");
            cramJourney             = getConf("CRAM_Journey",              "DAO");
            cramBusinessSegment     = getConf("CRAM_BusinessSegment",      "PBD");
            cramBusinessSubsegment  = getConf("CRAM_BusinessSubsegment",   "PBN");
            cramDeliveryChannel     = getConf("CRAM_DeliveryChannel",      "FF");

            fromMailID              = getConf("fromMailID",  "");
            toMailID                = getConf("toMailID",    "");
            mailSubject             = getConf("mailSubject", "CRAM Integration Error");
            mailStr                 = getConf("MailStr",     "");

            // Generic workstep list - comma separated
            String workstepsRaw     = getConf("CRAM_TRIGGER_WORKSTEPS", "SYS_CRAM_RISK");
            cramTriggerWorksteps    = new ArrayList<>();
            for (String ws : workstepsRaw.split(",")) {
                String trimmed = ws.trim();
                if (!trimmed.isEmpty()) cramTriggerWorksteps.add(trimmed);
            }

            logger.debug("[CRAM-CONFIG] Loaded. Queue=" + queueID
                    + " Worksteps=" + cramTriggerWorksteps
                    + " KongTokenEndpoint=" + kongTokenEndpoint
                    + " KongCRAMEndpoint=" + kongCramEndpoint);

            return 0;
        } catch (Exception e) {
            logger.error("[CRAM-CONFIG] Error reading config: " + e.getMessage(), e);
            return -1;
        }
    }

    private String getConf(String key, String defaultVal) {
        String val = configMap.get(key);
        return (val != null && !val.trim().isEmpty()) ? val.trim() : defaultVal;
    }

    // =========================================================================
    // Main Processing Loop - fetch and process IBPS work items
    // =========================================================================
    private void processCRAMWorkItems() {
        try {
            // Refresh session each cycle
            sessionID = CommonConnection.getSessionID(logger, false);
            if (sessionID == null || sessionID.trim().isEmpty()) {
                logger.error("[CRAM] Invalid session, skipping cycle.");
                return;
            }

            // Fetch work items from queue
            String fetchInputXML  = CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
            logger.debug("[CRAM] FetchWorkItems Input: " + fetchInputXML);

            String fetchOutputXML = WFNGExecute(fetchInputXML, jtsIP, jtsPort, 1);
            logger.debug("[CRAM] FetchWorkItems Output: " + fetchOutputXML);

            XMLParser fetchParser  = new XMLParser(fetchOutputXML);
            String fetchMainCode   = fetchParser.getValueOf("MainCode");
            int    fetchCount      = Integer.parseInt(fetchParser.getValueOf("RetrievedCount"));

            logger.debug("[CRAM] FetchMainCode=" + fetchMainCode + " Count=" + fetchCount);

            if (!"0".equalsIgnoreCase(fetchMainCode) || fetchCount <= 0) {
                logger.debug("[CRAM] No work items in queue. MainCode=" + fetchMainCode);
                return;
            }

            for (int i = 0; i < fetchCount; i++) {

                String instrumentXml = fetchParser.getNextValueOf("Instrument");
                instrumentXml = instrumentXml.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

                XMLParser wiParser       = new XMLParser(instrumentXml);
                String processInstanceID = wiParser.getValueOf("ProcessInstanceId");
                String workItemID        = wiParser.getValueOf("WorkItemId");
                String activityID        = wiParser.getValueOf("WorkStageId");
                String activityType      = wiParser.getValueOf("ActivityType");
                String processDefId      = wiParser.getValueOf("RouteId");
                String activityName      = wiParser.getValueOf("ActivityName");
                String entryDateTime     = wiParser.getValueOf("EntryDateTime");

                logger.debug("[CRAM] Processing WI=" + processInstanceID
                        + " WorkStep=" + activityName);

                // ── Generic workstep check ─────────────────────────────────
                // Only process WIs that are at a configured CRAM trigger workstep
                if (!isCramTriggerWorkstep(activityName)) {
                    logger.debug("[CRAM] WorkStep '" + activityName
                            + "' not in CRAM trigger list. Skipping WI=" + processInstanceID);
                    continue;
                }

                // Process this work item
                processSingleWorkItem(processInstanceID, workItemID, activityID,
                        activityType, processDefId, activityName, entryDateTime);
            }

        } catch (Exception e) {
            logger.error("[CRAM] Error in processCRAMWorkItems: " + e.getMessage(), e);
        }
    }

    /**
     * Returns true if the given workstep name is in the configured trigger list.
     * Case-insensitive match.
     */
    private boolean isCramTriggerWorkstep(String activityName) {
        if (activityName == null) return false;
        for (String ws : cramTriggerWorksteps) {
            if (ws.equalsIgnoreCase(activityName.trim())) return true;
        }
        return false;
    }

    // =========================================================================
    // Single Work Item Processing
    // =========================================================================
    private void processSingleWorkItem(String processInstanceID,
                                       String workItemID,
                                       String activityID,
                                       String activityType,
                                       String processDefId,
                                       String activityName,
                                       String entryDateTime) {

        String errDesc      = "";
        String decisionValue = "Submit";
        String msgId         = UUID.randomUUID().toString();

        try {
            logger.debug("[CRAM-WI] ===== Processing WI=" + processInstanceID + " =====");

            // ── Step 1: Fetch WI dynamic data from IBPS DB ─────────────────
            Map<String, String> wiData = fetchWorkItemData(processInstanceID);
            if (wiData == null || wiData.isEmpty()) {
                errDesc = "Failed to fetch WI data for WI=" + processInstanceID;
                logger.error("[CRAM-WI] " + errDesc);
                doneWorkItem(processInstanceID, workItemID, activityID, processDefId,
                        activityType, decisionValue, errDesc, msgId, activityName, entryDateTime);
                return;
            }

            String cif         = wiData.getOrDefault("CIF",         "");
            String custType    = wiData.getOrDefault("CUST_TYPE",   "Individual");
            String custNtbEtb  = wiData.getOrDefault("NTB_ETB",     "NTB");
            String custName    = wiData.getOrDefault("CUST_NAME",   "");
            String isDedupe    = wiData.getOrDefault("IS_DEDUPE",   "N");
            String cifCreatedDate = wiData.getOrDefault("CIF_CREATED_DATE", "");

            logger.debug("[CRAM-WI] CIF=" + cif + " CustType=" + custType
                    + " NTB/ETB=" + custNtbEtb + " IsDedupe=" + isDedupe);

            // ── Step 2: Fetch Account Summary (products + currencies) ───────
            Map<String, List<String>> accountSummary = fetchAccountSummary(processInstanceID, cif);
            List<String> activeProducts  = accountSummary.getOrDefault("products",  new ArrayList<>());
            List<String> activeCurrencies= accountSummary.getOrDefault("currencies",new ArrayList<>());

            logger.debug("[CRAM-WI] Products=" + activeProducts + " Currencies=" + activeCurrencies);

            // ── Step 3: [Dedupe only] Fetch CIF created date ────────────────
            // For Dedupe cases where CIF is finalized: call CUSTOMER_DETAILS → inquireECIFDetails
            // For all other cases: use CIF created date received from DEH on createWorkItem
            if ("Y".equalsIgnoreCase(isDedupe) && (cifCreatedDate == null || cifCreatedDate.isEmpty())) {
                logger.debug("[CRAM-WI] Dedupe case - fetching CIF created date from MW/Finacle...");
                cifCreatedDate = fetchCIFCreatedDate(processInstanceID, cif);
            }

            logger.debug("[CRAM-WI] CIF Created Date (maturityRelationship)=" + cifCreatedDate);

            // ── Step 4: Get auth token ──────────────────────────────────────
            String authToken = DPL_executeCRAM.getAuthToken(
                    logger, kongApiJksPassword, kongTokenEndpoint,
                    kongApiKey, kongApiClientId, kongApiClientSecret);

            if (authToken == null || authToken.trim().isEmpty()) {
                errDesc = "Failed to obtain CRAM auth token for WI=" + processInstanceID;
                logger.error("[CRAM-WI] " + errDesc);
                doneWorkItem(processInstanceID, workItemID, activityID, processDefId,
                        activityType, decisionValue, errDesc, msgId, activityName, entryDateTime);
                return;
            }

            // ── Step 5: Build CRAM Request ──────────────────────────────────
            CRAMRequest cramRequest = buildCRAMRequest(wiData, activeProducts, activeCurrencies,
                    cifCreatedDate, cif, custType, custNtbEtb, custName);

            // ── Step 6: Call CRAM Risk API ──────────────────────────────────
            CRAMResponse cramResponse = DPL_executeCRAM.callCRAMRiskAPI(
                    authToken, kongApiKey, kongCramEndpoint,
                    cramRequest, processInstanceID,
                    cabinetName, sessionID, logger, kongApiJksPassword);

            if (cramResponse == null) {
                errDesc = "CRAM API returned null response for WI=" + processInstanceID;
                logger.error("[CRAM-WI] " + errDesc);
                doneWorkItem(processInstanceID, workItemID, activityID, processDefId,
                        activityType, decisionValue, errDesc, msgId, activityName, entryDateTime);
                return;
            }

            // ── Step 7: Store risk result back in IBPS WI attributes ────────
            String riskCategory   = cramResponse.getRiskCategory()    != null ? cramResponse.getRiskCategory()    : "";
            String totalRiskScore = cramResponse.getTotalRiskScore()  != null ? String.valueOf(cramResponse.getTotalRiskScore()) : "";
            String overallRating  = cramResponse.getOverallRiskRating()!= null? String.valueOf(cramResponse.getOverallRiskRating()) : "";

            logger.debug("[CRAM-WI] Risk Result: Category=" + riskCategory
                    + " Score=" + totalRiskScore + " Rating=" + overallRating);

            // Persist risk result to IBPS extension table
            persistRiskResultToDb(processInstanceID, riskCategory, totalRiskScore,
                    overallRating, cramResponse, cramRequest.getRequestId());

            // ── Step 8: Done WI ─────────────────────────────────────────────
            errDesc = "CRAM_SUCCESS|Category=" + riskCategory
                    + "|Score=" + totalRiskScore + "|Rating=" + overallRating;

            doneWorkItem(processInstanceID, workItemID, activityID, processDefId,
                    activityType, decisionValue, errDesc, msgId, activityName, entryDateTime);

            logger.debug("[CRAM-WI] ===== WI=" + processInstanceID + " Completed =====");

        } catch (Exception e) {
            logger.error("[CRAM-WI] Unexpected error for WI=" + processInstanceID
                    + ": " + e.getMessage(), e);
            errDesc = "Exception: " + e.getMessage();
            try {
                doneWorkItem(processInstanceID, workItemID, activityID, processDefId,
                        activityType, decisionValue, errDesc, msgId, activityName, entryDateTime);
            } catch (Exception doneEx) {
                logger.error("[CRAM-WI] Error in doneWI fallback: " + doneEx.getMessage(), doneEx);
            }
        }
    }

    // =========================================================================
    // Step 1: Fetch WI Dynamic Data from IBPS DB
    // =========================================================================

    /**
     * Fetches all dynamic fields needed for the CRAM API from IBPS extension table.
     * Fields include CIF, NTB/ETB, nationality, demographic, PEP status, industry, etc.
     *
     * Table: NG_DAO_CRAM_WI_DATA  (or NG_DPL_EXTTABLE - adjust to your schema)
     */
    private Map<String, String> fetchWorkItemData(String processInstanceID) {
        Map<String, String> data = new HashMap<>();
        try {
            // TODO: Adjust column names to match your actual IBPS extension table schema
            String query = "SELECT CIF, CUST_TYPE, NTB_ETB, CUST_NAME, NATIONALITY, DEMOGRAPHIC, "
                         + "PEP_STATUS, INDUSTRY, SUB_INDUSTRY, PERSONA, HNWI, HNWE, "
                         + "CASH_TURNOVER_PERC, ADVERSE_MEDIA, COUNTRY_OF_BIRTH, "
                         + "LENGTH_OF_RESIDENCY, LICENSING_AUTHORITY, "
                         + "ANNUAL_TURNOVER_EXPECTED, PERSONAL_ACC_FOR_COMMERCIAL, "
                         + "CUST_REPORTED_TO_REGULATOR, LENGTH_OF_ESTABLISHMENT, "
                         + "COUNTRY_OF_ESTABLISHMENT, LAYERS_OWNERSHIP, NON_RESIDENT_UBO, "
                         + "IS_DEDUPE, CIF_CREATED_DATE "
                         + "FROM NG_DAO_CRAM_WI_DATA WITH(NOLOCK) "
                         + "WHERE WI_NAME = '" + processInstanceID + "'";

            String ipXml = CommonMethods.apSelectWithColumnNames(
                    query, cabinetName, sessionID);
            String opXml = WFNGExecute(ipXml, jtsIP, jtsPort, 1);

            XMLParser parser   = new XMLParser(opXml);
            String mainCode    = parser.getValueOf("MainCode");
            int totalRetrieved = Integer.parseInt(parser.getValueOf("TotalRetrieved"));

            if ("0".equalsIgnoreCase(mainCode) && totalRetrieved > 0) {
                NGXmlList recordList = parser.createList("Records", "Record");
                if (recordList.hasMoreElements(true)) {
                    // Map all columns
                    String[] columns = {
                        "CIF","CUST_TYPE","NTB_ETB","CUST_NAME","NATIONALITY","DEMOGRAPHIC",
                        "PEP_STATUS","INDUSTRY","SUB_INDUSTRY","PERSONA","HNWI","HNWE",
                        "CASH_TURNOVER_PERC","ADVERSE_MEDIA","COUNTRY_OF_BIRTH",
                        "LENGTH_OF_RESIDENCY","LICENSING_AUTHORITY",
                        "ANNUAL_TURNOVER_EXPECTED","PERSONAL_ACC_FOR_COMMERCIAL",
                        "CUST_REPORTED_TO_REGULATOR","LENGTH_OF_ESTABLISHMENT",
                        "COUNTRY_OF_ESTABLISHMENT","LAYERS_OWNERSHIP","NON_RESIDENT_UBO",
                        "IS_DEDUPE","CIF_CREATED_DATE"
                    };
                    for (String col : columns) {
                        data.put(col, recordList.getVal(col));
                    }
                }
                logger.debug("[CRAM-DATA] Fetched WI data. CIF=" + data.get("CIF"));
            } else {
                logger.warn("[CRAM-DATA] No data found for WI=" + processInstanceID
                        + " MainCode=" + mainCode);
            }
        } catch (Exception e) {
            logger.error("[CRAM-DATA] Error fetching WI data: " + e.getMessage(), e);
        }
        return data;
    }

    // =========================================================================
    // Step 2: Fetch Account Summary (Active Products + Currencies)
    // =========================================================================

    /**
     * Calls MW ACCOUNT_SUMMARY to get list of active products and currencies.
     * Per architecture: "Account summary call to be invoked to fetch products
     * and currencies before calling CRAM API. Only active products to be sent."
     *
     * This calls the existing IBPS-MW integration for ACCOUNT_SUMMARY.
     * Adjust the DB query/MW call to match your actual integration pattern.
     */
    private Map<String, List<String>> fetchAccountSummary(String processInstanceID, String cif) {
        Map<String, List<String>> result = new HashMap<>();
        List<String> products   = new ArrayList<>();
        List<String> currencies = new ArrayList<>();
        result.put("products",   products);
        result.put("currencies", currencies);

        try {
            // Query IBPS DB for account summary data already populated by MW call
            // MW ACCOUNT_SUMMARY → getAccountList → product list stored in IBPS table
            // TODO: Adjust table/column names to match your ACCOUNT_SUMMARY result table
            String query = "SELECT PRODUCT_CODE, CURRENCY_CODE "
                         + "FROM NG_DAO_ACCOUNT_SUMMARY WITH(NOLOCK) "
                         + "WHERE WI_NAME = '" + processInstanceID + "' "
                         + "AND IS_ACTIVE = 'Y'";    // Only active products per architecture

            String ipXml = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
            String opXml = WFNGExecute(ipXml, jtsIP, jtsPort, 1);

            XMLParser parser   = new XMLParser(opXml);
            String mainCode    = parser.getValueOf("MainCode");
            int totalRetrieved = Integer.parseInt(parser.getValueOf("TotalRetrieved"));

            if ("0".equalsIgnoreCase(mainCode) && totalRetrieved > 0) {
                NGXmlList recordList = parser.createList("Records", "Record");
                while (recordList.hasMoreElements(true)) {
                    String productCode  = recordList.getVal("PRODUCT_CODE");
                    String currencyCode = recordList.getVal("CURRENCY_CODE");

                    if (productCode  != null && !productCode.trim().isEmpty()
                            && !products.contains(productCode.trim())) {
                        products.add(productCode.trim());
                    }
                    if (currencyCode != null && !currencyCode.trim().isEmpty()
                            && !currencies.contains(currencyCode.trim())) {
                        currencies.add(currencyCode.trim());
                    }
                    recordList.skip(true);
                }
                logger.debug("[CRAM-ACCT] Products=" + products + " Currencies=" + currencies);
            } else {
                logger.warn("[CRAM-ACCT] No account summary data. WI=" + processInstanceID
                        + " CIF=" + cif + " MainCode=" + mainCode);
            }
        } catch (Exception e) {
            logger.error("[CRAM-ACCT] Error fetching account summary: " + e.getMessage(), e);
        }
        return result;
    }

    // =========================================================================
    // Step 3: Fetch CIF Created Date (Dedupe cases only)
    // =========================================================================

    /**
     * For Dedupe cases where CIF is finalized:
     * Calls CUSTOMER_DETAILS → MW → Finacle (inquireECIFDetails)
     * Returns BOCIFCREATEDDATE to use as maturityRelationship in CRAM.
     *
     * Per architecture: "IBPS to call CUSTOMER_DETAILS only when CIF is finalized
     * for De-dupe cases. For remaining cases, use CIF created date received from DEH."
     */
    private String fetchCIFCreatedDate(String processInstanceID, String cif) {
        String cifCreatedDate = "";
        try {
            // Query the IBPS table where CRYSTAL/MW CUSTOMER_DETAILS response is stored
            // CRYSTAL → XML/MQ → inquireECIFDetails → Finacle → BOCIFCREATEDDATE
            // TODO: Adjust to your actual CUSTOMER_DETAILS response table/column
            String query = "SELECT BOCIFCREATEDDATE "
                         + "FROM NG_DAO_ECIF_DETAILS WITH(NOLOCK) "
                         + "WHERE WI_NAME = '" + processInstanceID + "'";

            String ipXml = CommonMethods.apSelectWithColumnNames(query, cabinetName, sessionID);
            String opXml = WFNGExecute(ipXml, jtsIP, jtsPort, 1);

            XMLParser parser   = new XMLParser(opXml);
            String mainCode    = parser.getValueOf("MainCode");
            int totalRetrieved = Integer.parseInt(parser.getValueOf("TotalRetrieved"));

            if ("0".equalsIgnoreCase(mainCode) && totalRetrieved > 0) {
                cifCreatedDate = parser.getValueOf("BOCIFCREATEDDATE");
                logger.debug("[CRAM-ECIF] BOCIFCREATEDDATE=" + cifCreatedDate
                        + " for WI=" + processInstanceID);
            } else {
                logger.warn("[CRAM-ECIF] No ECIF data found for WI=" + processInstanceID
                        + " CIF=" + cif);
            }
        } catch (Exception e) {
            logger.error("[CRAM-ECIF] Error fetching CIF created date: " + e.getMessage(), e);
        }
        return cifCreatedDate;
    }

    // =========================================================================
    // Step 5: Build CRAMRequest from WI data
    // =========================================================================

    /**
     * Assembles the full CRAMRequest POJO from:
     *   - Static config fields (from properties)
     *   - Dynamic WI fields (from IBPS DB)
     *   - Account summary (products/currencies from Finacle)
     *   - CIF created date (maturityRelationship)
     */
    private CRAMRequest buildCRAMRequest(Map<String, String> wiData,
                                         List<String> products,
                                         List<String> currencies,
                                         String cifCreatedDate,
                                         String cif,
                                         String custType,
                                         String custNtbEtb,
                                         String custName) {
        CRAMRequest req = new CRAMRequest();

        DateFormat tsFormat = new SimpleDateFormat("dd/MM/yyyy H:mm");

        // ── Static fields from config ──────────────────────────────────────
        req.setServiceId(          cramServiceId);
        req.setServiceType(        cramServiceType);
        req.setServiceChannelId(   cramServiceChannelId);
        req.setUserId(             cramUserId);
        req.setJourney(            cramJourney);
        req.setBusinessSegment(    cramBusinessSegment);
        req.setBusinessSubsegment( cramBusinessSubsegment);
        req.setDeliveryChannel(    cramDeliveryChannel);

        // ── Request metadata ───────────────────────────────────────────────
        req.setRequestId(  UUID.randomUUID().toString());
        req.setTimeStamp(  tsFormat.format(new Date()));

        // ── Customer identity ──────────────────────────────────────────────
        req.setCustIdType( "CIF");
        req.setCustIdValue(cif);
        req.setCustType(   custType);
        req.setType(       custNtbEtb);
        req.setCustomerName(custName);

        // ── Array fields - split pipe/comma delimited DB values ────────────
        req.setNationality(       splitToList(wiData.get("NATIONALITY")));
        req.setDemographic(       splitToList(wiData.get("DEMOGRAPHIC")));
        req.setIndustry(          splitToList(wiData.get("INDUSTRY")));
        req.setCountryOfBirth(    splitToList(wiData.get("COUNTRY_OF_BIRTH")));
        req.setCountryOfEstablishment(splitToList(wiData.get("COUNTRY_OF_ESTABLISHMENT")));

        // ── Products and currencies from Account Summary ───────────────────
        req.setProduct(  products);
        req.setCurrency( currencies);

        // ── Scalar dynamic fields ──────────────────────────────────────────
        req.setLengthOfResidency(  wiData.get("LENGTH_OF_RESIDENCY"));
        req.setPersona(            wiData.get("PERSONA"));
        req.setPepStatus(          wiData.get("PEP_STATUS"));    // updated by ops user post-FIRCO
        req.setAdverseMediaResults(wiData.get("ADVERSE_MEDIA"));
        req.setLicensingAuthority( wiData.get("LICENSING_AUTHORITY"));
        req.setLengthOfEstablishment(wiData.get("LENGTH_OF_ESTABLISHMENT"));
        req.setLayersInComplexOwnershipStructure(wiData.get("LAYERS_OWNERSHIP"));
        req.setNonResidentUboOrCustomer(wiData.get("NON_RESIDENT_UBO"));
        req.setPersonalAccountsUtilizedForCommercialActivity(wiData.get("PERSONAL_ACC_FOR_COMMERCIAL"));
        req.setCustomerReportedToRegulator(wiData.get("CUST_REPORTED_TO_REGULATOR"));

        // ── HNWI / HNWE (numeric) ──────────────────────────────────────────
        req.setHnwi( parseDouble(wiData.get("HNWI")));
        req.setHnwe( parseDouble(wiData.get("HNWE")));
        req.setAnnualTurnoverExpected(parseDouble(wiData.get("ANNUAL_TURNOVER_EXPECTED")));

        // ── Cash Turnover % (array of doubles) ────────────────────────────
        req.setCashTurnoverPerc(splitToDoubleList(wiData.get("CASH_TURNOVER_PERC")));

        // ── maturityRelationship = BOCIFCREATEDDATE (from ECIF/DEH) ────────
        // Format: dd-MM-yyyy as per CRAM spec example "22-02-2026"
        req.setMaturityRelationship(formatMaturityDate(cifCreatedDate));

        logger.debug("[CRAM-BUILD] Request built. CIF=" + cif
                + " ReqId=" + req.getRequestId()
                + " PepStatus=" + req.getPepStatus()
                + " Products=" + products.size()
                + " Currencies=" + currencies.size());

        return req;
    }

    // =========================================================================
    // Step 7: Persist Risk Result to IBPS DB
    // =========================================================================

    /**
     * Stores the CRAM risk result back into the IBPS work item / extension table.
     * This allows IBPS UI to display the risk score to CF staff.
     */
    private void persistRiskResultToDb(String processInstanceID,
                                       String riskCategory,
                                       String totalRiskScore,
                                       String overallRating,
                                       CRAMResponse response,
                                       String cramRequestId) {
        try {
            // TODO: Adjust table/column names to match your IBPS schema
            String columnNames  = "WI_NAME, RISK_CATEGORY, TOTAL_RISK_SCORE, "
                                + "OVERALL_RISK_RATING, CRAM_REQUEST_ID, UPDATED_DATE";
            String columnValues = "'" + processInstanceID + "',"
                                + "'" + riskCategory  + "',"
                                + "'" + totalRiskScore + "',"
                                + "'" + overallRating  + "',"
                                + "'" + cramRequestId  + "',"
                                + "GETDATE()";

            String ipXml = CommonMethods.apInsert(cabinetName, sessionID,
                    columnNames, columnValues, "NG_DAO_CRAM_RISK_RESULT");
            logger.debug("[CRAM-RESULT] Insert InputXML: " + ipXml);

            String opXml   = WFNGExecute(ipXml, jtsIP, jtsPort, 1);
            XMLParser parser = new XMLParser(opXml);
            String mainCode  = parser.getValueOf("MainCode");

            if ("0".equalsIgnoreCase(mainCode)) {
                logger.debug("[CRAM-RESULT] Risk result stored. WI=" + processInstanceID);
            } else {
                logger.warn("[CRAM-RESULT] Failed to store risk result. MainCode=" + mainCode);
            }
        } catch (Exception e) {
            logger.error("[CRAM-RESULT] Error persisting risk result: " + e.getMessage(), e);
        }
    }

    // =========================================================================
    // Done Work Item  (WMAssignWorkItemAttributes → move WI to next step)
    // =========================================================================

    /**
     * Completes the IBPS work item and moves it to the next workstep.
     * Mirrors doneWiDPL() from DPL_STL_OCR.java reference code.
     */
    private void doneWorkItem(String processInstanceID,
                               String workItemID,
                               String activityID,
                               String processDefId,
                               String activityType,
                               String decisionValue,
                               String errDesc,
                               String msgId,
                               String activityName,
                               String entryDateTime) {
        try {
            // Get work item first
            String getWIInputXML  = CommonMethods.getWorkItemInput(cabinetName, sessionID,
                    processInstanceID, workItemID);
            String getWIOutputXML = WFNGExecute(getWIInputXML, jtsIP, jtsPort, 1);

            XMLParser getWIParser = new XMLParser(getWIOutputXML);
            String getWIMainCode  = getWIParser.getValueOf("MainCode");
            logger.debug("[CRAM-DONE] GetWorkItem MainCode=" + getWIMainCode);

            if (!"0".equalsIgnoreCase(getWIMainCode)) {
                logger.error("[CRAM-DONE] GetWorkItem failed. WI=" + processInstanceID);
                sendMail(processInstanceID, "GetWorkItem Failed", getWIMainCode, processDefId, msgId);
                return;
            }

            // Build attributes tag with CRAM result for WI
            String attributesTag = "<Decision>" + decisionValue + "</Decision>"
                    + "<CRAM_STATUS>" + escapeXml(errDesc) + "</CRAM_STATUS>";

            // WMAssignWorkItemAttributes - complete and move WI
            String assignInputXML = "<?xml version=\"1.0\"?>"
                    + "<WMAssignWorkItemAttributes_Input>"
                    + "<Option>WMAssignWorkItemAttributes</Option>"
                    + "<EngineName>"     + cabinetName        + "</EngineName>"
                    + "<SessionId>"      + sessionID          + "</SessionId>"
                    + "<ProcessInstanceId>" + processInstanceID + "</ProcessInstanceId>"
                    + "<WorkItemId>"     + workItemID         + "</WorkItemId>"
                    + "<ActivityId>"     + activityID         + "</ActivityId>"
                    + "<ProcessDefId>"   + processDefId       + "</ProcessDefId>"
                    + "<LastModifiedTime></LastModifiedTime>"
                    + "<ActivityType>"   + activityType       + "</ActivityType>"
                    + "<complete>D</complete>"
                    + "<AuditStatus></AuditStatus>"
                    + "<Comments></Comments>"
                    + "<UserDefVarFlag>Y</UserDefVarFlag>"
                    + "<Attributes>"     + attributesTag      + "</Attributes>"
                    + "</WMAssignWorkItemAttributes_Input>";

            logger.debug("[CRAM-DONE] AssignAttributes Input: " + assignInputXML);

            String assignOutputXML = WFNGExecute(assignInputXML, jtsIP, jtsPort, 1);
            XMLParser assignParser = new XMLParser(assignOutputXML);
            String assignMainCode  = assignParser.getValueOf("MainCode");

            logger.debug("[CRAM-DONE] AssignAttributes MainCode=" + assignMainCode);

            if ("0".equalsIgnoreCase(assignMainCode)) {
                logger.debug("[CRAM-DONE] WI moved to next step. WI=" + processInstanceID);
                // Log decision history
                logDecisionHistory(processInstanceID, activityName, decisionValue,
                        errDesc, entryDateTime);
            } else {
                logger.error("[CRAM-DONE] DoneWI failed. WI=" + processInstanceID
                        + " MainCode=" + assignMainCode);
                sendMail(processInstanceID, "DoneWI Failed", assignMainCode, processDefId, msgId);
            }

        } catch (Exception e) {
            logger.error("[CRAM-DONE] Exception: " + e.getMessage(), e);
        }
    }

    // =========================================================================
    // Decision History Logger
    // =========================================================================
    private void logDecisionHistory(String processInstanceID, String activityName,
                                     String decisionValue, String errDesc,
                                     String entryDateTime) {
        try {
            DateFormat dateFormat           = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String formattedNow             = dateFormat.format(new Date());
            String formattedEntryDate       = "";
            try {
                Date d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(entryDateTime);
                formattedEntryDate          = dateFormat.format(d);
            } catch (Exception ex) {
                formattedEntryDate = entryDateTime;
            }

            String columnNames  = "WI_NAME, DECISION_DATE_TIME, WORKSTEP, USERNAME, "
                                + "DECISION, REMARKS, ENTRY_DATE_TIME";
            String columnValues = "'" + processInstanceID     + "',"
                                + "'" + formattedNow          + "',"
                                + "'" + activityName          + "',"
                                + "'" + CommonConnection.getUsername() + "',"
                                + "'" + decisionValue         + "',"
                                + "'" + escapeXml(errDesc)    + "',"
                                + "'" + formattedEntryDate    + "'";

            String ipXml = CommonMethods.apInsert(cabinetName, sessionID,
                    columnNames, columnValues, "NG_DPL_GR_DECISION_HISTORY");
            String opXml = WFNGExecute(ipXml, jtsIP, jtsPort, 1);
            XMLParser parser = new XMLParser(opXml);
            logger.debug("[CRAM-HIST] Decision History MainCode=" + parser.getValueOf("MainCode"));

        } catch (Exception e) {
            logger.error("[CRAM-HIST] Error logging decision history: " + e.getMessage(), e);
        }
    }

    // =========================================================================
    // Mail Sender
    // =========================================================================
    private void sendMail(String wiName, String errDesc, String returnCode,
                           String processDefId, String msgId) {
        try {
            String finalMailBody = mailStr
                    .replace("<WI_NAME>",   wiName)
                    .replace("<ret_Code>",  returnCode)
                    .replace("<errormsg>",  errDesc)
                    .replace("<MsgID>",     msgId);

            String columnName   = "MAILFROM,MAILTO,MAILSUBJECT,MAILMESSAGE,MAILCONTENTTYPE,"
                                + "MAILPRIORITY,MAILSTATUS,INSERTEDBY,MAILACTIONTYPE,"
                                + "INSERTEDTIME,PROCESSDEFID,PROCESSINSTANCEID,WORKITEMID,"
                                + "ACTIVITYID,NOOFTRIALS";
            String columnValues = "'" + fromMailID    + "',"
                                + "'" + toMailID      + "',"
                                + "'" + mailSubject   + "',"
                                + "'" + finalMailBody + "',"
                                + "'text/html;charset=UTF-8','1','N','CUSTOM','TRIGGER',"
                                + "'" + CommonMethods.getdateCurrentDateInSQLFormat() + "',"
                                + "'" + processDefId  + "',"
                                + "'" + wiName        + "',"
                                + "'1','1','0'";

            String ipXml = "<?xml version=\"1.0\"?>"
                    + "<APInsert_Input>"
                    + "<Option>APInsert</Option>"
                    + "<TableName>WFMAILQUEUETABLE</TableName>"
                    + "<ColName>"  + columnName   + "</ColName>"
                    + "<Values>"   + columnValues + "</Values>"
                    + "<EngineName>"+ cabinetName + "</EngineName>"
                    + "<SessionId>" + sessionID   + "</SessionId>"
                    + "</APInsert_Input>";

            String opXml = WFNGExecute(ipXml, jtsIP, jtsPort, 0);
            XMLParser parser = new XMLParser(opXml);
            logger.debug("[CRAM-MAIL] Mail queue insert MainCode=" + parser.getValueOf("MainCode"));

        } catch (Exception e) {
            logger.error("[CRAM-MAIL] Error sending mail: " + e.getMessage(), e);
        }
    }

    // =========================================================================
    // Helper: WFNGExecute wrapper
    // =========================================================================
    private String WFNGExecute(String inputXml, String ip, String port, int flag) {
        try {
            return CommonMethods.WFNGExecute(inputXml, ip, port, flag);
        } catch (Exception e) {
            logger.error("[CRAM] WFNGExecute error: " + e.getMessage(), e);
            return "<MainCode>-1</MainCode>";
        }
    }

    // =========================================================================
    // Helper: Data Conversion Utilities
    // =========================================================================

    /**
     * Splits a pipe (|) or comma (,) separated DB string into a List<String>.
     * e.g. "AE|SA" or "AE,SA" → ["AE", "SA"]
     */
    private List<String> splitToList(String value) {
        List<String> list = new ArrayList<>();
        if (value == null || value.trim().isEmpty()) return list;
        String delimiter = value.contains("|") ? "\\|" : ",";
        for (String s : value.split(delimiter)) {
            String trimmed = s.trim();
            if (!trimmed.isEmpty()) list.add(trimmed);
        }
        return list;
    }

    /**
     * Splits a pipe/comma separated string into a List<Double>.
     * e.g. "50.0|32.5" → [50.0, 32.5]
     */
    private List<Double> splitToDoubleList(String value) {
        List<Double> list = new ArrayList<>();
        if (value == null || value.trim().isEmpty()) return list;
        String delimiter = value.contains("|") ? "\\|" : ",";
        for (String s : value.split(delimiter)) {
            try {
                list.add(Double.parseDouble(s.trim()));
            } catch (NumberFormatException ignored) {
                logger.warn("[CRAM-UTIL] Could not parse double: " + s);
            }
        }
        return list;
    }

    /** Safe Double parser - returns null if blank/invalid */
    private Double parseDouble(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try {
            return Double.parseDouble(value.trim());
        } catch (NumberFormatException e) {
            logger.warn("[CRAM-UTIL] Could not parse numeric: " + value);
            return null;
        }
    }

    /**
     * Formats a date string to dd-MM-yyyy for maturityRelationship field.
     * CRAM spec example: "22-02-2026"
     * Handles common date formats from Finacle/DEH.
     */
    private String formatMaturityDate(String rawDate) {
        if (rawDate == null || rawDate.trim().isEmpty()) return "";
        String[] formats = {
            "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "dd/MM/yyyy", "dd-MM-yyyy",
            "MM/dd/yyyy", "yyyyMMdd"
        };
        for (String fmt : formats) {
            try {
                Date d = new SimpleDateFormat(fmt).parse(rawDate.trim());
                return new SimpleDateFormat("dd-MM-yyyy").format(d);
            } catch (Exception ignored) {}
        }
        logger.warn("[CRAM-UTIL] Could not format date: " + rawDate + " - using as-is.");
        return rawDate;
    }

    /** Escapes XML special characters to prevent XML injection in attributes tag */
    private String escapeXml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"","&quot;")
                    .replace("'", "&apos;");
    }
}
