package com.newgen.DPL.lms;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import com.newgen.DPL.Digital_PL_Log;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;
//import com.sun.swing.internal.plaf.synth.resources.synth;

import adminclient.OSASecurity;

public class RLSAgrementID {

	static NGEjbClient ngEjbClient;
	private static org.apache.log4j.Logger logger;
	static Map<String, String> configPropertyMap = new HashMap<String, String>();

	static String sessionID = "";
	static int sessionCheckInt = 0;
	static int loopCount = 2;
	static int waitLoop = 50;
	private static String ActivityType;
	private static String ProcessDefId;
	private static String ActivityName;
	private static String ActivityID;
	private static String WorkItemID;
	private static String entryDateTime;

	public RLSAgrementID() throws NGException {
		Digital_PL_Log.setLogger(getClass().getSimpleName());
		this.ngEjbClient = NGEjbClient.getSharedInstance();
		logger = Digital_PL_Log.getLogger(getClass().getSimpleName());
	}

	public void LMSUpdateWI() {

		System.out.println("Inside Run");
		logger.debug("Inside Run");
		// Read properties file and store data in map
		Supplier<Integer> value = () -> {
			Properties p = null;
			try {

				p = new Properties();
				p.load(new FileInputStream(new File(System.getProperty("user.dir") + File.separator + "ConfigFiles"
						+ File.separator + "LMSAgreementId.properties")));

				Enumeration<?> names = p.propertyNames();

				while (names.hasMoreElements()) {
					String name = (String) names.nextElement();
					configPropertyMap.put(name, p.getProperty(name));
				}
			} catch (Exception e) {
				return -1;
			}
			return 0;
		};

		if (value.get() != 0) {
			logger.debug("Error in config file");
		}

		scheduleDailyCheckAgreementIDTask();
	}

	public static void scheduleDailyCheckAgreementIDTask() {
		logger.debug("Inside scheduleDailyCheckAgreementIDTask");
		
		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);//Executors.newSingleThreadScheduledExecutor();

		// Calculate initial delay
		String scheduledTime = configPropertyMap.get("scheduled.Time");
		int hours = Integer.parseInt(configPropertyMap.get("period.hours"));
		long initialDelay = calculateInitialDelay(LocalTime.parse(scheduledTime));
		long period = hours * 60 * 60; // 1*1*30;//24 * 60 * 60; // 24 hours in

		// database credentials
		String OracleIP = configPropertyMap.get("OracleIP");
		String OraclePort = configPropertyMap.get("OraclePort");
		String UsernameOracle = configPropertyMap.get("UsernameOracle");

		String PasswordOracle = decryptPassword(configPropertyMap.get("PasswordOracle"));
		String OracleServicename = configPropertyMap.get("OracleServicename");
		System.out.println("inside scheduleAtFixedRate"); // seconds

		logger.debug("before  scheduleAtFixedRate");
		logger.debug("scheduledTime:" + scheduledTime);
		logger.debug("initialDelay:" + initialDelay);
		logger.debug("period:" + period);
		
		scheduler.scheduleAtFixedRate(() -> {
			logger.debug("Task executed at: " + LocalDateTime.now());
			
			try {
				logger.debug("inside scheduleAtFixedRate");
				String queueID = configPropertyMap.get("queueID");
				String LMSActivityID = configPropertyMap.get("LMSActivityID");
						
				List<String> wiList = loadWorkItems(queueID);
				logger.debug("wi list" + wiList);

				Class.forName("oracle.jdbc.OracleDriver");
				
				try (Connection con = DriverManager.getConnection(
						"jdbc:oracle:thin:@" + OracleIP + ":" + OraclePort + ":" + OracleServicename, UsernameOracle,
						PasswordOracle)) {
					if (con != null) {
						logger.info("Connection successful" + con);
					}
					
					Statement stmt = con.createStatement();
					
					wiList.stream().forEach(wi -> {
						String agreementNo = getAgrementIdFromOracle(wi, stmt);
						logger.debug(" agreementNo" + agreementNo);
						if ((!"fail".equalsIgnoreCase(agreementNo)) && (!"null".equalsIgnoreCase(agreementNo))
								&& (!"".equalsIgnoreCase(agreementNo)) && agreementNo != null) {
							updateExternalTable("NG_DPL_EXTTABLE", "AgreementID", agreementNo, "WIName='" + wi + "'",
									CommonConnection.getJTSIP(), CommonConnection.getJTSPort(),
									CommonConnection.getCabinetName());

							doneWI(wi, "Success", "agreement no updated", "<Decision>Success</Decision>", sessionID,LMSActivityID);

						}
					});
				} catch (Exception e) {
				
					logger.error(e.getMessage());
					logger.error("error while contion :" + e.getStackTrace());
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Task executed at: " + LocalDateTime.now());
			// Your task logic here
		}, initialDelay, period, TimeUnit.SECONDS);
		
		///----------for source email--------
		scheduler.scheduleAtFixedRate(() -> {
			logger.debug("Task executed at: " + LocalDateTime.now());
			try {
				logger.debug("inside scheduleAtFixedRate for source queue");
				
				String sourceQueueID = configPropertyMap.get("sourceQueueID");
				logger.debug("sourceQueueID:"+sourceQueueID);
				
				String sourceActivityID = configPropertyMap.get("sourceActivityID");
				String expiredDate = configPropertyMap.get("ExpiredDate");
				logger.debug("ExpiredDate:"+expiredDate);
				
				long expireDate = Long.parseLong(expiredDate);
				logger.debug("convert in long expireDate:"+expireDate);
				
				List<String> wiList = loadWorkItems(sourceQueueID);
				logger.debug("wi list" + wiList);
				
				LocalDateTime todayDate = LocalDateTime.now();
				
				wiList.stream().forEach(wi -> {
					logger.debug("wi number:" + wi);
					String entryDateAndAgreementID = getEntryDateTime(wi);
					String []datalist= entryDateAndAgreementID.split(",");
					String entryDate = datalist[0];
					String agreementId = datalist[1];
					logger.debug("entryDate:"+entryDate+", wi number:" + wi);
					logger.debug("agreementId:"+agreementId+", wi number:" + wi);
					
					String dateOnly = entryDate.trim().split(" ")[0];
					logger.debug("entryDate:"+entryDate+", wi number:" + wi);
					
					long daydifference = ChronoUnit.DAYS.between(LocalDate.parse(dateOnly), todayDate);
					logger.debug("daydifference:"+daydifference+", wi number:" + wi);
					if (daydifference >= expireDate && (agreementId.isEmpty()||  "".equalsIgnoreCase(agreementId) || "null".equalsIgnoreCase(agreementId) )) {
						logger.debug(" day difference more then 30 days ");
						doneWI(wi, "Expired", "Wi Expire due to no action", "<Decision>Expired</Decision>", sessionID,sourceActivityID);

					}
				});
			}catch(Exception e){
				
			}
		}, initialDelay, period, TimeUnit.SECONDS);
	}

	private static String getEntryDateTime(String wino){
		try {
			String Query = "select EntryAt,AgreementID from NG_DPL_EXTTABLE where WINAME  ='"
					+ wino + "'";
			logger.debug("Query : " + Query);

			String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(Query, CommonConnection.getCabinetName(),
					CommonConnection.getSessionID(logger, false));

			logger.debug("extTabDataIPXML: " + extTabDataIPXML);
			String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, CommonConnection.getJTSIP(),
					CommonConnection.getJTSPort(), 1);
			logger.debug("extTabDataOPXML: " + extTabDataOPXML);

			XMLParser xmlParserData = new XMLParser(extTabDataOPXML);
			String entryDate = xmlParserData.getValueOf("EntryAt");
			String AgreementID = xmlParserData.getValueOf("AgreementID");
			logger.debug("entryDate: " + entryDate);
			logger.debug("AgreementID: " + AgreementID);
			if("".equalsIgnoreCase(AgreementID))
			{
				AgreementID="null";
			}
			logger.debug("AgreementID: " + AgreementID);
			return entryDate+","+AgreementID;

		}catch(Exception e){
			logger.debug("error getting find entrydate " + e.getMessage());
		}
		return "";
	}
 	private static long calculateInitialDelay(LocalTime scheduledTime) {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime nextRun = now.withHour(scheduledTime.getHour()).withMinute(scheduledTime.getMinute())
				.withSecond(0);

		if (nextRun.isBefore(now)) {
			nextRun = nextRun.plusDays(1); // Schedule for the next day
		}

		return java.time.Duration.between(now, nextRun).getSeconds();
	}

	static synchronized private void updateExternalTable(String tablename, String columnname, String sMessage, String sWhere,
			String jtsIP, String jtsPort, String cabinetName) {
		int sessionCheckInt = 0;
		int loopCount = 50;
		int mainCode = 0;
		String outXmlCheckAPUpdate = null;
		String mainCodeforCheckUpdate = null;

		logger.debug("Inside update EXT table: ");

		while (sessionCheckInt < loopCount) {
			try {
				XMLParser objXMLParser = new XMLParser();

				String inputXmlcheckAPUpdate = CommonMethods.getAPUpdateIpXML(tablename, columnname, sMessage, sWhere,
						cabinetName, sessionID);
				logger.debug(("inputXmlcheckAPUpdate : " + inputXmlcheckAPUpdate));

				outXmlCheckAPUpdate = CommonMethods.WFNGExecute(inputXmlcheckAPUpdate, jtsIP, jtsPort, 1);
				logger.debug(("outXmlCheckAPUpdate : " + outXmlCheckAPUpdate));

				objXMLParser.setInputXML(outXmlCheckAPUpdate);

				mainCodeforCheckUpdate = objXMLParser.getValueOf("MainCode");
				if (!mainCodeforCheckUpdate.equalsIgnoreCase("0")) {
					logger.debug(("Exception in ExecuteQuery_APUpdate updating " + tablename + " table"));
					System.out.println("Exception in ExecuteQuery_APUpdate updating " + tablename + " table");
				} else {
					logger.debug(("Succesfully updated " + tablename + " table"));
					System.out.println("Succesfully updated " + tablename + " table");

				}
				mainCode = Integer.parseInt(mainCodeforCheckUpdate);
				if (mainCode == 11) {
					sessionID = CommonConnection.getSessionID(logger, false);
				} else {
					sessionCheckInt++;
					break;
				}

				if (outXmlCheckAPUpdate.equalsIgnoreCase("") || outXmlCheckAPUpdate == ""
						|| outXmlCheckAPUpdate == null)
					break;

			} catch (Exception e) {
				logger.debug(("Inside create validateSessionID exception" + e.getMessage()));
			}
		}
	}

	static String getAgrementIdFromOracle(String wi, Statement stmt) {

		try {
			String sql = "select app_id_c from FININT.application_details where new_gen_appid ='" + wi.substring(12, 20)
					+ "'";
			logger.info("insert query for oracle LMS tables: \n" + sql);
			System.out.println(sql);
			ResultSet returnflag = stmt.executeQuery(sql);
			logger.info("returnflag..." + returnflag);
			String agreementId = "";
			while (returnflag.next()) {
				logger.info("returnflag" + returnflag.getString("app_id_c"));
				agreementId = returnflag.getString("app_id_c");
			}

			logger.debug("agreementId:" + agreementId);
			return agreementId;
		} catch (Exception e) {
			
			logger.debug("Error occuried in foreach loop: " + e.getMessage());
			return "fail";
		}

	}

	private synchronized  static List<String> loadWorkItems(String queueID) throws NumberFormatException, IOException, Exception {

		int mainCode = 0;
		List<String> workItemList = new ArrayList<>();
		try {
			String workItemListInputXML = "";
			String workItemListOutputXML = "";
			//String queueID = configPropertyMap.get("queueID");
			sessionCheckInt = 0;
			sessionID = CommonConnection.getSessionID(logger, false);
			while (sessionCheckInt < loopCount) {
				workItemListInputXML = CommonMethods.fetchWorkItemsInput(CommonConnection.getCabinetName(), sessionID,
						queueID);
				logger.debug("InputXML for fetchWorkList Call: " + workItemListInputXML);

				try {
					String fetchWorkitemListOutputXML = CommonMethods.WFNGExecute(workItemListInputXML,
							CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);
					logger.debug("WMFetchWorkList OutputXML: " + fetchWorkitemListOutputXML);

					XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

					String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
					logger.debug("FetchWorkItemListMainCode: " + fetchWorkItemListMainCode);

					int fetchWorkitemListCount = Integer
							.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
					logger.debug("RetrievedCount for WMFetchWorkList Call: " + fetchWorkitemListCount);

					if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0) {
						// lmsFlag = "Y";
						for (int i = 0; i < fetchWorkitemListCount; i++) {
							String fetchWorkItemlistData = xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
							fetchWorkItemlistData = fetchWorkItemlistData.replaceAll("[ ]+>", ">").replaceAll("<[ ]+",
									"<");

							logger.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: " + fetchWorkItemlistData);
							XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

							String processInstanceID = xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
							logger.debug("Current ProcessInstanceID: " + processInstanceID);

							logger.debug("Processing Workitem: " + processInstanceID);
							System.out.println("\nProcessing Workitem: " + processInstanceID);

							WorkItemID = xmlParserfetchWorkItemData.getValueOf("WorkItemId");
							logger.debug("Current WorkItemID: " + WorkItemID);

							entryDateTime = xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
							logger.debug("Current EntryDateTime: " + entryDateTime);

							ActivityName = xmlParserfetchWorkItemData.getValueOf("ActivityName");
							logger.debug("ActivityName: " + ActivityName);

							ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
							logger.debug("ActivityID: " + ActivityID);
							ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
							logger.debug("ActivityType: " + ActivityType);
							ProcessDefId = xmlParserfetchWorkItemData.getValueOf("RouteId");
							logger.debug("ProcessDefId: " + ProcessDefId);

							workItemList.add(processInstanceID);
						}
					}

				} catch (Exception e) {
					logger.info("Exception in Execute : " + e);
					sessionCheckInt++;
					waiteloopExecute(waitLoop);
					sessionID = CommonConnection.getSessionID(logger, false);
					continue;
				}
				logger.info("workItemListOutputXML aa:" + workItemListOutputXML);
				sessionCheckInt++;
				if (CommonMethods.getTagValues(workItemListOutputXML, "MainCode").equalsIgnoreCase("11")) {
					sessionID = CommonConnection.getSessionID(logger, false);
				} else {
					sessionCheckInt++;
					break;
				}
			}
		} catch (Exception ex) {
			logger.error("Error = " + ex);
		}

		return workItemList;

	}

	public static void waiteloopExecute(long wtime) {
		try {
			for (int i = 0; i < 10; i++) {
				Thread.yield();
				Thread.sleep(wtime / 10);
			}
		} catch (InterruptedException e) {
			logger.error(e.toString());
		}
	}

	private static String decryptPassword(String pass) {
		// logger.debug("Inside decryptPassword");
		try {
			int len = pass.length();
			byte[] data = new byte[len / 2];
			for (int i = 0; i < len; i += 2) {
				data[i / 2] = (byte) ((Character.digit(pass.charAt(i), 16) << 4)
						+ Character.digit(pass.charAt(i + 1), 16));
			}
			String password = OSASecurity.decode(data, "UTF-8");
			return password;
		} catch (Exception e) {
			logger.debug("Error decryptPassword" + e.getMessage());
		}
		return "";
	}

	private synchronized static void doneWI(String processInstanceID, String decisionValue, String ErrDesc, String attributesTag,
			String sessionId, String activityId) {
		try {
			// Lock Workitem.
			String getWorkItemInputXML = CommonMethods.getWorkItemInput(CommonConnection.getCabinetName(), sessionId,
					processInstanceID, WorkItemID);
			logger.debug("Output XML For getWorkItemInputXML: " + getWorkItemInputXML);
			String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, CommonConnection.getJTSIP(),
					CommonConnection.getJTSPort(), 1);
			logger.debug("Output XML For WmgetWorkItemCall: " + getWorkItemOutputXml);

			XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
			String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");
			logger.debug("WmgetWorkItemCall Maincode:  " + getWorkItemMainCode);

			if (getWorkItemMainCode.trim().equals("0")) {
				logger.debug("WMgetWorkItemCall Successful: " + getWorkItemMainCode);

				String assignWorkitemAttributeInputXML = "<?xml version=\"1.0\"?><WMAssignWorkItemAttributes_Input>"
						+ "<Option>WMAssignWorkItemAttributes</Option>" + "<EngineName>"
						+ CommonConnection.getCabinetName() + "</EngineName>" + "<SessionId>" + sessionId
						+ "</SessionId>" + "<ProcessInstanceId>" + processInstanceID + "</ProcessInstanceId>"
						+ "<WorkItemId>" + WorkItemID + "</WorkItemId>" + "<ActivityId>" + activityId + "</ActivityId>"
						+ "<ProcessDefId>" + ProcessDefId + "</ProcessDefId>" + "<LastModifiedTime></LastModifiedTime>"
						+ "<ActivityType>" + ActivityType + "</ActivityType>" + "<complete>D</complete>"
						+ "<AuditStatus></AuditStatus>" + "<Comments></Comments>" + "<UserDefVarFlag>Y</UserDefVarFlag>"
						+ "<Attributes>" + attributesTag + "</Attributes>" + "</WMAssignWorkItemAttributes_Input>";

				logger.debug("InputXML for assignWorkitemAttribute Call: " + assignWorkitemAttributeInputXML);

				String assignWorkitemAttributeOutputXML = CommonMethods.WFNGExecute(assignWorkitemAttributeInputXML,
						CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);

				logger.debug("OutputXML for assignWorkitemAttribute Call: " + assignWorkitemAttributeOutputXML);

				XMLParser xmlParserWorkitemAttribute = new XMLParser(assignWorkitemAttributeOutputXML);
				String assignWorkitemAttributeMainCode = xmlParserWorkitemAttribute.getValueOf("MainCode");
				logger.debug("AssignWorkitemAttribute MainCode: " + assignWorkitemAttributeMainCode);

				if (assignWorkitemAttributeMainCode.trim().equalsIgnoreCase("0")) {
					logger.debug("AssignWorkitemAttribute Successful: " + assignWorkitemAttributeMainCode);
					if ("0".trim().equalsIgnoreCase("0")) {
						System.out.println(processInstanceID + "Complete Succesfully with status " + decisionValue);

						logger.debug("WorkItem moved to next Workstep.");

						SimpleDateFormat inputDateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
						SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");

						Date entryDatetimeFormat = inputDateformat.parse(entryDateTime);
						String formattedEntryDatetime = outputDateFormat.format(entryDatetimeFormat);
						logger.debug("FormattedEntryDatetime: " + formattedEntryDatetime);

						Date actionDateTime = new Date();
						String formattedActionDateTime = outputDateFormat.format(actionDateTime);
						logger.debug("FormattedActionDateTime: " + formattedActionDateTime);

						// Insert in WIHistory Table.
						String columnNames = "WI_NAME,Decision_Date_Time,WORKSTEP,USERNAME,DECISION,ENTRY_DATE_TIME,REMARKS";
						String columnValues = "'" + processInstanceID + "','" + formattedActionDateTime + "','"
								+ ActivityName + "','" + CommonConnection.getUsername() + "','" + decisionValue + "','"
								+ formattedEntryDatetime + "','" + ErrDesc + "'";

						String apInsertInputXML = CommonMethods.apInsert(CommonConnection.getCabinetName(), sessionId,
								columnNames, columnValues, "NG_DPL_GR_DECISION_HISTORY");
						logger.debug("APInsertInputXML: " + apInsertInputXML);

						String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML,
								CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);
						logger.debug("APInsertOutputXML: " + apInsertInputXML);

						XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
						String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
						logger.debug("Status of apInsertMaincode  " + apInsertMaincode);

						logger.debug("Completed On " + ActivityName);

						if (apInsertMaincode.equalsIgnoreCase("0")) {
							logger.debug("ApInsert successful: " + apInsertMaincode);
							logger.debug("Inserted in WiHistory table successfully.");
						} else {
							logger.debug("ApInsert failed: " + apInsertMaincode);
						}
					} else {
						// completeWorkitemMaincode="";
						// logger.debug("WMCompleteWorkItem failed:
						// "+completeWorkitemMaincode);
					}
				} else if ("11".equalsIgnoreCase(assignWorkitemAttributeMainCode)) {

					sessionID = CommonConnection.getSessionID(logger, false);
					doneWI(processInstanceID, decisionValue, ErrDesc, attributesTag, sessionID,activityId);
				} else {
					assignWorkitemAttributeMainCode = "";
					logger.debug("AssignWorkitemAttribute failed: " + assignWorkitemAttributeMainCode);
				}
			} else {
				getWorkItemMainCode = "";
				logger.debug("WmgetWorkItem failed: " + getWorkItemMainCode);
			}
		} catch (Exception e) {
			logger.debug("DoneWI Exception: " + e.toString());
		}
	}

}
