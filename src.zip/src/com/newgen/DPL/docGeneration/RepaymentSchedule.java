package com.newgen.DPL.docGeneration;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.newgen.DCC.DECTECHIntegration.MapXML;
import com.newgen.DCC.Update_AssignCIF.DCC_UpdateAssignCIFLog;
import com.newgen.DPL.Digital_PL_CommomMethod;
import com.newgen.DPL.Digital_PL_Log;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.poi.ss.formula.functions.Replace;
import org.w3c.dom.NodeList;

public class RepaymentSchedule extends Digital_PL_CommomMethod {

	public static String processInstanceID = null;
	static Map<String, String> ConfigParamMap = new HashMap<String, String>();
	static NGEjbClient ngEjbClient;
	private static org.apache.log4j.Logger logger;

	private static String jtsIP;
	private static String jtsPort;
	private static String ActivityType;
	private static String ProcessDefId;
	private static String ActivityName;
	private static String ActivityID;
	private static String cabinetName;
	public static String prodType;

	private String sessionID = "";
	private String queueID = "";

	public RepaymentSchedule() throws NGException {
		Digital_PL_Log.setLogger(getClass().getSimpleName());
		this.ngEjbClient = NGEjbClient.getSharedInstance();
		logger = Digital_PL_Log.getLogger(getClass().getSimpleName());
	}

	public String onDoneGenPDF() throws Exception {

		logger.debug("Inside OnDoneGenPDF");
		final String Queuename = "Digital_PL_Doc_Generation";
		ActivityName = "Doc_Generation";
		// Validate Session ID

		int configReadStatus = readConfig();

		logger.debug("configReadStatus " + configReadStatus);
		if (configReadStatus != 0) {
			logger.error("Could not Read Config Properties PL Repayment");
		}

		String headerImagePath = "";
		if ("Conventional".equalsIgnoreCase(prodType)) {
			headerImagePath = ConfigParamMap.get("Digital_PL_ConventionalHeader");
		} else {
			headerImagePath = ConfigParamMap.get("Digital_PL_IslamicHeader");
		}

		logger.debug("prodType: " + prodType + "Loaded with Header: " + headerImagePath);
		sessionID = CommonConnection.getSessionID(logger, false);
		cabinetName = CommonConnection.getCabinetName();
		jtsIP = CommonConnection.getJTSIP();
		jtsPort = CommonConnection.getJTSPort();

		if (sessionID == null || sessionID.equalsIgnoreCase("") || sessionID.equalsIgnoreCase("null")) {
			logger.error("Could Not Get Session ID " + sessionID);
		}

		Document document = new Document(PageSize.A4.rotate());
		document.setMargins(15, 15, 147, 65);

		try {
			logger.debug("RepaymentPDF : ");
			String pdfName = processInstanceID + "_RepaymentSchedule";

			String TemplatePath = ConfigParamMap.get("RepaymentPath") + pdfName + ".pdf";
			// String headerImagePath =
			// ConfigParamMap.get("Digital_PL_HeaderImage");
			String footerLeft = ConfigParamMap.get("Digital_PL_FooterImageLeft");
			String footerRight = ConfigParamMap.get("Digital_PL_FooterImageRight");
			logger.debug("Paths: " + TemplatePath + "\n" + headerImagePath + "\n" + footerLeft + "\n" + footerRight);
			//
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(TemplatePath));
			logger.debug("After pdfWriter declaration");
			int prevPage = 0;
			writer.setPageEvent(new PdfPageEventHelper() {

				@Override
				public void onEndPage(PdfWriter writer, Document document) {
					try {
						String headerImagePath = "";
						if ("Conventional".equalsIgnoreCase(prodType)) {
							headerImagePath = ConfigParamMap.get("Digital_PL_ConventionalHeader");
						} else {
							headerImagePath = ConfigParamMap.get("Digital_PL_IslamicHeader");
						}
						int currentPage = writer.getCurrentPageNumber();
						if (currentPage == 1) {
							// Header Image
							Image headerLeftImage = Image.getInstance(headerImagePath);
							headerLeftImage.scaleToFit(150, 50);

							headerLeftImage.scalePercent(65, 65);
							if ("Conventional".equalsIgnoreCase(prodType)) {
								headerLeftImage.setAbsolutePosition(document.getPageSize().getLeft() + 20,
										document.getPageSize().getTop() - 120);// 135
							} else {
								headerLeftImage.setAbsolutePosition(document.getPageSize().getLeft() + 20,
										document.getPageSize().getTop() - 135);// 135
							}
							writer.getDirectContent().addImage(headerLeftImage);

							// Footer Image
							Image footerCenterImage1 = Image.getInstance(footerLeft);
							Image footerCenterImage2 = Image.getInstance(footerRight);
							footerCenterImage1.scalePercent(40, 40);
							footerCenterImage2.scalePercent(40, 40);

							float totalWidth = footerCenterImage1.getScaledWidth() + footerCenterImage2.getScaledWidth()
									+ 20;
							float startX = (document.getPageSize().getWidth() - totalWidth) / 2;

							footerCenterImage1.setAbsolutePosition(startX, 15);
							footerCenterImage2.setAbsolutePosition(startX + footerCenterImage1.getScaledWidth() + 20,
									15);

							writer.getDirectContent().addImage(footerCenterImage1);
							writer.getDirectContent().addImage(footerCenterImage2);

							PdfContentByte cb = writer.getDirectContent();
							Font pageFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
							Phrase pageNo = new Phrase("Page " + writer.getPageNumber(), pageFont);
							ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, pageNo, document.left(),
									document.bottom() - 15, 0);

						}
						// Add table header from page 2 onwards
						if (currentPage > (1)) {

							Image headerLeftImage1 = Image.getInstance(headerImagePath);

							headerLeftImage1.scaleToFit(150, 50);
							if ("Conventional".equalsIgnoreCase(prodType)) {
								headerLeftImage1.scalePercent(65, 60);// 60,55
								headerLeftImage1.setAbsolutePosition(document.getPageSize().getLeft() + 20,
										document.getPageSize().getTop() - 88);// 110
							} else {
								headerLeftImage1.scalePercent(60, 55);// 60,55
								headerLeftImage1.setAbsolutePosition(document.getPageSize().getLeft() + 20,
										document.getPageSize().getTop() - 110);// 110
							}
							writer.getDirectContent().addImage(headerLeftImage1);

							PdfPTable table = new PdfPTable(14);
							table.setTotalWidth(
									document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
							table.setLockedWidth(true);

							// Set relative widths for columns
							float[] columnWidths;
							if ("Conventional".equalsIgnoreCase(prodType)) {
								columnWidths = new float[] { 8, 8, 10, 9, 8, 8, 8, 8, 8, 10, 7, 6, 10, 10 };
							} else {
								columnWidths = new float[] { 10, 10, 10, 10, 10, 9, 11, 10, 10, 11, 9, 9, 11, 10 };
							}

							table.setWidths(columnWidths);
							String[] headers;
							if ("Conventional".equalsIgnoreCase(prodType)) {
								headers = new String[] { "Instl. Num", "Due Date", "Opening Principal", "Instl. Amount",
										"Principal", "Interest", "LI Amount", "PI Amount", "EMI", "CL.Principal",
										"Rate", "Days", "Deferral Flag", "Moratorium Interest" };
							} else {
								headers = new String[] { "SI No,", "Due Date", "Opening Principal",
										"Monthly Commitment", "Principal Amount", "Profit Amount", "Fee",
										"Deferred Profit", "Moratorium Profit", "Closing Principal", "Profit Rate",
										"Total Payable", "Received Amount", "Life Takaful Amount(TI)" };
							}

							String line1 = "_";
							int linelength1 = 120;
							while (linelength1 > 0) {
								line1 += "_";
								linelength1--;
							}
							PdfPCell lineCell1 = new PdfPCell(new Phrase(line1));
							lineCell1.setColspan(headers.length);
							lineCell1.setBorder(PdfPCell.NO_BORDER);
							lineCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
							lineCell1.setPaddingTop(-8);
							lineCell1.setPaddingBottom(2);
							table.addCell(lineCell1);

							Font headerFont;
							if ("Conventional".equalsIgnoreCase(prodType)) {
								headerFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
							} else {
								headerFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
							}
							for (String header : headers) {
								PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
								cell.setHorizontalAlignment(Element.ALIGN_CENTER);
								cell.setBorder(Rectangle.NO_BORDER);
								cell.setPadding(3f);
								table.addCell(cell);
							}

							// Add line below headers
							PdfPCell lineCell = new PdfPCell(new Phrase(line1));
							lineCell.setColspan(headers.length);
							lineCell.setBorder(PdfPCell.NO_BORDER);
							lineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
							lineCell.setPaddingTop(-9);
							if ("Conventional".equalsIgnoreCase(prodType)) {
								lineCell.setPaddingBottom(10);// 12
							} else {
								lineCell.setPaddingBottom(12);
							}
							table.addCell(lineCell);

							// Position the table just below the header image
							PdfContentByte cb = writer.getDirectContent();
							float yPosition = document.getPageSize().getTop() - 110; // Adjusted
																						// position
							table.writeSelectedRows(0, -1, document.leftMargin(), yPosition, cb);

							// Footer Image
							Image footerCenterImage1 = Image.getInstance(footerLeft);
							Image footerCenterImage2 = Image.getInstance(footerRight);
							footerCenterImage1.scalePercent(40, 40);
							footerCenterImage2.scalePercent(40, 40);

							float totalWidth = footerCenterImage1.getScaledWidth() + footerCenterImage2.getScaledWidth()
									+ 20;
							float startX = (document.getPageSize().getWidth() - totalWidth) / 2;

							footerCenterImage1.setAbsolutePosition(startX, 15);
							footerCenterImage2.setAbsolutePosition(startX + footerCenterImage1.getScaledWidth() + 20,
									15);

							writer.getDirectContent().addImage(footerCenterImage1);
							writer.getDirectContent().addImage(footerCenterImage2);

							PdfContentByte cb1 = writer.getDirectContent();
							Font pageFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
							Phrase pageNo = new Phrase("Page " + writer.getPageNumber(), pageFont);
							ColumnText.showTextAligned(cb1, Element.ALIGN_LEFT, pageNo, document.left(),
									document.bottom() - 15, 0);
							logger.debug("RepaymentPDF Header first page fin");
						}

					} catch (Exception e) {
						String exception = customException(e);
						logger.debug("Exception while adding the document: " + exception);
					}
				}
			});

			document.open();

			// Title Table starts
			PdfPTable titleSection = new PdfPTable(2);
			titleSection.setWidthPercentage(100);
			titleSection.setWidths(new float[] { 60, 40 });

			Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11);
			PdfPCell titleCell = new PdfPCell(new Paragraph("Repayment Schedule", titleFont));
			titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			titleCell.setBorder(Rectangle.NO_BORDER);
			titleCell.setPaddingBottom(0);
			titleSection.addCell(titleCell);

			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String currentDate = dateFormat.format(new Date());
			Font dateFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
			PdfPCell dateCell = new PdfPCell(new Paragraph("Date: " + currentDate, dateFont));
			dateCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			dateCell.setBorder(Rectangle.NO_BORDER);

			titleSection.addCell(dateCell);
			titleSection.setSpacingAfter(-7f);
			titleSection.setSpacingBefore(-5f);
			document.add(titleSection);
			// Title Table ends

			String line = "_";
			int linelength = 80;
			while (linelength > 0) {
				line += "_";
				linelength--;
			}

			String line1 = "_";
			int linelength1 = 120;
			while (linelength1 > 0) {
				line1 += "_";
				linelength1--;
			}

			document.add(new Paragraph(new Phrase(line)));
			logger.debug("Lines added");

			// Customer Data Table
			PdfPTable customerTable = new PdfPTable(4);
			customerTable.setWidthPercentage(60);
			customerTable.setSpacingBefore(3f);

			String customerDataQuery = "select top 1 CustomerName,AgreementID,LoanAmount,RequestedLoanTenor,InterestRate,Output_Interest_Rate,EMI,ProductType,"
					+ "emailid,i.First_Installment_Date from NG_DPL_EXTTABLE e WITH (NOLOCK) join NG_DPL_IncomeExpense i WITH (NOLOCK) "
					+ "on e.WINAME=i.WI_Name WHERE e.WINAME='" + processInstanceID + "'";

			logger.debug("Customer Data Query: " + customerDataQuery);

			String customerDataIPXML = CommonMethods.apSelectWithColumnNames(customerDataQuery,
					CommonConnection.getCabinetName(), CommonConnection.getSessionID(logger, false));
			logger.debug("extTabDataIPXML: " + customerDataIPXML);

			String customerDataOPXML = CommonMethods.WFNGExecute(customerDataIPXML, CommonConnection.getJTSIP(),
					CommonConnection.getJTSPort(), 1);
			logger.debug("extTabDataOPXML: " + customerDataOPXML);

			XMLParser customerDataXMLparser = new XMLParser(customerDataOPXML);

			String CustomerName = customerDataXMLparser.getValueOf("CustomerName");
			String AgreementID = customerDataXMLparser.getValueOf("AgreementID");
			String LoanAmount = customerDataXMLparser.getValueOf("LoanAmount");
			String RequestedLoanTenor = customerDataXMLparser.getValueOf("RequestedLoanTenor");
			String InterestRate = customerDataXMLparser.getValueOf("Output_Interest_Rate");
			String EMIamt = customerDataXMLparser.getValueOf("EMI");
			String ProductType = customerDataXMLparser.getValueOf("ProductType");
			String toMailId = customerDataXMLparser.getValueOf("emailid");
			String First_Installment_Date = customerDataXMLparser.getValueOf("First_Installment_Date");
			String startDate = "";
			String toDate = "";
			try {
				if (First_Installment_Date.contains(" ")) {
					First_Installment_Date = First_Installment_Date.split(" ")[0];
				}
				logger.debug("First_Installment_Date: " + First_Installment_Date);
				int calculatedTenor = Integer.parseInt(RequestedLoanTenor) - 1;
				DateTimeFormatter b = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate date = LocalDate.parse(First_Installment_Date, b);
				LocalDate endDate = date.plusMonths(calculatedTenor);
				DateTimeFormatter a = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				startDate = date.format(a);
				toDate = endDate.format(a);
				logger.debug("Start Date: " + startDate);
				logger.debug("End Date: " + toDate);
			} catch (Exception e) {
				logger.debug("error: " + e.getMessage());
			}
			// Define all the column labels and their corresponding data
			String[][] customerData;
			if ("Conventional".equalsIgnoreCase(prodType)) {
				customerData = new String[][] { { "Customer Name:", CustomerName, "Agreement No.:", AgreementID },
						{ "Loan Amount:", LoanAmount, "Tenure:", RequestedLoanTenor + " months" },
						{ "Interest Rate:", InterestRate + " %", "EMI Amount:", EMIamt },
						{ "Start Date:", startDate, "End Date:", toDate } };
			} else {
				customerData = new String[][] { { "Agreement No.:", AgreementID, "Agreement Date:", currentDate },
						{ "Customer Name:", CustomerName, "Frequency:", "Monthly" },
						{ "Product: ", "Personal Finance", "Effective Rate: ", InterestRate + " %" },
						{ "Finance Amount: ", LoanAmount, "Balance Tenor: ", RequestedLoanTenor },
						{ "Currency: ", "AED", "", "" } };
			}
			logger.debug("Data Fetched" + Arrays.toString(customerData));

			// Add all rows to the table
			for (String[] row : customerData) {
				addCustomerDataCell(customerTable, row[0], row[1], row[2], row[3]);
			}

			customerTable.setHorizontalAlignment(Element.ALIGN_LEFT);
			customerTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			document.add(customerTable);

			// Loan Data Table
			PdfPTable table = new PdfPTable(14);
			table.setWidthPercentage(100);

			document.add(new Paragraph(new Phrase(line)));

			String[] headers;
			if ("Conventional".equalsIgnoreCase(prodType)) {
				headers = new String[] { "Instl. Num", "Due Date", "Opening Principal", "Instl. Amount", "Principal",
						"Interest", "LI Amount", "PI Amount", "EMI", "CL.Principal", "Rate", "Days", "Deferral Flag",
						"Moratorium Interest" };
			} else {
				headers = new String[] { "SI No.", "Due Date", "Opening Principal", "Monthly Commitment",
						"Principal Amount", "Profit Amount", "Fee", "Deferred Profit", "Moratorium Profit",
						"Closing Principal", "Profit Rate", "Total Payable", "Received Amount",
						"Life Takaful Amount(TI)" };
			}
			Font newHeaderFont;
			if ("Conventional".equalsIgnoreCase(prodType)) {
				newHeaderFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
			} else {
				newHeaderFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
			}
			for (String header : headers) {
				addHeaderCell(table, header, newHeaderFont);
			}

			PdfPCell lineCell = new PdfPCell(new Phrase(line1));
			lineCell.setColspan(headers.length);
			lineCell.setBorder(PdfPCell.NO_BORDER);
			lineCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			lineCell.setPaddingTop(-8);
			lineCell.setPaddingBottom(10);
			table.addCell(lineCell);

			String repaymentData = "select a.month,EMI_DATE,Opening_Principle,a.EMI,Principal,Interest,"
					+ "Life_Insurance,Property_Insurance,Closing_Principle,Output_Interest_Rate,Excess_Interest,"
					+ "a.EMI_Days,Moratorium from NG_PL_EMI_Schedule a WITH (NOLOCK) join NG_DPL_EXTTABLE b WITH (NOLOCK) "
					+ "on a.Workitem_Name=b.WINAME where b.WINAME='" + processInstanceID
					+ "' order by TRY_CONVERT(numeric(20,1),a.month)";

			logger.debug("Repayment Data Query: " + repaymentData);
			// List<List<String>> repaymentDtls =
			// iform.getDataFromDB(repaymentData);
			// logger.debug("Repayment Data: " + repaymentDtls);

			//
			String add_xml_str = "";
			// Digital_PL_CommomMethod digital_pl_CommomMethod = new
			// Digital_PL_CommomMethod();
			List<Map<String, String>> OutputXML = Digital_PL_CommomMethod.getDataFromDBForPdf(repaymentData,
					cabinetName, sessionID, jtsIP, jtsPort);
			logger.info("ExternalBureauIndividualProducts list size" + OutputXML.size() + "");

			// String data for total
			double totalEMI = 0.00;
			double totalPrincipal = 0.00;
			double totalInterest = 0.00;

			for (Map<String, String> map : OutputXML) {

				String month = Digital_PL_CommomMethod.validateValue(map.get("month"));
				String EMI_DATE = Digital_PL_CommomMethod.validateValue(map.get("EMI_DATE"));
				String Opening_Principle = Digital_PL_CommomMethod.validateValue(map.get("Opening_Principle"));
				String EMI = Digital_PL_CommomMethod.validateValue(map.get("EMI"));
				String Principal = Digital_PL_CommomMethod.validateValue(map.get("Principal"));
				String Interest = Digital_PL_CommomMethod.validateValue(map.get("Interest"));
				String Life_Insurance = Digital_PL_CommomMethod.validateValue(map.get("Life_Insurance"));
				String Property_Insurance = Digital_PL_CommomMethod.validateValue(map.get("Property_Insurance"));
				String Closing_Principle = Digital_PL_CommomMethod.validateValue(map.get("Closing_Principle"));
				String Output_Interest_Rate = Digital_PL_CommomMethod.validateValue(map.get("Output_Interest_Rate"));
				String EMI_Days = Digital_PL_CommomMethod.validateValue(map.get("EMI_Days"));
				String Moratorium = Digital_PL_CommomMethod.validateValue(map.get("Excess_Interest"));

				if ("Conventional".equalsIgnoreCase(prodType)) {
					addRow(table, month, EMI_DATE, Opening_Principle, EMI, Principal, Interest, Life_Insurance,
							Property_Insurance, EMI, Closing_Principle, Output_Interest_Rate, EMI_Days, "", Moratorium);
				} else {
					addRow(table, month, EMI_DATE, Opening_Principle, EMI, Principal, Interest, Life_Insurance, "",
							Moratorium, Closing_Principle, Output_Interest_Rate, EMI, "", "");
				}

				logger.debug("Row DATA: " + EMI_DATE + "\n" + Opening_Principle + "\n" + EMI + "\n" + Principal + "\n"
						+ Interest + "\n" + Life_Insurance + "\n" + Property_Insurance + "\n" + Closing_Principle + "\n"
						+ Output_Interest_Rate + "\n" + EMI_Days + "\n" + Moratorium);

				totalEMI += Double.parseDouble(EMI);
				totalPrincipal += Double.parseDouble(Principal);
				totalInterest += Double.parseDouble(Interest);
			}

			logger.debug("Total DATA: " + totalEMI + "\n" + totalPrincipal + "\n" + totalInterest);

			// }

			table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			table.setSpacingBefore(7f);
			document.add(table);

			document.add(new Paragraph(new Phrase(line1)));

			PdfPTable endTable = new PdfPTable(14);
			endTable.setWidthPercentage(100);
			endTable.setSpacingBefore(5f);

			if ("Conventional".equalsIgnoreCase(prodType)) {
				addRow(endTable, "", "", "Total:", String.format("%.2f", totalEMI),
						String.format("%.2f", totalPrincipal), String.format("%.2f", totalInterest), "", "",
						String.format("%.2f", totalEMI), "", "", "", "", "");
			} else {
				addRow(endTable, "", "", "Total:", String.format("%.2f", totalEMI),
						String.format("%.2f", totalPrincipal), String.format("%.2f", totalInterest), "", "", "", "", "",
						String.format("%.2f", totalEMI), "", "");

			}

			endTable.setSpacingAfter(-12f);
			document.add(endTable);
			document.add(new Paragraph(new Phrase(line1)));

			document.close();
			logger.debug("PDF created successfully.");

			// Getting document index and sending via mail
			String addDocResult = AttachDocumentWithWI(processInstanceID, pdfName);
			logger.debug("addDocResult : " + addDocResult);
			String docIndex = "";
			if (addDocResult.contains("~")) {
				String dataArray[] = addDocResult.split("~");
				docIndex = dataArray[1];
			}
			if (addDocResult.contains("Success")) {
				String docDetails = getisINDEXFromDB(processInstanceID, "RepaymentSchedule", docIndex);
				logger.debug("docDetails : " + docDetails);
				String isINDEX = "", attachmentNames = "", volID = "", wfattachmentNames = "", wfattachmentIndex = "", wlImageIndex="", wlAttachment="", wlVolID="",
						wetSignatureImageIndex ="",wetSignatureAttachment ="",wetSignatureVolID="";//vinayak changes for wet signature
				if (docDetails != null && !docDetails.isEmpty() && !"~.~".equalsIgnoreCase(docDetails)) {
					String[] docArray = docDetails.split("~");
					isINDEX = docArray[0];
					attachmentNames = docArray[1];
					volID = docArray[2];
					wlImageIndex = docArray[3];
					wlAttachment = docArray[4];
					wlVolID = docArray[5];
					wetSignatureImageIndex = docArray[6];//vinayak changes for wet signature
					wetSignatureAttachment = docArray[7];
					wetSignatureVolID = docArray[8];
				}

				if (!"".equalsIgnoreCase(isINDEX)) {
					wfattachmentNames = attachmentNames +";"+ wlAttachment+";"+wetSignatureAttachment+";";
					wfattachmentIndex = isINDEX + "#" + volID + "#;"+ wlImageIndex + "#" + wlVolID + "#;"+wetSignatureImageIndex + "#" + wetSignatureVolID + "#;";
				}
				logger.debug("Final wfattachmentNames is: " + wfattachmentNames);
				logger.debug("Final wfattachmentIndex is: " + wfattachmentIndex);

				String mailSubject = "";
				String mailMessage = "";

				String templateQuery = "select MailTemplate,MailSubject,FromMail from NG_DPL_MASTER_EMAIL_TRIGGER where "
						+ "ProcessName = 'Digital_PL' and WorkstepName='" + ActivityName + "' and " + "ProductType='"
						+ ProductType + "' and MailEvent = 'RepaymentSchedule'";
				logger.debug("template Query: " + templateQuery);

				String templateIPXML = CommonMethods.apSelectWithColumnNames(templateQuery,
						CommonConnection.getCabinetName(), CommonConnection.getSessionID(logger, false));
				logger.debug("extTabDataIPXML: " + templateIPXML);

				String templateOPXML = CommonMethods.WFNGExecute(templateIPXML, CommonConnection.getJTSIP(),
						CommonConnection.getJTSPort(), 1);
				logger.debug("extTabDataOPXML: " + templateOPXML);

				XMLParser templateXMLparser = new XMLParser(templateOPXML);

				mailSubject = templateXMLparser.getValueOf("MailSubject");
				mailMessage = templateXMLparser.getValueOf("MailTemplate");

				mailSubject = mailSubject.replace("XXXXXXX", AgreementID);
				logger.debug("mailSubject with replace xx : " + mailSubject);

				String ConventioanallogoPath, IslamicLogoPath, QR, insta, X, fb;
				ConventioanallogoPath = ConfigParamMap.get("ConventionalLogobase64");
				IslamicLogoPath = ConfigParamMap.get("IslamicLogobase64");
				QR = ConfigParamMap.get("QRbase64");
				insta = ConfigParamMap.get("Instabase64");
				X = ConfigParamMap.get("Xbase64");
				fb = ConfigParamMap.get("FBbase64");

				logger.debug("image Paths: " + ConventioanallogoPath + "\n" + IslamicLogoPath + "\n" + QR + "\n" + insta
						+ "\n" + X + "\n" + fb);

				if ("Conventional".equals(ProductType)) {
					mailMessage = mailMessage.replaceAll(Pattern.quote("#Bank_Logo#"), ConventioanallogoPath);
					logger.debug("Inside ProductType check: " + ProductType);
				} else {
					mailMessage = mailMessage.replaceAll(Pattern.quote("#Bank_Logo#"), IslamicLogoPath);
				}

				mailMessage = mailMessage.replaceAll(Pattern.quote("#CUSTOMER_NAME#"), CustomerName);
				mailMessage = mailMessage.replace("#QR_img#", QR);
				mailMessage = mailMessage.replace("#Insta_img#", insta);
				mailMessage = mailMessage.replace("#X_img#", X);
				mailMessage = mailMessage.replace("#FB_img#", fb);

				String processDefID = "52";
				String fromMail = ConfigParamMap.get("fromMail");// "test5@rakbanktst.ae";
				String toMail = toMailId;// "test11@rakbanktst.ae";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
				String insertedDateTime = simpleDateFormat.format(new Date());
				// Inserting into table
				String colNames = "MAILFROM,MAILTO,MAILSUBJECT,MAILMESSAGE,MAILCONTENTTYPE,MAILPRIORITY,MAILSTATUS,INSERTEDBY,MAILACTIONTYPE,"
						+ "INSERTEDTIME,PROCESSDEFID,PROCESSINSTANCEID,WORKITEMID,ACTIVITYID,NOOFTRIALS,attachmentNames,attachmentISINDEX";

				String colValues = "'" + fromMail + "','" + toMail + "',N'" + mailSubject + "',N'" + mailMessage + "',"
						+ "'text/html;charset=UTF-8','1','N','CUSTOM','TRIGGER','" + insertedDateTime + "','"
						+ processDefID + "','" + processInstanceID + "'," + "'1','1','0','" + wfattachmentNames + "','"
						+ wfattachmentIndex + "'";

				logger.debug("Column Values for WFMAIL " + colValues);

				String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, colNames, colValues,
						"WFMAILQUEUETABLE");
				logger.debug("APInsertInputXML mail " + apInsertInputXML);

				String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
				logger.debug("APInsertOutputXML mail " + apInsertOutputXML);

				XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
				String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
				logger.debug("Status of apInsertMaincode  ng_digital_awb_status DCC " + apInsertMaincode);

				logger.debug("****************Insert Into DB Successfully*******************");

				return "Success";
			}

			else if (addDocResult.contains("Error")) {
				logger.debug("Error in AttachDocumentWithWI");
			}
			//
		} catch (Exception e) {
			String exception = customException(e);
			logger.debug("Exception while adding the document: " + exception);
		}

		return "";
	}

	private static void addHeaderCell(PdfPTable table, String headerText, Font headerFont) {
		PdfPCell headerCell = new PdfPCell(new Paragraph(headerText, headerFont));
		headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		headerCell.setBorder(Rectangle.NO_BORDER);
		table.addCell(headerCell);
	}

	// Modified method to handle column-data pairs
	private static void addCustomerDataCell(PdfPTable table, String label1, String value1, String label2,
			String value2) {
		Font customerFont = FontFactory.getFont(FontFactory.HELVETICA, 9);

		// First
		PdfPCell labelCell1 = new PdfPCell(new Paragraph(label1, customerFont));
		labelCell1.setBorder(Rectangle.NO_BORDER);
		labelCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
		table.addCell(labelCell1);

		PdfPCell valueCell1 = new PdfPCell(new Paragraph(value1, customerFont));
		valueCell1.setBorder(Rectangle.NO_BORDER);
		valueCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(valueCell1);
		//

		// Second
		PdfPCell labelCell2 = new PdfPCell(new Paragraph(label2, customerFont));
		labelCell2.setBorder(Rectangle.NO_BORDER);
		labelCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
		table.addCell(labelCell2);

		PdfPCell valueCell2 = new PdfPCell(new Paragraph(value2, customerFont));
		valueCell2.setBorder(Rectangle.NO_BORDER);
		valueCell2.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(valueCell2);
		//
	}

	private static void addRow(PdfPTable table, String... rowData) {
		Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
		for (String data : rowData) {
			PdfPCell cell = new PdfPCell(new Paragraph(data, cellFont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(cell);
		}
	}

	public String getisINDEXFromDB(String wi_name, String docToFetched, String docIndex) {
		logger.debug("********************Inside getisINDEXFromDB*******************");
		try {
			String FetchDocIndexQuery = "SELECT AppName,ImageIndex,Name,volumeId FROM PDBDocument WITH (NOLOCK) WHERE DocumentIndex='"
					+ docIndex + "'";
			logger.debug("query for DocIndex is : " + FetchDocIndexQuery);

			String customerDataIPXML = CommonMethods.apSelectWithColumnNames(FetchDocIndexQuery,
					CommonConnection.getCabinetName(), CommonConnection.getSessionID(logger, false));
			logger.debug("extTabDataIPXML: " + customerDataIPXML);

			String customerDataOPXML = CommonMethods.WFNGExecute(customerDataIPXML, CommonConnection.getJTSIP(),
					CommonConnection.getJTSPort(), 1);
			logger.debug("extTabDataOPXML: " + customerDataOPXML);

			XMLParser customerDataXMLparser = new XMLParser(customerDataOPXML);

			String appName = customerDataXMLparser.getValueOf("AppName");
			String imageIndex = customerDataXMLparser.getValueOf("ImageIndex");
			String docName = customerDataXMLparser.getValueOf("Name");
			String volID = customerDataXMLparser.getValueOf("volumeId");

			String welcomeLetterQuery = "select top 1 appname,imageindex,name,volumeid from pdbdocument where documentindex in "
					+ "(select documentindex from pdbdocumentcontent where parentfolderindex in (select folderindex from pdbfolder where "
					+ "name='" + processInstanceID
					+ "')) and name like '%DPL_Welcome_Letter%' order by documentindex desc";

			logger.debug("query for welcomeLetter is : " + welcomeLetterQuery);

			String wlIPXML = CommonMethods.apSelectWithColumnNames(welcomeLetterQuery,
					CommonConnection.getCabinetName(), CommonConnection.getSessionID(logger, false));
			logger.debug("welcome Letter INXML: " + wlIPXML);

			String wlOPXML = CommonMethods.WFNGExecute(wlIPXML, CommonConnection.getJTSIP(),
					CommonConnection.getJTSPort(), 1);
			logger.debug("welcome Letter OPXML: " + wlOPXML);

			XMLParser wlXMLparser = new XMLParser(wlOPXML);

			String wlappName = wlXMLparser.getValueOf("AppName");
			String wlimageIndex = wlXMLparser.getValueOf("ImageIndex");
			String wldocName = wlXMLparser.getValueOf("Name");
			String wlvolID = wlXMLparser.getValueOf("volumeId");

			logger.debug("DocIndex is : " + docIndex);

			String isIndex = imageIndex;
			String attachmentNames = docName + "." + appName;
			logger.debug("isIndex : " + isIndex);
			logger.debug("attachmentNames : " + attachmentNames);
			logger.debug("volID : " + volID);

			String wlAttachment = wldocName + "." + wlappName;
			logger.debug("WL Image Index : " + wlimageIndex);
			logger.debug("WL doc nam final : " + attachmentNames);
			logger.debug("WLvolID : " + wlvolID);
			
			
			//vinayak chnages 
			String wetSignatureQuery = "select top 1 appname,imageindex,name,volumeid from pdbdocument where documentindex in "
					+ "(select documentindex from pdbdocumentcontent where parentfolderindex in (select folderindex from pdbfolder where "
					+ "name='"+processInstanceID+"')) and name like '%Wet_signature_form%' order by documentindex desc";
			logger.debug("query for wetSignature is : " + wetSignatureQuery);
			
			String wetSignatureIPXML = CommonMethods.apSelectWithColumnNames(wetSignatureQuery,
					CommonConnection.getCabinetName(), CommonConnection.getSessionID(logger, false));
			logger.debug("wetSignatureIPXML INXML: " + wetSignatureIPXML);
			
			String wetSignatureOPXML = CommonMethods.WFNGExecute(wetSignatureIPXML, CommonConnection.getJTSIP(),
					CommonConnection.getJTSPort(), 1);
			
			logger.debug("wetSignatureOPXML: " + wetSignatureOPXML);
			
			XMLParser wetSignatureXMLparser = new XMLParser(wetSignatureOPXML);
			
			String wetSignatureappName = wetSignatureXMLparser.getValueOf("AppName");
			String wetSignatureimageIndex = wetSignatureXMLparser.getValueOf("ImageIndex");
			String wetSignaturedocName = wetSignatureXMLparser.getValueOf("Name");
			String wetSignaturevolID = wetSignatureXMLparser.getValueOf("volumeId");
			
			String wetSignatureAttachment = wetSignaturedocName + "." + wetSignatureappName;
			logger.debug("wetSignatureimageIndex : " + wetSignatureimageIndex);
			logger.debug("WL doc nam final : " + wetSignatureAttachment);
			logger.debug("wetSignaturevolID : " + wetSignaturevolID);
			
			
			String result = isIndex + "~" + attachmentNames + "~" + volID;
			String wlResult = wlimageIndex + "~" + wlAttachment + "~" + wlvolID;
			String wetSignatureResult = wetSignatureimageIndex + "~" + wetSignatureAttachment + "~" + wetSignaturevolID;
			logger.debug("result in getisINDEXFromDB is :" + result);
			return result+"~"+wlResult+"~"+wetSignatureResult;

		} catch (Exception e) {
			String exception = customException(e);
			logger.debug("Exception in getisINDEXFromDB " + exception);
		}
		return "";
	}

	private int readConfig() {
		Properties p = null;
		try {

			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir") + File.separator + "ConfigFiles"
					+ File.separator + "DPL_RepaymentSchedule.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements()) {
				String name = (String) names.nextElement();
				ConfigParamMap.put(name, p.getProperty(name));
			}
		} catch (Exception e) {
			return -1;
		}
		return 0;
	}

	public String customException(Exception e) {
		StringWriter sw = new StringWriter();
		e.printStackTrace();
		String exception = sw.toString();
		try {
			sw.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return exception;
	}

	public String AttachDocumentWithWI(String pid, String pdfName) {

		String docxml = "";
		String documentindex = "";
		String doctype = "";

		try {
			logger.debug("inside ODAddDocument");
			logger.debug("Proess Instance Id: " + pid);
			logger.debug("Integration call pdfName: " + pdfName);

			int jts_port = Integer.parseInt(jtsPort);

			String path = System.getProperty("user.dir");// for path
			logger.debug(" \nAbsolute Path :" + path);
			String pdfTemplatePath = "";
			String generatedPdfPath = ConfigParamMap.get("RepaymentPath");
			String dynamicPdfName = pdfName + ".pdf";

			logger.debug("\nGeneratedPdfPathCheck :" + generatedPdfPath);
			generatedPdfPath = generatedPdfPath + dynamicPdfName;

			logger.debug("\nGeneratedPdfPath :" + generatedPdfPath);

			docxml = SearchExistingDoc(pid, "DPL_Repayment_Schedule", generatedPdfPath);
			logger.debug("Final Document Output: " + docxml);
			documentindex = getTagValues(docxml, "DocumentIndex");

			doctype = "new";
			logger.debug(docxml + "~" + documentindex + "~" + dynamicPdfName);
			//

			//
			if (!documentindex.isEmpty()) {
				return "Success~" + documentindex;
			} else {
				return "Error";
			}

		} catch (Exception e) {
			String exception = customException(e);
			logger.debug("Exception while adding the document: " + exception);
			return "Exception while adding the document: " + e;
		}

	}

	public String SearchExistingDoc(String pid, String FrmType, String sFilepath) {
		try {
			String strFolderIndex = "";
			String strImageIndex = "";
			String strInputQry1 = "select FolderIndex from PDBFolder where name='" + processInstanceID + "'";
			logger.debug("strInputQry1: " + strInputQry1);

			String folderIndexIPXML = CommonMethods.apSelectWithColumnNames(strInputQry1,
					CommonConnection.getCabinetName(), CommonConnection.getSessionID(logger, false));
			logger.debug("folderIndexIPXML: " + folderIndexIPXML);

			String folderIndexOPXML = CommonMethods.WFNGExecute(folderIndexIPXML, CommonConnection.getJTSIP(),
					CommonConnection.getJTSPort(), 1);
			logger.debug("folderIndexOPXML: " + folderIndexOPXML);

			XMLParser folderIndexXMLparser = new XMLParser(folderIndexOPXML);
			strFolderIndex = folderIndexXMLparser.getValueOf("FolderIndex");

			logger.debug("FolderIndex for WI:" + processInstanceID + " " + strFolderIndex);
			// strFolderIndex = ConfigParamMap.get("folderIndex");
			strImageIndex = ConfigParamMap.get("imageVolumeIndex");

			// short iJtsPort = (short) jtsPort;

			logger.debug("Folder Index: " + strFolderIndex);
			logger.debug("Image Volume Index: " + strImageIndex);

			if (!(strFolderIndex.equalsIgnoreCase("") && strImageIndex.equalsIgnoreCase(""))) {

				try {
					logger.debug("Inside Adding PN File: ");
					logger.debug("sFilepath: " + sFilepath);
					String filepath = sFilepath;

					File newfile = new File(filepath);
					String name = newfile.getName();
					String ext = "";
					String sMappedInputXml = "";
					if (name.contains(".")) {
						ext = name.substring(name.lastIndexOf("."), name.length());
					}
					JPISIsIndex ISINDEX = new JPISIsIndex();
					JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
					String strDocumentPath = sFilepath;
					File processFile = null;
					long lLngFileSize = 0L;
					processFile = new File(strDocumentPath);

					lLngFileSize = processFile.length();
					String lstrDocFileSize = "";
					lstrDocFileSize = Long.toString(lLngFileSize);

					String createdbyappname = "";
					createdbyappname = ext.replaceFirst(".", "");
					Short volIdShort = Short.valueOf(strImageIndex);

					logger.debug("lLngFileSize: --" + lLngFileSize);

					/*
					 * String sMappedInputXml =
					 * CommonMethods.getNGOAddDocument(strFolderIndex,FrmType,
					 * "N",createdbyappname,
					 * ISINDEX,lstrDocFileSize,strImageIndex,cabinetName,
					 * sessionID);
					 */
					logger.debug("sMappedInputXml " + sMappedInputXml);

					if (lLngFileSize != 0L) {
						logger.debug("sJtsIp --" + jtsIP + " iJtsPort-- " + "10000" + " sCabname--" + cabinetName + "\n"
								+ " volIdShort.shortValue() --" + volIdShort.shortValue() + "\n" + " strDocumentPath--"
								+ strDocumentPath + "\n" + " JPISDEC --" + JPISDEC + "  ISINDEX-- " + ISINDEX);
						CPISDocumentTxn.AddDocument_MT(null, jtsIP, Short.parseShort("10000"), cabinetName,
								volIdShort.shortValue(), strDocumentPath, JPISDEC, "", ISINDEX);

					}

					sMappedInputXml = "<?xml version=\"1.0\"?>" + "<NGOAddDocument_Input>"
							+ "<Option>NGOAddDocument</Option>" + "<CabinetName>" + cabinetName + "</CabinetName>"
							+ "<UserDBId>" + sessionID + "</UserDBId>" + "<GroupIndex>0</GroupIndex>"
							+ "<VersionFlag>Y</VersionFlag>" + "<ParentFolderIndex>" + strFolderIndex
							+ "</ParentFolderIndex>" + "<DocumentName>" + FrmType + "</DocumentName>"
							+ "<CreatedByAppName>" + createdbyappname + "</CreatedByAppName>" + "<Comment>" + FrmType
							+ "</Comment>" + "<VolumeIndex>" + ISINDEX.m_sVolumeId + "</VolumeIndex>" + "<FilePath>"
							+ strDocumentPath + "</FilePath>" + "<ISIndex>" + ISINDEX.m_nDocIndex + "#"
							+ ISINDEX.m_sVolumeId + "</ISIndex>" + "<NoOfPages>1</NoOfPages>"
							+ "<DocumentType>N</DocumentType>" + "<DocumentSize>" + lstrDocFileSize + "</DocumentSize>"
							+ "</NGOAddDocument_Input>";

					logger.debug("Document Addition sInputXML: " + sMappedInputXml);

					// String sOutputXml =
					// WFCustomCallBroker.execute(sMappedInputXml, sJtsIp,
					// iJtsPort, 1);
					String sOutputXML = CommonMethods.WFNGExecute(sMappedInputXml, jtsIP, jtsPort, 1);
					XMLParser OPxmlParserData = new XMLParser(sOutputXML);
					logger.debug("Document Addition sOutputXml: " + sOutputXML);
					String status_D = OPxmlParserData.getValueOf("Status");
					if (status_D.equalsIgnoreCase("0")) {
						// deleteLocalDocument(sFilepath);
						return sOutputXML;
					} else {
						return "Error in Document Addition";
					}
				} catch (JPISException e) {
					return "Error in Document Addition at Volume";
				} catch (Exception e) {
					return "Exception Occurred in Document Addition";
				}

			}
			return "Any Error occurred in Addition of Document";
		} catch (Exception e) {
			return "Exception Occurred in SearchDocument";
		}
	}

	public static String getTagValues(String sXML, String sTagName) {
		String sTagValues = "";
		String sStartTag = "<" + sTagName + ">";
		String sEndTag = "</" + sTagName + ">";
		String tempXML = sXML;
		try {
			for (int i = 0; i < sXML.split(sEndTag).length; i++) {
				if (tempXML.indexOf(sStartTag) != -1) {
					sTagValues += tempXML.substring(tempXML.indexOf(sStartTag) + sStartTag.length(),
							tempXML.indexOf(sEndTag));
					// System.//out.println("sTagValues"+sTagValues);
					tempXML = tempXML.substring(tempXML.indexOf(sEndTag) + sEndTag.length(), tempXML.length());
				}
				if (tempXML.indexOf(sStartTag) != -1) {
					sTagValues += "`";
					// System.//out.println("sTagValues"+sTagValues);

				}
				// System.//out.println("sTagValues"+sTagValues);
			}
			// System.//out.println(" Final sTagValues"+sTagValues);
		}

		catch (Exception e) {
		}
		return sTagValues;
	}

}
