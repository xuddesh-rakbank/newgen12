/*
---------------------------------------------------------------------------------------------------------
                  NEWGEN SOFTWARE TECHNOLOGIES LIMITED

Group                   : Application - Projects
Project/Product			: RAK BPM
Application				: RAK BPM Utility
Module					: RAOP Status
File Name				: RAOPStatus.java
Author 					: Ravindra Kumar	
Date (DD/MM/YYYY)		: 01/06/2022

---------------------------------------------------------------------------------------------------------
                 	CHANGE HISTORY
---------------------------------------------------------------------------------------------------------

Problem No/CR No        Change Date           Changed By             Change Description
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
*/


package com.newgen.DCC.Final_Limit_Increase;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.newgen.DCC.CardClosure.DCC_CardClosureLog;
import com.newgen.DCC.EFMS.DCC_MurabahaDealIntegration;
import com.newgen.DCC.Notify.DCC_Notify_CAPS;
import com.newgen.DCC.Update_AssignCIF.DCC_Service_Maintenance;
import com.newgen.DCC.Update_AssignCIF.DCC_UpdateAssignCIFLog;
import com.newgen.common.CommonConnection;
import com.newgen.common.CommonMethods;
import com.newgen.omni.jts.cmgr.XMLParser;


public class DCC_FINAL_LIMIT_INC implements Runnable
{
	static Map<String, String> DCC_FINAL_LIMIT_INCConfigParamMap= new HashMap<String, String>();
	HashMap<String, String> socketDetailsMap = new HashMap<String,String> ();

	int socketConnectionTimeout=0;
	int integrationWaitTime=0;
	int sleepIntervalInMin=0;
	int TrialTime = 0;
	int ErrorCount = 0;
	private static String cabinetName = null;
	private static String jtsIP = null;
	private static String jtsPort = null;
	private static String queueID = null;
	private String sessionID = null;
	public String actioneddate="";
	@Override
	public void run()
	{
		try
		{
			DCC_FINAL_LIMIT_LOG.setLogger();

			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Connecting to Cabinet.");

			int configReadStatus = readConfig();

			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("configReadStatus "+configReadStatus);
			if(configReadStatus !=0)
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Could not Read Config Properties [DCCNotifyAPP]");
				return;
			}

			cabinetName = CommonConnection.getCabinetName();
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Cabinet Name: " + cabinetName);

			jtsIP = CommonConnection.getJTSIP();
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("JTSIP: " + jtsIP);

			jtsPort = CommonConnection.getJTSPort();
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("JTSPORT: " + jtsPort);

			queueID = DCC_FINAL_LIMIT_INCConfigParamMap.get("queueID");
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("QueueID: " + queueID);

			socketConnectionTimeout=Integer.parseInt(DCC_FINAL_LIMIT_INCConfigParamMap.get("MQ_SOCKET_CONNECTION_TIMEOUT"));
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("SocketConnectionTimeOut: "+socketConnectionTimeout);

			integrationWaitTime=Integer.parseInt(DCC_FINAL_LIMIT_INCConfigParamMap.get("INTEGRATION_WAIT_TIME"));
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("IntegrationWaitTime: "+integrationWaitTime);

			sleepIntervalInMin=Integer.parseInt(DCC_FINAL_LIMIT_INCConfigParamMap.get("SleepIntervalInMin"));
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("SleepIntervalInMin: "+sleepIntervalInMin);
			
			TrialTime=Integer.parseInt(DCC_FINAL_LIMIT_INCConfigParamMap.get("TrialTime"));
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("TrialTime: "+TrialTime);


			ErrorCount=Integer.parseInt(DCC_FINAL_LIMIT_INCConfigParamMap.get("ErrorCount"));
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("ErrorCount: "+ErrorCount);


			sessionID = CommonConnection.getSessionID(DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC, false);

			if(sessionID.trim().equalsIgnoreCase(""))
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Could Not Connect to Server!");
			}
			else
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Session ID found: " + sessionID);
				HashMap<String, String> socketDetailsMap = CommonMethods.socketConnectionDetails(cabinetName, jtsIP, jtsPort, sessionID);
				while (true) {
					DCC_FINAL_LIMIT_LOG.setLogger();
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("DCC Notify TO DEH ...123.");
					DCC_FINAL_LIMIT(cabinetName, jtsIP, jtsPort, queueID, socketConnectionTimeout, integrationWaitTime, socketDetailsMap);
					System.out.println("No More workitems to Process, Sleeping!");
					Thread.sleep(sleepIntervalInMin * 60 * 1000);
				}
			}
		}

		catch(Exception e)
		{
			e.printStackTrace();
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception Occurred in DCCNotifyAPP : "+e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception Occurred in DCCNotifyAPP : "+result);
		}
	}

	@SuppressWarnings("unused")
	private void DCC_FINAL_LIMIT(String cabinetName, String sJtsIp, String iJtsPort, String queueID, 
			int socketConnectionTimeOut, int integrationWaitTime, HashMap<String, String> socketDetailsMap)
	{
		final String ws_name="Sys_Limit_Increase";
		
		try
		{
			final HashMap<String, String> CheckGridDataMap = new HashMap<String, String>();
			//Validate Session ID
			sessionID  = CommonConnection.getSessionID(DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC, false);

			if (sessionID == null || sessionID.equalsIgnoreCase("") || sessionID.equalsIgnoreCase("null"))
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Could Not Get Session ID "+sessionID);
				return;
			}

			//Fetch all Work-Items on given queueID.
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Fetching all Workitems on DCCNotifyAPP queue");
			System.out.println("Fetching all Workitems on DCC_FINAL_LIMIT queue");
			String fetchWorkitemListInputXML=CommonMethods.fetchWorkItemsInput(cabinetName, sessionID, queueID);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("InputXML for fetchWorkList Call DCC_FINAL_LIMIT: "+fetchWorkitemListInputXML);

			String fetchWorkitemListOutputXML= CommonMethods.WFNGExecute(fetchWorkitemListInputXML,sJtsIp,iJtsPort,1);

			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("WMFetchWorkList DCC_FINAL_LIMIT OutputXML: "+fetchWorkitemListOutputXML);

			XMLParser xmlParserFetchWorkItemlist = new XMLParser(fetchWorkitemListOutputXML);

			String fetchWorkItemListMainCode = xmlParserFetchWorkItemlist.getValueOf("MainCode");
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("FetchWorkItemListMainCode: "+fetchWorkItemListMainCode);

			int fetchWorkitemListCount = Integer.parseInt(xmlParserFetchWorkItemlist.getValueOf("RetrievedCount"));
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("RetrievedCount for WMFetchWorkList Call: "+fetchWorkitemListCount);

			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Number of workitems retrieved on DCC_FINAL_LIMIT: "+fetchWorkitemListCount);

			System.out.println("Number of workitems retrieved on DCC_FINAL_LIMIT: "+fetchWorkitemListCount);

			if (fetchWorkItemListMainCode.trim().equals("0") && fetchWorkitemListCount > 0)
			{
				for(int i=0; i<fetchWorkitemListCount; i++)
				{
					String fetchWorkItemlistData=xmlParserFetchWorkItemlist.getNextValueOf("Instrument");
					fetchWorkItemlistData =fetchWorkItemlistData.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Parsing <Instrument> in WMFetchWorkList OutputXML: "+fetchWorkItemlistData);
					XMLParser xmlParserfetchWorkItemData = new XMLParser(fetchWorkItemlistData);

					String processInstanceID=xmlParserfetchWorkItemData.getValueOf("ProcessInstanceId");
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Current ProcessInstanceID: "+processInstanceID);
					//processInstanceID="DCC-0000000833-process";
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Processing Workitem: "+processInstanceID);
					System.out.println("\nProcessing Workitem: "+processInstanceID);

					String WorkItemID=xmlParserfetchWorkItemData.getValueOf("WorkItemId");
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Current WorkItemID: "+WorkItemID);

					String entryDateTime=xmlParserfetchWorkItemData.getValueOf("EntryDateTime");
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Current EntryDateTime: "+entryDateTime);

					String ActivityName=xmlParserfetchWorkItemData.getValueOf("ActivityName");
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("ActivityName: "+ActivityName);
					
					String ActivityID = xmlParserfetchWorkItemData.getValueOf("WorkStageId");
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("ActivityID: "+ActivityID);
					String ActivityType = xmlParserfetchWorkItemData.getValueOf("ActivityType");
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("ActivityType: "+ActivityType);
					String ProcessDefId = xmlParserfetchWorkItemData.getValueOf("RouteId");
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("ProcessDefId: "+ProcessDefId);
					
					String NTB="";
					String FYF="";
					String Etb_new="";
					String Service_type="";
					String Final_Limit="",Requested_Limit="",Cli_stp="";
					// Hritik - 18/07/23 -- ETB 
					try{
						String StrExttable_query = "SELECT WI_NAME,NTB,FYF,isnull(Etb_new,'') as 'Etb_new',Service_type,Final_Limit,Requested_Limit,Cli_stp FROM NG_DCC_EXTTABLE with(nolock) WHERE WI_NAME='" + processInstanceID + "'";
						
						String extTabDataIPXML = CommonMethods.apSelectWithColumnNames(StrExttable_query,cabinetName,sessionID);
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("StrExttable_query: " + StrExttable_query);
						String extTabDataOPXML = CommonMethods.WFNGExecute(extTabDataIPXML, CommonConnection.getJTSIP(), CommonConnection.getJTSPort(), 1);
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataOPXML: " + extTabDataOPXML);
						XMLParser xmlParserData = new XMLParser(extTabDataOPXML);
						String mainCode=xmlParserData.getValueOf("MainCode");
						int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));
						
						if (mainCode!=null && !"".equalsIgnoreCase(mainCode) && mainCode.equalsIgnoreCase("0")  && iTotalrec > 0){
							NTB=xmlParserData.getValueOf("NTB");
							FYF = xmlParserData.getValueOf("FYF");
							Etb_new=xmlParserData.getValueOf("Etb_new");
							Service_type=xmlParserData.getValueOf("Service_type");
							Final_Limit=xmlParserData.getValueOf("Final_Limit");
							Requested_Limit=xmlParserData.getValueOf("Requested_Limit");
							Cli_stp=xmlParserData.getValueOf("Cli_stp");
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("NTB: " + NTB);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("FYF: " + FYF);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Etb_new" + Etb_new);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Service_type" + Service_type);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Final_Limit" + Final_Limit);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Requested_Limit" + Requested_Limit);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Cli_stp" + Cli_stp);
						}
						
						Date current_date = new Date();
						DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						String entrydatetime = dateFormat.format(current_date);
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("entrydatetime: " + entrydatetime);
						
						if("false".equalsIgnoreCase(NTB) && "CLI".equalsIgnoreCase(Service_type)) { // PDSC-1929 Hritik 28.05.2024 
							try{
								DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("CLI NCAPS Start :");
								DCC_Notify_CAPS obj_DCC_Notify_CAPS = new DCC_Notify_CAPS(DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC);
								String notifyCapsStatus=obj_DCC_Notify_CAPS.DCC_Notify_CAPS_Integration(cabinetName, sessionID, sJtsIp, iJtsPort, processInstanceID, ws_name,CommonConnection.getUsername(), socketConnectionTimeOut, integrationWaitTime, socketDetailsMap);
								//vinayak 26-09-24 set final limit as requested limit for cli_stp "y" cases
								if("Y".equalsIgnoreCase(Cli_stp)){
									String updateStatus=updateDataInExtTable(processInstanceID,"Final_Limit",Requested_Limit);
								}
								//end
								if("Success".equalsIgnoreCase(notifyCapsStatus))
								{
									String decisionUpdate=updateDataInExtTable(processInstanceID,"Decision","Success");
									completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Success", entryDateTime,"");
									DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("CLI NCAPS completeWorkItem :");
									continue;
								}
								else {
									String arr[];
									String ErrDesc="";
									if(notifyCapsStatus.contains("Failure")) {
										arr=notifyCapsStatus.split("~");
										if(arr.length>2)
											ErrDesc=arr[2];
									}
									//MANTHAN 28.01.2025
									String decisionUpdate=updateDataInExtTable(processInstanceID,"Decision","Failed");
									
									completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Failed", entryDateTime,"Notify CAPS Failed-"+ErrDesc);
									DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("CLI NCAPS Failed completeWorkItem :");
									continue;
								}
							}
							catch (Exception e) {
								DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Exception in CLI DCC_Notify_CAPS : "+e.getMessage());
							}
						}
						
						if("false".equalsIgnoreCase(NTB) && "".equalsIgnoreCase(Etb_new)) // pipeline ETB handle PDSC - 1435
						{
							String ServiceFeeFlag=getFeeApplicableFlag(processInstanceID);
							
							String tableName="NG_DCC_GR_ETB_REQ_STATUS";
							String Col = "WI_NAME,Request_status,Workstep,entry_date,Service_fee,EK_Card_FYF";
							String val = "'"+processInstanceID+"','Limit Increase','Sys_Limit_Increase','"+entrydatetime+"','"+ServiceFeeFlag+"','"+FYF+"'";
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Col: " + Col);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("val: " + val);
							
							String inputXML = CommonMethods.apInsert(cabinetName, sessionID, Col, val, tableName);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.info("Insert No" + inputXML);
							String outputXML = CommonMethods.WFNGExecute(inputXML, jtsIP, jtsPort, 1);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.info("Insert No outXml" + outputXML);
							XMLParser xmlParser = new XMLParser(outputXML);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.info("apInsert : " +processInstanceID + " ; MainCode" + xmlParser.getValueOf("MainCode"));
							String mainCode_apinsert=xmlParser.getValueOf("MainCode");
							if (mainCode_apinsert!=null && !"".equalsIgnoreCase(mainCode_apinsert) && mainCode_apinsert.equalsIgnoreCase("0")){
								
								completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Success", entryDateTime,"ETB Request status insert success");
								continue;
							}
							else{
								completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Failed", entryDateTime,"ETB Request status insert Failed");
								continue;
							}
						}
					}
					catch (Exception e){
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Exception ETB : " + e.getMessage());
					}
					
					String status=executeMurahabhaCalls(processInstanceID,ws_name,WorkItemID,entryDateTime,ActivityType);
					if("Error".equalsIgnoreCase(status)||status.contains("Fail"))
					{
						String errdec="Murahabha CALL Failed";
						if(status.contains("Fail"))
						{
							String arr[] = status.split("_");
							if(arr.length>1)
							errdec="Murahabha CALL "+arr[1]+" Failed";
						}
						completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Failed", entryDateTime,errdec);
						continue;
					}
					
					DCC_Notify_CAPS obj_DCC_Notify_CAPS = new DCC_Notify_CAPS(DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC);
					String notifyCapsStatus=obj_DCC_Notify_CAPS.DCC_Notify_CAPS_Integration(cabinetName, sessionID, sJtsIp, iJtsPort, processInstanceID, ws_name,CommonConnection.getUsername(), socketConnectionTimeOut, integrationWaitTime, socketDetailsMap);
					if("Success".equalsIgnoreCase(notifyCapsStatus))
					{
						String ServiceFeeFlag=getFeeApplicableFlag(processInstanceID);
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Service Fee Flag:- "+ProcessDefId);
						if("R".equalsIgnoreCase(ServiceFeeFlag) || "NA".equalsIgnoreCase(ServiceFeeFlag))
						{
							String updateStatus=updateDataInExtTable(processInstanceID,"service_fee_flag",ServiceFeeFlag);
							if("Success".equalsIgnoreCase(updateStatus))
							{
							completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Success", entryDateTime,"");
							}
							else
							completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Failed", entryDateTime,"Error in Updating Service Fee Flag..");
							continue;
						}
						else
						completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Failed", entryDateTime,"Error in getting Fee Applicable Flag..");
							continue;
						
					}
					else
					{
						String arr[];
						String ErrDesc="";
						if(notifyCapsStatus.contains("Failure"))
						{
							arr=notifyCapsStatus.split("~");
							if(arr.length>2)
								ErrDesc=arr[2];
						}
						completeWorkItem(cabinetName,processInstanceID,WorkItemID, "Failed", entryDateTime,"Notify CAPS Failed-"+ErrDesc);
					}
				   }
				}
			}
		catch (Exception e)
		{
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Exception: "+e.getMessage());
		}
	}
	
	public String executeMurahabhaCalls(String processInstanceID,String ws_name,String WorkItemID,String entryDateTime,String ActivityType)
	{
		
		try
		{
			String islamicflag=isIslamic(processInstanceID);
			if("Y".equalsIgnoreCase(islamicflag))
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Execute Murabha calls--");
				String query="select ResponseFlag from NG_DCC_MURABAHA_RESPONSE_DATA  with(nolock) where call_seq=2 and wi_name='"+processInstanceID+"'";
				
				String MURABAHAIPXML = CommonMethods.apSelectWithColumnNames(query,cabinetName,sessionID);
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataIPXML: " + MURABAHAIPXML);
				String MURABAHAIPXMLOPXML = CommonMethods.WFNGExecute(MURABAHAIPXML,jtsIP,jtsPort, 1);
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataOPXML: " + MURABAHAIPXMLOPXML);
	
				XMLParser xmlParserData = new XMLParser(MURABAHAIPXMLOPXML);
				int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));
				String mainCode=xmlParserData.getValueOf("MainCode");
				String responseflag= xmlParserData.getValueOf("ResponseFlag");
				if("0".equalsIgnoreCase(mainCode) && (iTotalrec==0 || !"SUCCESS".equalsIgnoreCase(responseflag)) )
				{
					DCC_MurabahaDealIntegration  MurahabaObj = new DCC_MurabahaDealIntegration(DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC);
					String MurabhaCallsStatus=MurahabaObj.MurabahaReqDeal(cabinetName, jtsIP, jtsPort, sessionID, processInstanceID, socketConnectionTimeout, integrationWaitTime, socketDetailsMap, TrialTime, ErrorCount, ws_name,"2");
					if("Success".equalsIgnoreCase(MurabhaCallsStatus))
					{
						return "Success";
					}
					else
					{
						if(MurabhaCallsStatus.contains("Fail"))
							return MurabhaCallsStatus;
						return "Error";
					}
				}
				else if(iTotalrec>0 && "SUCCESS".equalsIgnoreCase(responseflag))
				{
					return "Success";
				}
				else
				{
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Some error occured in getting Murahabha Response flag--" +mainCode);
					return "Error";
				}
			}
			else if("N".equalsIgnoreCase(islamicflag))
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Case is not islamic!");
				return "Success";
			}
			else
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Some error occured in getting ISLAMIC flag-");
				return "Error";
				
			}
			
		}
		catch(Exception e)
		{
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception in executing Murahabha calls-"+e.toString());
			return "Error";
		}
		
	}
	private String isIslamic(String processInstanceID)
	{
		String isIslamic="";
		try
		{
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Check if the case  is Islamic--");
			String query="select Product from NG_DCC_EXTTABLE  with(nolock) where wi_name='"+processInstanceID+"'";
			
			String ISLAMIC_CHECK_IPXML = CommonMethods.apSelectWithColumnNames(query,cabinetName,sessionID);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataIPXML: " + ISLAMIC_CHECK_IPXML);
			String ISLAMIC_CHECK_OPXML = CommonMethods.WFNGExecute(ISLAMIC_CHECK_IPXML,jtsIP,jtsPort, 1);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataOPXML: " + ISLAMIC_CHECK_OPXML);

			XMLParser xmlParserData = new XMLParser(ISLAMIC_CHECK_OPXML);
			
			String mainCode=xmlParserData.getValueOf("MainCode");
			String poduct= xmlParserData.getValueOf("Product");
			if("0".equalsIgnoreCase(mainCode) )
			{
				int iTotalrec = Integer.parseInt(xmlParserData.getValueOf("TotalRetrieved"));
				if(iTotalrec>0)
				{
					if("ISL".equalsIgnoreCase(poduct))
					{
						isIslamic="Y";
					}
					else
						isIslamic="N";	
				}
				else
				{
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Islamic data is not available for this item--" +processInstanceID);
					isIslamic="E";	
				}
			}
			else
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Some error occured in getting product--" +mainCode);
				isIslamic="E";	
			}
		}
		catch (Exception e)
		{
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception in isIslamic method--" +e.toString());
			isIslamic="E";
		}
		return isIslamic;
	}
	private String getFeeApplicableFlag(String processInstanceID)
	{
		String isFeeApplicable="";
		try
		{
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Check if the Fees is applicable for the card--");
			String query="select isnull((select isFeeApplicable from  Ng_Dcc_Master_Card_Product_Fee_Enable where Card_product=Card_Product_Sub_Type),'N') as isFeeApplicable from NG_DCC_EXTTABLE  with(nolock) where wi_name='"+processInstanceID+"'";
			
			String ISFEE_APPLCBL_IPXML = CommonMethods.apSelectWithColumnNames(query,cabinetName,sessionID);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataIPXML: " + ISFEE_APPLCBL_IPXML);
			String ISFEE_APPLCBL_OPXML = CommonMethods.WFNGExecute(ISFEE_APPLCBL_IPXML,jtsIP,jtsPort, 1);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataOPXML: " + ISFEE_APPLCBL_OPXML);

			XMLParser xmlParserData = new XMLParser(ISFEE_APPLCBL_OPXML);
			
			String mainCode=xmlParserData.getValueOf("MainCode");
			String totalRec = xmlParserData.getValueOf("TotalRetrieved");
			
			if("0".equalsIgnoreCase(mainCode) && totalRec!=null && !"".equalsIgnoreCase(totalRec) && Integer.parseInt(totalRec)>0 )
			{
				isFeeApplicable= xmlParserData.getValueOf("isFeeApplicable");
				if("Y".equalsIgnoreCase(isFeeApplicable))
					isFeeApplicable="R";
				else if("N".equalsIgnoreCase(isFeeApplicable))
					isFeeApplicable="NA";
				else
					isFeeApplicable="NA";
			}
			else
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Some error occured in getting fee flag--" +mainCode);
				isFeeApplicable="E";	
			}
		}
		catch (Exception e)
		{
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception in getFeeApplicableFlag method--" +e.toString());
			isFeeApplicable="E";
		}
		return isFeeApplicable;
	}
	public String updateDataInExtTable(String processInstanceId, String columnName , String value)
	{
		try {
			String sWhereClause = "Wi_Name = '" + processInstanceId + "'";
			value = "'"+ value+"'";
			String columnNames1 = columnName;
			String columnValues1 = value;
			//String sWhereClause = "Workitem_no = '" + processInstanceID + "' and Firco_ID = '" + objWorkList.getVal("FIRCO_ECN_No") + "'";

			String extTableIPUpdateXml = CommonMethods.apUpdateInput(cabinetName, sessionID, "NG_DCC_EXTTABLE", columnNames1, columnValues1, sWhereClause);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Input XML for apUpdateInput for NG_DCC_EXTTABLE Table : " + extTableIPUpdateXml);

			String extTableOPUpdateXml = CommonMethods.WFNGExecute(extTableIPUpdateXml, jtsIP, jtsPort, 1);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Output XML for apUpdateInput for NG_DCC_EXTTABLE Table : " + extTableOPUpdateXml);

			XMLParser sXMLParserChild = new XMLParser(extTableOPUpdateXml);
			String StrMainCode = sXMLParserChild.getValueOf("MainCode");

			if (StrMainCode.equals("0"))
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Successful in apUpdateInput the record in : NG_DCC_EXTTABLE");
				return "Success";
			}
				
			else
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Error in Executing apUpdateInput sOutputXML : " + sXMLParserChild);
				return null;
			}
		}catch(Exception e){
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Exception in updating ext table: " + e.getMessage());
			System.out.println("Exception in updating ext table: " + e.getMessage());
			return null;
		}
	}
	private String completeWorkItem(String cabinetName, String processInstanceID,String workItemId, String decision, String entryDateTime,String remarks) {
		
		try {
			String getWorkItemInputXML = CommonMethods.getWorkItemInput(cabinetName, sessionID, processInstanceID, workItemId);
			String getWorkItemOutputXml = CommonMethods.WFNGExecute(getWorkItemInputXML, jtsIP, jtsPort, 1);

			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Output XML for getWorkItem is " + getWorkItemOutputXml);

			XMLParser xmlParserGetWorkItem = new XMLParser(getWorkItemOutputXml);
			String getWorkItemMainCode = xmlParserGetWorkItem.getValueOf("MainCode");

			if ("0".equals(getWorkItemMainCode)) {
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.info("get Workitem call successfull for " + processInstanceID);
				String attrbuteTag = "<Decision>" + decision + "</Decision>";
				String assignWorkitemAttributeInputXML = CommonMethods.assignWorkitemAttributeInput(cabinetName, sessionID, processInstanceID, workItemId, attrbuteTag);
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Input XML for assign Attribute is " + assignWorkitemAttributeInputXML);

				String assignWorkitemAttributeOutputXML = CommonMethods.WFNGExecute(assignWorkitemAttributeInputXML, jtsIP, jtsPort, 1);
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Output XML for assign Attribues is " + assignWorkitemAttributeOutputXML);

				XMLParser xmlParserAssignAtt = new XMLParser(assignWorkitemAttributeOutputXML);

				String mainCodeAssignAtt = xmlParserAssignAtt.getValueOf("MainCode");
				if ("0".equals(mainCodeAssignAtt.trim())) {
					String completeWorkItemInputXML = CommonMethods.completeWorkItemInput(cabinetName, sessionID, processInstanceID, workItemId);

					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Input XML for complete WI is " + completeWorkItemInputXML);

					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Input XML for wmcompleteWorkItem: " + completeWorkItemInputXML);

					String completeWorkItemOutputXML = CommonMethods.WFNGExecute(completeWorkItemInputXML, jtsIP, jtsPort, 1);
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Output XML for wmcompleteWorkItem: " + completeWorkItemOutputXML);

					XMLParser xmlParserCompleteWorkitem = new XMLParser(completeWorkItemOutputXML);
					String completeWorkitemMaincode = xmlParserCompleteWorkitem.getValueOf("MainCode");
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Status of wmcompleteWorkItem  " + completeWorkitemMaincode);

					if ("0".equals(completeWorkitemMaincode)) {
						// inserting into history table
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("WmCompleteWorkItem successful: " + completeWorkitemMaincode);
						// System.out.println(processInstanceID + "Complete Sussesfully with status "+objResponseBean.getIntegrationDecision());

						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("WorkItem moved to next Workstep.");

						SimpleDateFormat inputDateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
						SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");

						Date entryDatetimeFormat = inputDateformat.parse(entryDateTime);
						String formattedEntryDatetime = outputDateFormat.format(entryDatetimeFormat);
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("FormattedEntryDatetime: " + formattedEntryDatetime);

						Date actionDateTime = new Date();
						String formattedActionDateTime = outputDateFormat.format(actionDateTime);
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("FormattedActionDateTime: " + formattedActionDateTime);

						// Insert in WIHistory Table.
						
						String columnNames = "WI_NAME,dec_date,WORKSTEP,USER_NAME,DECISION,decision_date_time,Remarks";
						String columnValues = "'" + processInstanceID + "','" + formattedActionDateTime + "','Sys_Limit_Increase','" + CommonConnection.getUsername() + "','" + decision + "','"
								+ formattedEntryDatetime + "','"+remarks+"'";

						String apInsertInputXML = CommonMethods.apInsert(cabinetName, sessionID, columnNames, columnValues, "NG_DCC_GR_DECISION_HISTORY");
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("APInsertInputXML: " + apInsertInputXML);

						String apInsertOutputXML = CommonMethods.WFNGExecute(apInsertInputXML, jtsIP, jtsPort, 1);
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("APInsertOutputXML: " + apInsertOutputXML);

						XMLParser xmlParserAPInsert = new XMLParser(apInsertOutputXML);
						String apInsertMaincode = xmlParserAPInsert.getValueOf("MainCode");
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Status of apInsertMaincode  " + apInsertMaincode);
						if (apInsertMaincode.equalsIgnoreCase("0")) {
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("ApInsert successful: " + apInsertMaincode);
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Inserted in WiHistory table successfully.");
						} else {
							DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("ApInsert failed: " + apInsertMaincode);
						}
					} else {
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Error in completeWI call for " + processInstanceID);
					}
				} else {
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Error in Assign Attribute call for WI " + processInstanceID);
				}

			} else {
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Error in getWI call for WI " + processInstanceID);
			}

		}

		catch (Exception e) {
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception " + e);
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception Occurred in TAO Integration Thread : " + result);
			System.out.println("Exception " + e);

		}
		return "";
	}

	private int readConfig() {
		Properties p = null;
		try {

			p = new Properties();
			p.load(new FileInputStream(new File(System.getProperty("user.dir") + File.separator + "ConfigFiles" + File.separator + "DCC_FINAL_LIMIT_INC.properties")));

			Enumeration<?> names = p.propertyNames();

			while (names.hasMoreElements()) {
				String name = (String) names.nextElement();
				DCC_FINAL_LIMIT_INCConfigParamMap.put(name, p.getProperty(name));
			}
		} catch (Exception e) {
			return -1;
		}
		return 0;
	}
	public String serviceMaintainance_final_limit(String processInstanceID)
	{
		String ismaintainanceapplicable="";
		String card_product="";
		String card_sub_product="";
		String FYF="";
		//Deepak changes done to move fee delay days in master Ng_Dcc_Master_Card_Product_Fee_Enable - 20Nov23
		int Fee_delay_days = 0;
		try
		{
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Check if the Fees is applicable for the card--");
			String query="select Card_Product_Sub_Type,FYF from NG_DCC_EXTTABLE  with(nolock) where wi_name='"+processInstanceID+"'";
			String Card_Product_Sub_Type_IPXML = CommonMethods.apSelectWithColumnNames(query,cabinetName,sessionID);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataIPXML: " + Card_Product_Sub_Type_IPXML);
			String Card_Product_Sub_Type_OPXML = CommonMethods.WFNGExecute(Card_Product_Sub_Type_IPXML,jtsIP,jtsPort, 1);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataOPXML: " + Card_Product_Sub_Type_OPXML);
			XMLParser xmlParserData = new XMLParser(Card_Product_Sub_Type_OPXML);
			String mainCode=xmlParserData.getValueOf("MainCode");
			String totalRec = xmlParserData.getValueOf("TotalRetrieved");
			if("0".equalsIgnoreCase(mainCode) && totalRec!=null && !"".equalsIgnoreCase(totalRec) && Integer.parseInt(totalRec)>0 )
			{
				card_product= xmlParserData.getValueOf("Card_Product_Sub_Type");
				FYF= xmlParserData.getValueOf("FYF");
				if(FYF.equalsIgnoreCase("") || FYF.equalsIgnoreCase(null)){
					FYF="NA";
				}
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("FYF flag value " + FYF);
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Card_Product_Sub_Type  value " + card_product);
			}
			else
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Some error occured in getting fee flag--" +mainCode);
				ismaintainanceapplicable="E";	
			}
			
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Check if the Fees is applicable for the card--");
			//Deepak changes done to move fee delay days in master Ng_Dcc_Master_Card_Product_Fee_Enable - 20Nov23
			String query2="select Card_product,isNull(Fee_delay_days,0) as Fee_delay_days from Ng_Dcc_Master_Card_Product_Fee_Enable where Card_product='"+card_product+"'";
			
			String Card_product_IPXML = CommonMethods.apSelectWithColumnNames(query2,cabinetName,sessionID);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataIPXML: " + Card_product_IPXML);
			String Card_product_OPXML = CommonMethods.WFNGExecute(Card_product_IPXML,jtsIP,jtsPort, 1);
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("extTabDataOPXML: " + Card_product_OPXML);

			XMLParser xmlParserData2 = new XMLParser(Card_product_OPXML);
			
			String mainCode2=xmlParserData2.getValueOf("MainCode");
			String totalRec2 = xmlParserData2.getValueOf("TotalRetrieved");
			
			if("0".equalsIgnoreCase(mainCode2) && totalRec2!=null && !"".equalsIgnoreCase(totalRec2) && Integer.parseInt(totalRec2)>0 )
			{
				card_sub_product= xmlParserData2.getValueOf("Card_product");
				ismaintainanceapplicable="Y";
				//Deepak changes done to move fee delay days in master Ng_Dcc_Master_Card_Product_Fee_Enable - 20Nov23 start
				String Fee_delay_days_str = xmlParserData2.getValueOf("Fee_delay_days");
				if("NA".equalsIgnoreCase(Fee_delay_days_str)){
					Fee_delay_days = 0;
				}
				else{
					try{
						Fee_delay_days = Integer.parseInt(Fee_delay_days_str);
					}
					catch(Exception e){
						Fee_delay_days = 0;
						DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception while converting Fee_delay_days flag" +e.getMessage());
					}
					
				}
				//Deepak changes done to move fee delay days in master Ng_Dcc_Master_Card_Product_Fee_Enable - 20Nov23 -end
			}
			else
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Some error occured in getting fee flag--" +mainCode);
				ismaintainanceapplicable="E";	
			}
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("ismaintainanceapplicable flag value " + ismaintainanceapplicable);
			if("Y".equalsIgnoreCase(ismaintainanceapplicable))
			{
				Date current_date = new Date();
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");				
				 actioneddate=dateFormat.format(current_date);
				
				//Calendar cal=Calendar.getInstance();
				 DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("card_sub_product  value " + card_sub_product);
				 DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("FYF  value " + FYF);
				if(card_sub_product.contains("EK") && "Y".equalsIgnoreCase(FYF))
						{
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("inside ek card fyf n");
							Calendar cal=Calendar.getInstance();
							cal.add(Calendar.DAY_OF_MONTH,365);
							actioneddate=dateFormat.format(cal.getTime());
						}
				else if(card_sub_product.contains("EK") && "N".equalsIgnoreCase(FYF))
						{
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("inside ek card fyf y");
							actioneddate=actioneddate;
						}
				else{
					//Deepak changes done to move fee delay days in master Ng_Dcc_Master_Card_Product_Fee_Enable - 20Nov23
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("Inside Else, to add no of day in action date by days: " + Fee_delay_days );
					Calendar cal=Calendar.getInstance();
					cal.add(Calendar.DAY_OF_MONTH,Fee_delay_days);
					actioneddate=dateFormat.format(cal.getTime());
				}
				/*else if(card_sub_product.contains("WORLD"))
						{
					DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("inside world card");
							Calendar cal=Calendar.getInstance();
							cal.add(Calendar.DAY_OF_MONTH,365);
							actioneddate=dateFormat.format(cal.getTime());
						}*/
				
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.debug("actioneddate  value " + actioneddate);
				
				
			}
			else
			{
				DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception in getFeeApplicableFlag method--" );
				ismaintainanceapplicable="E";
			}
			
		}
		catch (Exception e)
		{
			DCC_FINAL_LIMIT_LOG.DCC_FINAL_LIMIT_INC.error("Exception in getFeeApplicableFlag method--" +e.toString());
			ismaintainanceapplicable="E";
		}
		return ismaintainanceapplicable;
	}
}



