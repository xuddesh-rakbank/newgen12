package com.newgen.iforms.user;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.custom.IFormReference;

public class DigitalAO_FormLoad extends DigitalAO_Common {

	public String formLoadEvent(IFormReference iform, String controlName, String event, String data) {
		String strReturn = "";

		DigitalAO.mLogger.debug("This is DAO_FormLoad_Event" + event + " controlName :" + controlName);

		String Workstep = iform.getActivityName();
		DigitalAO.mLogger.debug("WINAME : " + getWorkitemName(iform) + ", WSNAME: " + iform.getActivityName()
				+ ", Workstep :" + Workstep);
		//ldaccounts call
		if(("operations").equalsIgnoreCase(Workstep)||("compliance").equalsIgnoreCase(Workstep)||("compliance_wc").equalsIgnoreCase(Workstep)) {
			
			String schemes = fetchLdAccountSchemes(iform);
			DigitalAO.mLogger.debug("schemes:::"+schemes);
		}
		
		
		if ("section_onLoad".equalsIgnoreCase(controlName)){
			DigitalAO.mLogger.debug("Section Disable :  Form load : log_in_as :"+iform.getUserName());
			setControlValue("log_in_as",iform.getUserName(), iform);
			DigitalAO.mLogger.debug("Section Disable :  Form load : before Section Disable");
			iform.setStyle("Customer_Information", "disable", "true");
			iform.setStyle("DigitalAO_EmpDetails", "disable", "true");
			iform.setStyle("DigitalAO_CompDetails", "disable", "true");
			iform.setStyle("Address_Details", "disable", "true");
			iform.setStyle("Income_Detail", "disable", "true");
			iform.setStyle("Contact_Details", "disable", "true");
			iform.setStyle("FATCA_CRS_Details", "disable", "true");
			iform.setStyle("System_Checks", "disable", "true");
			
			
			if(("operations").equalsIgnoreCase(Workstep)){
			
			iform.setStyle("Account_Details", "disable", "false");// pdocal-14 vinayak
			iform.setStyle("CIF", "disable", "true");
			iform.setStyle("IBAN", "disable", "true");
			iform.setStyle("product_currency", "disable", "true");
			iform.setStyle("Purpose_of_account_description", "disable", "true");
			iform.setStyle("Name_on_ChequeBk", "disable", "true");
			iform.setStyle("Name_on_Debit_Card", "disable", "true");
			iform.setStyle("Communication_Mode", "disable", "true");
			iform.setStyle("Statement", "disable", "true");
			iform.setStyle("Receive_Mrkt_Offer", "disable", "true");
			iform.setStyle("account_no", "disable", "true");
			iform.setStyle("product_typw", "disable", "true");
			iform.setStyle("Scheme_Code", "disable", "true");
			iform.setStyle("ChequeBk_Req", "disable", "true");
			iform.setStyle("is_prime_req", "disable", "true");
			iform.setStyle("DEL_CB_DC", "disable", "true");
			iform.setStyle("Prefer_Branch_Det", "disable", "true");
			iform.setStyle("Mrkt_Promo_Offer", "disable", "true");
			iform.setStyle("Payroll_account", "disable", "true");
			//14-april-2026
			iform.setStyle("Country_of_birth", "disable", "false");
			//06-02-2026
			// Getting the description for product_typ.
			String Product_type_descptn = "";
			String product_typ = (String) iform.getValue("product_typw");
			
			String account_type_query = "select account_type from NG_MASTER_DAO_PRODUCT_NAME with(nolock) where cm_code='" + product_typ + "'";
			List<List<String>> account_type_query_output = iform.getDataFromDB(account_type_query);
			DigitalAO.mLogger.debug("account_type_query_output : " + account_type_query_output);
			String account_type_val="";
			if (!account_type_query_output.isEmpty()) {
				DigitalAO.mLogger.debug("Inside account_type_query_output: ");
				 account_type_val = account_type_query_output.get(0).get(0);
				DigitalAO.mLogger.debug("account_type_val: " + account_type_val);							
			} else {
				DigitalAO.mLogger.debug("account_type_query_output is empty!!");
			}
			
			if (account_type_val.equalsIgnoreCase("Current")){
				Product_type_descptn = "Current Account";
				iform.setValue("product_type",Product_type_descptn);
				DigitalAO.mLogger.debug("product_type : " + Product_type_descptn);
			}
			else if(account_type_val.equalsIgnoreCase("Saving")){
				Product_type_descptn = "Savings Account";
				iform.setValue("product_type",Product_type_descptn);
				DigitalAO.mLogger.debug("product_type : " + Product_type_descptn);
			}
			
			
			
			//pdocal-476 vinayak 
			String highRisk = (String) iform.getValue("high_risk");
			DigitalAO.mLogger.debug("HighRisk for address_detail:"+highRisk);
			if(highRisk.equalsIgnoreCase("Y")){				
				iform.setStyle("Address_Details", "disable", "false");
				iform.setStyle("prefered_mail_address", "disable", "true");
				iform.setStyle("highRisk_occupant_type", "disable", "true");
			}
			//end
			
			
			
			}
			else{
				iform.setStyle("Account_Details", "disable", "true");
			}
			//ends
			iform.setStyle("UID_Details", "disable", "true");
			iform.setStyle("DigitalAO_BackgroundInfo", "disable", "true");
			iform.setStyle("Additional_Documents_Required", "disable", "true");
			iform.setStyle("NG_DAO_GR_DECISION_HISTORY", "disable", "true");
			iform.setStyle("Generate_RiskScore", "visible", "false");
			iform.setStyle("template_generate_kyc", "visible", "false");
			iform.setStyle("AECB_rpt", "disable", "false");
			//vinayak change jira 3727
			String is_Ntb_val = (String) iform.getValue("is_Ntb");
			if(is_Ntb_val.equalsIgnoreCase("N"))
			{
				iform.setStyle("internalExposureDetails", "visible", "true");	
				String is_stp_val=(String) iform.getValue("is_stp");
				if(("sign_upload_maker").equalsIgnoreCase(Workstep)&& (is_stp_val.equalsIgnoreCase("Y")))
				{
					iform.setStyle("internalExposureDetails", "disable", "false");
				}
			}
			
			if(("operations").equalsIgnoreCase(Workstep)){
				iform.setStyle("UID_Details", "disable", "false");
			//	iform.setStyle("UID_Details_Grid", "disable", "true");
				iform.setStyle("UID_Remarks_grid", "disable", "false");
				iform.setStyle("AECB_rpt", "disable", "false");
				iform.setStyle("Generate_RiskScore", "visible", "false");
				iform.setStyle("template_generate_kyc", "visible", "false");
				iform.setStyle("internalExposureDetails", "disable", "false");//vinayak change jira 3727
				
				//14-April-2026
				iform.setStyle("Country_of_birth", "disable", "false");
							
				//vinayak ado-8521 chnages starts
				String PEP_modified = (String) iform.getValue("PEP");
				DigitalAO.mLogger.debug("PEP :  formload " + PEP_modified);
				if (PEP_modified.trim().equalsIgnoreCase("YES") || PEP_modified.trim().equalsIgnoreCase("Y")) 
				{
					iform.setStyle("SOW_Inheritance_ibps", "disable", "false");
					iform.setStyle("SOW_Investments_ibps", "disable", "false");
					iform.setStyle("SOW_Insurance_ibps", "disable", "false");
					iform.setStyle("SOW_RealEstate_ibps", "disable", "false");
					iform.setStyle("SOW_OtherImmovable_Asset_ibps", "disable", "false");
					iform.setStyle("SOW_GovernmentEmployment_ibps", "disable", "false");
					iform.setStyle("SOW_Other_Income_ibps", "disable", "false");
					iform.setStyle("SOW_Other_Income_Value_ibps", "disable", "false");
					//iform.setStyle("SOW_Total_Income_ibps", "disable", "false");
				}
				//ends
				
				// added for name edit changes -- 07.02.2023
				String Name_modify = (String) iform.getValue("Name_modify");
				if((Name_modify.equalsIgnoreCase("Y")))
				{
					iform.setStyle("Given_Name", "disable", "false");
					iform.setStyle("Middle_Name", "disable", "false");
					iform.setStyle("Surname", "disable", "false");
					iform.setStyle("Generate_RiskScore", "visible", "true");
					iform.setStyle("template_generate_kyc", "visible", "true");
					iform.setStyle("Generate_RiskScore", "disable", "false");
					iform.setStyle("Generate_firco_temp", "disable", "false");
					iform.setStyle("template_generate_kyc", "disable", "false");
				}
				if("Y".equalsIgnoreCase((String) iform.getValue("Dedupe_Match_found")))
				{
					iform.setStyle("CIF", "disable", "false");
				}
			}
			
			if(("Ops_Account_Closure_Maker").equalsIgnoreCase(Workstep))
			{
				iform.setStyle("Card_closed", "visible", "true");
				iform.setStyle("Card_closed", "disable", "false");
				iform.setStyle("ChequeBk_destroy", "visible", "true");
				iform.setStyle("ChequeBk_destroy", "disable", "false");
			}
			else if(("Ops_Account_Closure_Checker").equalsIgnoreCase(Workstep)){
				
				iform.setStyle("Card_closed", "visible", "true");
				iform.setStyle("Card_closed", "disable", "true");
				iform.setStyle("ChequeBk_destroy", "visible", "true");
				iform.setStyle("ChequeBk_destroy", "disable", "true");
			}
			else{
				iform.setStyle("Card_closed", "visible", "false");
				iform.setStyle("ChequeBk_destroy", "visible", "false");
			}
			DigitalAO.mLogger.debug("Section Disable :  Form load : after Section Disable");
		}
		
		else if("purpose_description".equalsIgnoreCase(controlName))
		{
			String description_val="";
			String product_category=(String) iform.getValue("Product_Category");
			DigitalAO.mLogger.debug("product_category "+product_category);
			String purpose_account=(String) iform.getValue("Purpose_of_account");
			DigitalAO.mLogger.debug("purpose_account "+purpose_account);
			//fix vinayak 10-07-24
			String purpose_account_sub="";
			if(purpose_account.length()>5)				
			 purpose_account_sub = purpose_account.substring(0,5);
			//end
			DigitalAO.mLogger.debug("purpose_account_sub "+purpose_account_sub);
			
			if(purpose_account_sub.equalsIgnoreCase("Other")){
				description_val=purpose_account;
				DigitalAO.mLogger.debug("description_val Others: "+description_val);
				
				iform.setStyle("Purpose_of_account_description", "disable", "false");
				setControlValue("Purpose_of_account_description",description_val, iform);
				iform.setStyle("Purpose_of_account_description", "disable", "true");
				DigitalAO.mLogger.debug("Value Set");
			}
			
			else if("C".equalsIgnoreCase(product_category)||"Conventional".equalsIgnoreCase(product_category))
			{
				List<List<String>> description= iform.getDataFromDB("select Desc_Conventional from NG_MASTER_DAO_PURPOSE_OF_ACCOUNT with (nolock) where Code_Common='"+purpose_account+"'");
				DigitalAO.mLogger.debug("description: "+description);
				if (!description.isEmpty()) {
					DigitalAO.mLogger.debug("Inside: ");
					description_val = description.get(0).get(0);
					DigitalAO.mLogger.debug("description: " + description_val);
					
					iform.setStyle("Purpose_of_account_description", "disable", "false");
					setControlValue("Purpose_of_account_description",description_val, iform);
					iform.setStyle("Purpose_of_account_description", "disable", "true");
					DigitalAO.mLogger.debug("Value Set");
					
				} else {
					DigitalAO.mLogger.debug("description is empty!!");
				}
				DigitalAO.mLogger.debug("description_val"+description_val);
			}
			else if("I".equalsIgnoreCase(product_category)||"Islamic".equalsIgnoreCase(product_category))
			{
				List<List<String>> description= iform.getDataFromDB("select Desc_Islamic from NG_MASTER_DAO_PURPOSE_OF_ACCOUNT with (nolock) where Code_Common='"+purpose_account+"'");
				DigitalAO.mLogger.debug("description: "+description);
				if (!description.isEmpty()) {
					DigitalAO.mLogger.debug("Inside: ");
					description_val = description.get(0).get(0);
					DigitalAO.mLogger.debug("description: " + description_val);
					
					iform.setStyle("Purpose_of_account_description", "disable", "false");
					setControlValue("Purpose_of_account_description",description_val, iform);
					iform.setStyle("Purpose_of_account_description", "disable", "true");
					DigitalAO.mLogger.debug("Value Set");
					
				} else {
					DigitalAO.mLogger.debug("description is empty!!");
				}
					
				DigitalAO.mLogger.debug("description_val"+description_val);
			}
		}
		
		else if("section_onLoad_Readmode".equalsIgnoreCase(controlName)){
			
			DigitalAO.mLogger.debug("Section Disable :  Form load : controlName: "+controlName);
			iform.setStyle("Customer_Information", "disable", "true");
			iform.setStyle("DigitalAO_EmpDetails", "disable", "true");
			iform.setStyle("DigitalAO_CompDetails", "disable", "true");
			iform.setStyle("Address_Details", "disable", "true");
			iform.setStyle("Income_Detail", "disable", "true");
			iform.setStyle("Contact_Details", "disable", "true");
			iform.setStyle("FATCA_CRS_Details", "disable", "true");
			iform.setStyle("System_Checks", "disable", "true");
			iform.setStyle("Account_Details", "disable", "true");
			iform.setStyle("UID_Details", "disable", "true");
			iform.setStyle("DigitalAO_BackgroundInfo", "disable", "true");
			iform.setStyle("Additional_Documents_Required", "disable", "true");
			iform.setStyle("NG_DAO_GR_DECISION_HISTORY", "disable", "true");
			iform.setStyle("sheet1", "disable", "true");
			iform.setStyle("rejectReason", "disable", "true");
			DigitalAO.mLogger.debug("Section Disable :  Form load : R mode: ");
			
		}
		
		else if ("company_details_popup_load".equalsIgnoreCase(controlName)){
			 //business details grid validation
			if (Workstep.equalsIgnoreCase("operations")){
			DigitalAO.mLogger.debug("company_details_popup_load :  Form load : before Disable");
			iform.setStyle("companyName", "disable", "true");
		    iform.setStyle("countryOfIncorporation", "disable", "true");
		    iform.setStyle("percentageShareholding", "disable", "true");
			iform.setStyle("annual_turnover", "disable", "true");
			iform.setStyle("annual_profit", "disable", "true");
		    iform.setStyle("tradeLicense", "disable", "true");
			iform.setStyle("Year_Of_Incorporation", "disable", "true");
		 // iform.setStyle("Country_List", "disable", "true"); hritik
			DigitalAO.mLogger.debug("company_details_popup_load :  Form load : after  Disable");
			}
		}
		
		else if ("cust_info_frame".equalsIgnoreCase(controlName)) {
			String highRisk = (String) iform.getValue("High_risk");
			if (Workstep.equalsIgnoreCase("compliance")) 
			{
				DigitalAO.mLogger.debug("High_risk :  Form loand : compliance");

				iform.setStyle("DigitalAO_BackgroundInfo", "visible", "true");
				iform.setStyle("background_information", "visible", "true");
				iform.setStyle("template_generate", "visible", "true");
				iform.setStyle("template_generate", "disable", "false");

				if (highRisk.equalsIgnoreCase("Y") || highRisk.equalsIgnoreCase("Yes")) {
					iform.setStyle("DigitalAO_BackgroundInfo", "disable", "true"); // hritik 29.7.22 as discussed W ST
					iform.setStyle("background_information", "disable", "true");// hritik 29.7.22 as discussed W ST
					iform.setStyle("template_generate", "visible", "true");
					iform.setStyle("template_generate", "disable", "false");
				} else {
					iform.setStyle("DigitalAO_BackgroundInfo", "disable", "true");
					iform.setStyle("background_information", "disable", "true");
					iform.setStyle("template_generate", "disable", "false");
				}
			}
			else 
			{
				iform.setStyle("DigitalAO_BackgroundInfo", "visible", "false"); // hritik 29.7.22 as discussed W ST
				iform.setStyle("background_information", "visible", "false");
				iform.setStyle("template_generate", "visible", "false");
				iform.setStyle("template_generate", "disable", "true");
			}
			
			String decision = (String) iform.getValue("Decision");
			if(decision.equalsIgnoreCase("Approve"))
			{
				iform.setStyle("Remarks_dec", "disable", "false");
				iform.setStyle("Remarks_dec", "mandatory", "false");
				iform.setStyle("rejectReason", "disable", "true");
				iform.setStyle("rejectReason", "mandatory", "false");
			}
			else if(decision.equalsIgnoreCase("Reject")){
				DigitalAO.mLogger.debug("Decision :  RejectReason on change" + decision);
				iform.setStyle("Remarks_dec", "disable", "false");
				iform.setStyle("Remarks_dec", "mandatory", "false");
				iform.setStyle("rejectReason", "disable", "false");
				iform.setStyle("rejectReason", "mandatory", "true");
			}
			else 
			{
				iform.setStyle("Remarks_dec", "disable", "false");
				iform.setStyle("Remarks_dec", "mandatory", "false");
				iform.setStyle("rejectReason", "disable", "true");
				iform.setStyle("rejectReason", "mandatory", "false");
			}
			
			
			// Additional Documents Required
			if (Workstep.equalsIgnoreCase("operations") 
				|| Workstep.equalsIgnoreCase("compliance") 
				|| Workstep.equalsIgnoreCase("compliance_wc") 
				|| Workstep.equalsIgnoreCase("Additional_cust_details")
				|| Workstep.equalsIgnoreCase("wm_control"))
				//|| Workstep.equalsIgnoreCase("sign_upload_checker")) // For STP journey if docs uploaded wrong. New requirement.
			// commented for non etb release
			{
				iform.setStyle("Additional_Documents_Required", "disable", "false");
				iform.setStyle("AddnalDocs", "disable", "false");
			}
			// gross month salary CIF_Update 
			if (Workstep.equalsIgnoreCase("sign_upload_checker"))
			{
				iform.setStyle("CIF_Update", "visible", "true");
				iform.setStyle("sign_upload", "visible", "true");
				iform.setStyle("gross_monthly_salary_income", "disable", "false");
				iform.setStyle("CIF_Update", "disable", "false");
				iform.setStyle("sign_upload", "disable", "false");
				iform.setStyle("Additional_Documents_Required", "disable", "false");
				iform.setStyle("AddnalDocs", "disable", "false");
			}
			else
			{
				iform.setStyle("gross_monthly_salary_income", "disable", "true");
				iform.setStyle("CIF_Update", "disable", "true");
				iform.setStyle("CIF_Update", "visible", "false");
				iform.setStyle("sign_upload", "visible", "false");
			}
			
			if (Workstep.equalsIgnoreCase("operations")) 
			{
				// Risk Score Button
				iform.setStyle("Risk_score_trigger", "disable", "false");
				iform.setStyle("Country_of_birth", "disable", "false");
				
				//vinayak added jira 3913 rakempowered changes
				String Payroll_account = (String) iform.getValue("Payroll_account");
				DigitalAO.mLogger.debug("Payroll_account " + Payroll_account);
				
				//pdocal-378 changes vinayak 04-07-24
				/*
				if("RAKEmpower".equalsIgnoreCase(Payroll_account)){					
					iform.setStyle("Risk_score_trigger", "disable", "true");
				}*/
				//end
				
				//POA-996 - Hritik 7.7.22 - start
				iform.setStyle("country_of_residence", "disable", "false");
				iform.setStyle("Nationality", "disable", "false");
				
				
			    // PEP
				iform.setStyle("PEP", "disable", "false");
				String Fatca_PEP = (String) iform.getValue("PEP");
				DigitalAO.mLogger.debug("PEP :  formload " + Fatca_PEP);
				if (Fatca_PEP.trim().equalsIgnoreCase("YES") || Fatca_PEP.trim().equalsIgnoreCase("Y")) {
					iform.setStyle("PEP_Category", "visible", "true");
					iform.setStyle("Previous_Designation", "visible", "true");
					iform.setStyle("Relation_Detail_w_PEP", "visible", "true");
					iform.setStyle("name_of_pep", "visible", "true");
					iform.setStyle("country_pep_hold_status", "visible", "true");
					iform.setStyle("Emirate_pep_hold_status", "visible", "true");
				} else {
					iform.setStyle("PEP_Category", "visible", "false");
					iform.setStyle("Previous_Designation", "visible", "false");
					iform.setStyle("Relation_Detail_w_PEP", "visible", "false");
					iform.setStyle("name_of_pep", "visible", "false");
					iform.setStyle("country_pep_hold_status", "visible", "false");
					iform.setStyle("Emirate_pep_hold_status", "visible", "false");
				}
			} 
			else
			{
				iform.setStyle("Fatca_PEP", "disable", "true");
				iform.setStyle("PEP_Category", "visible", "false");
				iform.setStyle("Previous_Designation", "visible", "false");
				iform.setStyle("Relation_Detail_w_PEP", "visible", "false");
				iform.setStyle("name_of_pep", "visible", "false");
				iform.setStyle("country_pep_hold_status", "visible", "false");
				iform.setStyle("Emirate_pep_hold_status", "visible", "false");
			}
			return strReturn = "success executed cust_info_frame";

		}

		else if ("employment_frame".equalsIgnoreCase(controlName)) {
			
			DigitalAO.mLogger.debug("DigitalAO_EmpDetails: Disable on load");
			iform.setStyle("DigitalAO_EmpDetails", "visible", "false");
			iform.setStyle("DigitalAO_CompDetails", "visible", "false");
			iform.setStyle("company_detail", "visible", "false");

			String employement_type = (String) iform.getValue("employement_type");
			DigitalAO.mLogger.debug("DigitalAO_EmpDetails: employement_type: formload" + employement_type);
			if (employement_type.trim().equalsIgnoreCase("Salaried")) {
				iform.setStyle("DigitalAO_EmpDetails", "visible", "true");
				iform.setStyle("DigitalAO_EmpDetails", "disable", "true");
				if (Workstep.equalsIgnoreCase("operations"))
				{
					//iform.setStyle("Company_employer_name", "disable", "false"); chngaes vinayak changes jira 3310
					//industry sub industry changes 23 march 2026 for salaried-uddeshya
					DigitalAO.mLogger.debug("DigitalAO_EmpDetails:industry");
					iform.setStyle("industry_segment", "disable", "false");
					iform.setStyle("industry_subsegment", "disable", "false");
					DigitalAO.mLogger.debug("DigitalAO_EmpDetails:subindustry");
					iform.setStyle("is_modify_employer", "disable", "false");
					iform.setValue("is_EmployerAdd_req", "");//set value of flag as null on load for employer chnage
					String is_modify_employer_val = (String) iform.getValue("is_modify_employer");
					String is_notPicklistEmployer_val = (String) iform.getValue("is_notPicklistEmployer");
					if("true".equalsIgnoreCase(is_modify_employer_val))
					{
					iform.setStyle("picklist_employer_name", "disable", "false");
					iform.setStyle("is_notPicklistEmployer", "visible", "true");
					iform.setStyle("is_notPicklistEmployer", "disable", "false");					
					iform.setStyle("CustomerInput_other_employerName", "disable", "true");
					}
					if("true".equalsIgnoreCase(is_notPicklistEmployer_val))
					{
						iform.setStyle("CustomerInput_other_employerName", "visible", "true");
						iform.setStyle("CustomerInput_other_employerName", "disable", "false");
						iform.setStyle("picklist_employer_name", "disable", "true");						
					}

				}
			} 
			else if (employement_type.trim().equalsIgnoreCase("Self Employed")) {
				if (Workstep.equalsIgnoreCase("operations"))
				{
					iform.setStyle("DigitalAO_CompDetails", "visible", "true");
					iform.setStyle("company_detail", "visible", "true");
					iform.setStyle("DigitalAO_CompDetails", "disable", "false");
					iform.setStyle("company_detail", "disable", "false");
				}
				else{
					iform.setStyle("DigitalAO_CompDetails", "visible", "true");
					iform.setStyle("company_detail", "visible", "true");
					iform.setStyle("DigitalAO_CompDetails", "disable", "true");
					iform.setStyle("company_detail", "disable", "true");
				}
			} 
			else {
				iform.setStyle("DigitalAO_EmpDetails", "visible", "false");
				iform.setStyle("DigitalAO_CompDetails", "visible", "false");
				iform.setStyle("company_detail", "visible", "false");
			}
			return strReturn = "Success disable DigitalAO_EmpDetails";
		}
		
		else if("populateCIF".equals(controlName))
		{
			try
			{
				List CIF = iform.getDataFromDB("select CIFID from NG_DAO_GR_DEDUPE_DETAILS with (nolock) where Wi_Name='"
				+ getWorkitemName(iform) + "'");
				DigitalAO.mLogger.debug(" inside Pop CIF drop down : " + CIF);
				String value = "";
				
				for (int i = 0; i < CIF.size(); i++)
				{
					List<String> arr1 = (List) CIF.get(i);
					value = arr1.get(0);
					iform.addItemInCombo("CIF", value, value);
				}
				iform.addItemInCombo("CIF", "NTB", "NTB");
				strReturn = "CIF Loaded";
			}
			catch(Exception e){
				
				DigitalAO.mLogger.debug("WINAME : " + getWorkitemName(iform) + ", WSNAME: " + iform.getActivityName()
						+ ", Exception in Pop CIF load " + e.getMessage());
			}
			
		}
		

		else if ("DecisionDropDown".equals(controlName))
		{
			try {
				
				List lstDecisions = iform
						.getDataFromDB("SELECT decision FROM NG_DAO_MASTER_Decision WITH(NOLOCK) WHERE WorkstepName='"
								+ iform.getActivityName() + "' and Is_Active='Y' ORDER BY decision ASC");
				DigitalAO.mLogger.debug(" inside Decision drop down WS: " + lstDecisions);
				String value = "";
				iform.clearCombo("Decision");
				for (int i = 0; i < lstDecisions.size(); i++) {
					List<String> arr1 = (List) lstDecisions.get(i);
					value = arr1.get(0);
					iform.addItemInCombo("Decision", value, value);
					strReturn = "Decision Loaded";
				}
				
				/*if(Workstep=="Additional details needed" && iform.getValue("is_stp")=="Y")
                {
					iform.removeItemFromCombo("Decision",1);
                    iform.removeItemFromCombo("Decision",2);
                    iform.removeItemFromCombo("Decision",3);
                    iform.removeItemFromCombo("Decision",4);
                    iform.removeItemFromCombo("Decision",5);
                    iform.removeItemFromCombo("Decision",6);
                }*/
				if("sign_upload_checker".equalsIgnoreCase(Workstep) && "Manual_Archive".equalsIgnoreCase((String) iform.getValue("prevws")))
				{
					DigitalAO.mLogger.debug(" inside Decision drop down remove item from combo "+ iform.getValue("prevws"));
					iform.removeItemFromCombo("Decision", 4);
					iform.removeItemFromCombo("Decision", 3);
					iform.removeItemFromCombo("Decision", 1);
					iform.addItemInCombo("Decision", "Send to Account Closure Maker", "Send to Account Closure Maker");//ado -5439
				} // POA-2569
				
				if ("Additional_cust_details".equalsIgnoreCase(Workstep) && "sign_upload_checker".equalsIgnoreCase((String) iform.getValue("prevws"))) {
					DigitalAO.mLogger.debug(" inside Decision drop down remove item from combo "+ iform.getValue("prevws"));
					iform.removeItemFromCombo("Decision", 5);
					iform.removeItemFromCombo("Decision", 4);
					iform.removeItemFromCombo("Decision", 3);
					iform.removeItemFromCombo("Decision", 2);
					iform.removeItemFromCombo("Decision", 1);
					iform.addItemInCombo("Decision", "Send to Account Closure", "Send to Account Closure");//ado -5439
				//	iform.removeItemFromCombo("Decision", 6);
				}
				else
				{
					iform.removeItemFromCombo("Decision", 6);
				}
				
				String Name_modify = (String) iform.getValue("Name_modify");
				String Firco = (String) iform.getValue("firco_hit");
				String Risk = (String) iform.getValue("high_risk");
				String dedupe  = (String) iform.getValue("Dedupe_Match_found");
				
				if("operations".equalsIgnoreCase(Workstep) && "N".equalsIgnoreCase(Name_modify) 
					&& "N".equalsIgnoreCase(Firco) && "N".equalsIgnoreCase(Risk) && "Y".equalsIgnoreCase(dedupe) )
				{
					DigitalAO.mLogger.debug("Inside Ops condition "+ Workstep);
					iform.removeItemFromCombo("Decision", 3);
					iform.removeItemFromCombo("Decision", 1);
					strReturn = "Decision Loaded at Ops for Dedupe Y & name modify Firco Risk N";
				}
				
				if("operations".equalsIgnoreCase(Workstep) && "Y".equalsIgnoreCase(Name_modify) 
					&& "N".equalsIgnoreCase(Firco) && "N".equalsIgnoreCase(Risk))
				{
					DigitalAO.mLogger.debug("Inside Ops condition "+ Workstep);
					iform.removeItemFromCombo("Decision", 3);
					strReturn = "Decision Loaded at Ops for name modify Y & Firco Risk N";
				}
				
				if("operations".equalsIgnoreCase(Workstep) && "Y".equalsIgnoreCase(Name_modify) 
					&& "N".equalsIgnoreCase(Firco) && "Y".equalsIgnoreCase(Risk))
				{
					DigitalAO.mLogger.debug("Inside Ops condition "+ Workstep);
					iform.removeItemFromCombo("Decision", 3);
					strReturn = "Decision Loaded at Ops for name modify Y & Firco N Risk Y";
				}
				if("operations".equalsIgnoreCase(Workstep) && "Y".equalsIgnoreCase(dedupe) 
						&& "Y".equalsIgnoreCase(Risk))
					{
						DigitalAO.mLogger.debug("Inside Ops condition "+ Workstep);
						iform.removeItemFromCombo("Decision", 3);
						strReturn = "Decision Loaded at Ops for Dedupe Y and  Risk Y";
					}
					String Q_segment=(String) iform.getValue("q_customer_segment");
					String Q_source=(String) iform.getValue("q_source_unit");
					
					DigitalAO.mLogger.debug("Q_segment "+ iform.getValue("q_customer_segment"));
					DigitalAO.mLogger.debug("Q_source "+ iform.getValue("q_source_unit"));
				
				if ("Additional_cust_details".equalsIgnoreCase(Workstep)
					&&(("PAM".equalsIgnoreCase((String) iform.getValue("q_customer_segment")) && "RM".equalsIgnoreCase((String) iform.getValue("q_source_unit"))) 
					||("PAM".equalsIgnoreCase((String) iform.getValue("q_customer_segment")) && "VRM".equalsIgnoreCase((String) iform.getValue("q_source_unit")))))
					{
						DigitalAO.mLogger.debug("PAM - RM/VRM ");
						iform.addItemInCombo("Decision", "send to WM Control", "send to wm_control");
					}
				//ado-8849 acceptance criteria 7
				if ("Additional_cust_details".equalsIgnoreCase(Workstep)&& "wm_control".equalsIgnoreCase((String) iform.getValue("prevws")))
				{
					DigitalAO.mLogger.debug("inside wm_control prevws");
					
					String Query = "select wi_name from NG_DAO_GR_DECISION_HISTORY with(nolock) where wi_name='"
							+ getWorkitemName(iform) + "' and workstep in('sign_upload_checker')";
					
					DigitalAO.mLogger.debug("Query :" + Query);
					List<List<String>> result2 = iform.getDataFromDB(Query);
					if (!result2.isEmpty()) {
						DigitalAO.mLogger.debug("inside wm_control where sign_upload_checker is in decision history");
						iform.addItemInCombo("Decision", "Send to Account Closure", "Send to Account Closure");

					}
				}
				//end
				
				// ado-8672
				if(("Ops_Account_Closure_Maker").equalsIgnoreCase(Workstep) && ("Hold_courier_update".equalsIgnoreCase((String) iform.getValue("prevws"))|| "Ops_Account_Closure_Checker".equalsIgnoreCase((String) iform.getValue("prevws"))||"Branch".equalsIgnoreCase((String) iform.getValue("prevws"))))
				{
					
					String Query = "select  is_redispatch_case,AWB_Number_old from NG_DAO_EXTTABLE with(nolock) where wi_name='"+getWorkitemName(iform)+"'";
					
					DigitalAO.mLogger.debug("Query :" + Query);
					List<List<String>> result2 = iform.getDataFromDB(Query);
					if (!result2.isEmpty()) {
						String is_redispatch_case = result2.get(0).get(0);
						String AWB_Number_old = result2.get(0).get(1);
						DigitalAO.mLogger.debug("inside decision at account closure maker"+is_redispatch_case);
						DigitalAO.mLogger.debug("inside AWB_Number_old at account closure maker"+AWB_Number_old);
						if(!"Yes".equalsIgnoreCase(is_redispatch_case)){
							if("".equalsIgnoreCase(AWB_Number_old)){
								DigitalAO.mLogger.debug("inside Ops_Account_Closure_Maker currws");
								iform.addItemInCombo("Decision", "Redispatch", "Redispatch");
							}
							
						}
					}
					
				}
				if("Ops_Account_Closure_Checker".equalsIgnoreCase(Workstep) && "Ops_Account_Closure_Maker".equalsIgnoreCase((String) iform.getValue("prevws")))
				{
					DigitalAO.mLogger.debug("inside wm_control prevws");
					
					String Query = "select top 1 Decision from NG_DAO_GR_DECISION_HISTORY with(nolock) where wi_name='"+getWorkitemName(iform)+"' and workstep in('Ops_Account_Closure_Maker') order by decision_date_time desc";
					
					DigitalAO.mLogger.debug("Query :" + Query);
					List<List<String>> result2 = iform.getDataFromDB(Query);
					if (!result2.isEmpty()) {
						String decision = result2.get(0).get(0);
						DigitalAO.mLogger.debug("inside decision at account closure maker"+decision);
						if("Redispatch".equalsIgnoreCase(decision)){
							iform.addItemInCombo("Decision", "Approved for Redispatch", "Approved for Redispatch");
						}
					}
					
				}
				//end
				
				
			} catch (Exception e) 
			{
				DigitalAO.mLogger.debug("WINAME : " + getWorkitemName(iform) + ", " +
				"WSNAME: " + iform.getActivityName()
				+ ", Exception in Decision drop down load " + e.getMessage());
			}
			return strReturn ="Success DecisionDropDown";
		}
		else if ("template_generate_kyc".equalsIgnoreCase(controlName)) {
			
			String pdfName = "DAO Template KYC";
			try{
				DigitalAO.mLogger.debug("template_generate_kyc "+ new DAOTemplate().generate_kyc_temp(iform, getWorkitemName(iform), pdfName));
				return new DAOTemplate().generate_kyc_temp(iform, getWorkitemName(iform), pdfName);
			}
			catch(Exception e){
				DigitalAO.mLogger.debug("template_generate_kyc :"+e.getMessage());
			}
		}
		else if ("template_generate_risk_sheet".equalsIgnoreCase(controlName)) {
			
			try{
				DigitalAO.mLogger.debug("template_generate_risk_sheet "+genrate_risksheet(iform));
				return genrate_risksheet(iform);
			}
			catch(Exception e){
				DigitalAO.mLogger.debug("template_generate_risk_sheet :"+e.getMessage());
			}
		}
		
		else if ("template_generate_firco".equalsIgnoreCase(controlName)) {
			String pdfName = "DAO Firco Template";
			try{
				DigitalAO.mLogger.debug("generate_firco_temp "+new DAOTemplate().generate_firco_temp(iform, getWorkitemName(iform), pdfName));
				return new DAOTemplate().generate_firco_temp(iform, getWorkitemName(iform), pdfName);
				}
			catch(Exception e){
				DigitalAO.mLogger.debug("generate_firco_temp :"+e.getMessage());
			}
		}
		
		else if ("template_generate_dedupe".equalsIgnoreCase(controlName)) {
			String pdfName = "DEDUPE";   // vinayak kyc archival changes
			try{
				DigitalAO.mLogger.debug("generate_dedupe_temp "+new DAOTemplate().generate_dedupe_temp(iform, getWorkitemName(iform), pdfName));
				return new DAOTemplate().generate_dedupe_temp(iform, getWorkitemName(iform), pdfName);
				}
			catch(Exception e){
				DigitalAO.mLogger.debug("generate_dedupe_temp :"+e.getMessage());
			}
		}
		
		//pdocal-14 vinayak 		
		else if ("Money_send_and_received_country".equalsIgnoreCase(controlName)) {
			
			String Money_send_and_received_Countries=(String) iform.getValue("Money_send_and_received_Countries");
			DigitalAO.mLogger.debug("Money_send_and_received_Countries :"+Money_send_and_received_Countries);
			String[] array=Money_send_and_received_Countries.split(",");
			String CountryCode="";
			JSONArray arr=new JSONArray();
			JSONArray jsonArray=new JSONArray();
			JSONObject obj=new JSONObject();
			String money_country_string="";
			for(int i=0;i<array.length;i++){
				CountryCode=array[i];
				String country_desc="";
				String getMaterQuery=" select CD_DESC from NG_MASTER_DAO_COUNTRY with(nolock) where  CM_CODE='"+CountryCode+"'";
				DigitalAO.mLogger.debug("getMaterQuery :"+getMaterQuery);
				List<List<String>> result2 = iform.getDataFromDB(getMaterQuery);
				if (!result2.isEmpty()) 
				{
					country_desc = result2.get(0).get(0);	
					String lable="Country "+(i+1);
					obj.put(lable,country_desc);
					money_country_string=money_country_string+CountryCode+",";
				}
			}
			jsonArray.add(obj);
			iform.addDataToGrid("Gr_Money_Sent_And_Received_Country", jsonArray);
			DigitalAO.mLogger.debug("jsonArray : "+jsonArray);
			
			if(!(money_country_string.equalsIgnoreCase("")||money_country_string.equalsIgnoreCase(null)))
			{
				money_country_string=money_country_string.substring(0, money_country_string.length()-1);
			}
			DigitalAO.mLogger.debug("money_country_List_string :"+money_country_string);
			 iform.setValue("Money_send_and_received_Countries_final_IBPS",money_country_string);
		
		}
				
		else if ("Money_send_and_received_country_change".equalsIgnoreCase(controlName)) {			
			
			String Money_send_and_received_Countries=(String) iform.getValue("Money_send_and_received_Countries");
			DigitalAO.mLogger.debug("Money_send_and_received_Countries :"+Money_send_and_received_Countries);
			String[] array_wiCreate=Money_send_and_received_Countries.split(",");
			
			String moneySent_Country1=((String) iform.getValue("moneySent_Country1")).trim();
			String moneySent_Country2=((String) iform.getValue("moneySent_Country2")).trim();
			String moneySent_Country3=((String) iform.getValue("moneySent_Country3")).trim();
			String moneySent_Country4=((String) iform.getValue("moneySent_Country4")).trim();
			String moneySent_Country5=((String) iform.getValue("moneySent_Country5")).trim();
			DigitalAO.mLogger.debug("moneySent_Country1 :"+moneySent_Country1);
			DigitalAO.mLogger.debug("moneySent_Country2 :"+moneySent_Country2);
			DigitalAO.mLogger.debug("moneySent_Country3 :"+moneySent_Country3);
			DigitalAO.mLogger.debug("moneySent_Country4 :"+moneySent_Country4);
			DigitalAO.mLogger.debug("moneySent_Country5 :"+moneySent_Country5);
			
			List<String> moneySent_List_form=new ArrayList<String>();
			moneySent_List_form.add(moneySent_Country1);
			moneySent_List_form.add(moneySent_Country2);
			moneySent_List_form.add(moneySent_Country3);
			moneySent_List_form.add(moneySent_Country4);
			moneySent_List_form.add(moneySent_Country5);
			
			
			String[] array_form=new String[5];
			String money_country_string="";
			for (int i = 0; i < moneySent_List_form.size(); i++) {

				String getDataQuery = "select CM_CODE from NG_MASTER_DAO_COUNTRY with(nolock) where CD_DESC='"+moneySent_List_form.get(i)+"'";
						
				DigitalAO.mLogger.debug("getDataQuery :" + getDataQuery);

				List<List<String>> result1 = iform.getDataFromDB(getDataQuery);
				DigitalAO.mLogger.debug("result1.size() :" + result1.size());
				if (!result1.isEmpty()) {
					for (int j = 0; j < result1.size(); j++) {
						array_form[i] = result1.get(j).get(0);
						money_country_string=money_country_string+result1.get(j).get(0)+",";
						DigitalAO.mLogger.debug(" :index :" + i + "   :array_form value at index:" + array_form[i]);
					}
				}

			}
			
			if(!(money_country_string.equalsIgnoreCase("")||money_country_string.equalsIgnoreCase(null)))
			{
				money_country_string=money_country_string.substring(0, money_country_string.length()-1);
			}
			DigitalAO.mLogger.debug("money_country_List_string :"+money_country_string);
			 iform.setValue("Money_send_and_received_Countries_final_IBPS",money_country_string);			
			
			
			DigitalAO.mLogger.debug("After data insert into array :");
			DigitalAO.mLogger.debug("array_wiCreate Length:"+array_wiCreate.length);
			DigitalAO.mLogger.debug("array_form Length:"+array_form.length);
			
			for (int i = 0; i < 5; i++) {
				int match = 0;
				
				DigitalAO.mLogger.debug("array_form value at index "+i+" is : "+array_form[i]);
				if (!(array_form[i]==null) && !("".equalsIgnoreCase(array_form[i]))) {
					for (int j = 0; j < array_wiCreate.length; j++) {						
						DigitalAO.mLogger.debug("array_wiCreation :"+array_wiCreate[j]);
						if (array_wiCreate[j].equalsIgnoreCase(array_form[i])) {
							match = 1;
						}
					}
					DigitalAO.mLogger.debug("match :"+match);
					if (match == 0) {
						DigitalAO.mLogger.debug(array_form[i]);
						iform.setValue("risk_score", "");
						break;
					}
				}
			}			
		}
		
		//end pdocal-14 vinayak		
		
		//pdocal-11 vinayak
		
		else if ("Professional_history".equalsIgnoreCase(controlName)) {

			String Past_employer_1 = (String) iform.getValue("Past_employer_1");
			DigitalAO.mLogger.debug("Past_employer_1 :" + Past_employer_1);
			
			String Past_employer_2 = (String) iform.getValue("Past_employer_2");
			DigitalAO.mLogger.debug("Past_employer_2 :" + Past_employer_2);
			
			String Past_employer_3 = (String) iform.getValue("Past_employer_3");
			DigitalAO.mLogger.debug("Past_employer_3 :" + Past_employer_3);
			
			JSONArray jsonArray = new JSONArray();
			JSONObject obj = new JSONObject();
			
			if (!(Past_employer_1==null) && !("".equalsIgnoreCase(Past_employer_1))){
				String[] array1 = Past_employer_1.split(",");
				if(array1.length==4){
					obj.put("Company / Employer Name", array1[0]);
					obj.put("Job title/ Line of business",  array1[1]);
					obj.put("Country", array1[2]);
					obj.put("Start with / Date of Incorporation", array1[3]);
					jsonArray.add(obj);
				}
			}
			JSONObject obj2 = new JSONObject();
			if (!(Past_employer_2==null) && !("".equalsIgnoreCase(Past_employer_2))){
				String[] array2 = Past_employer_2.split(",");
				if(array2.length==4){
					obj2.put("Company / Employer Name", array2[0]);
					obj2.put("Job title/ Line of business",  array2[1]);
					obj2.put("Country", array2[2]);
					obj2.put("Start with / Date of Incorporation", array2[3]);
					jsonArray.add(obj2);
				}
			}
			JSONObject obj3 = new JSONObject();
			if (!(Past_employer_3==null) && !("".equalsIgnoreCase(Past_employer_3))){
				String[] array3 = Past_employer_3.split(",");
				if(array3.length==4){
					obj3.put("Company / Employer Name", array3[0]);
					obj3.put("Job title/ Line of business",  array3[1]);
					obj3.put("Country", array3[2]);
					obj3.put("Start with / Date of Incorporation", array3[3]);
					jsonArray.add(obj3);
				}
			}		
			
			iform.addDataToGrid("Q_gr_professional_history", jsonArray);
			DigitalAO.mLogger.debug("jsonArray : " + jsonArray);
		}
		// end pdocal-11 vinayak
		

		// To load all the exceptions automatically.
		/*
		 * else if (controlName.equalsIgnoreCase("Exception")) {
		 * iform.getDataFromGrid("Q_USR_0_IRBL_EXCEPTION_HISTORY").clear();
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", after clear from Q_USR_0_IRBL_EXCEPTION_HISTORY "
		 * +iform.getDataFromGrid("Q_USR_0_IRBL_EXCEPTION_HISTORY").size());
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", Data Coming in Exceptions is "+data); try { List<List<String>>
		 * lstException = iform .getDataFromDB(
		 * "SELECT ExceptionName,CanRaise,CanClear,CanView FROM USR_0_IRBL_EXCEPTION_MASTER WITH(NOLOCK) where ISACTIVE='Y' and WORKSTEP_NAME='"
		 * +Workstep+"'"); JSONArray jsonArray = new JSONArray(); String value =
		 * ""; for (int i = 0; i < lstException.size(); i++) { JSONObject obj =
		 * new JSONObject(); List<String> arr = (List) lstException.get(i);
		 * value = arr.get(0); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ",  value : "+value); obj.put("Exception", value); if
		 * ("".equals(strReturn)) { strReturn = strReturn + value + ":" +
		 * arr.get(1) + ":" + arr.get(2) + ":" + arr.get(3); } else { strReturn
		 * = strReturn + "~" + value + ":" + arr.get(1) + ":" + arr.get(2) + ":"
		 * + arr.get(3); } jsonArray.add(obj); } DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+", return for exception " +
		 * jsonArray.toJSONString()); // iform.addDataToGrid("table7",
		 * jsonArray); if(!("Rights".equals(data))) {
		 * iform.addDataToGrid("Q_USR_0_IRBL_EXCEPTION_HISTORY", jsonArray); } }
		 * catch (Exception e) { DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Exception in ExceptionHistory load " + e.getMessage()); } }
		 * //Raising Automatic
		 * exception************************************************************
		 * ******* else if("RaiseAutomaticException".equals(controlName)) { try
		 * { DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", Data Coming in RaiseAutomaticException is "+data); int tablecount
		 * = iform.getDataFromGrid("Q_USR_0_IRBL_EXCEPTION_HISTORY").size();
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+", tablecount "+tablecount); for
		 * (int i = 0; i< tablecount; i++) { String
		 * exceptioName=iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY"
		 * ,i, 1); if(exceptioName.equalsIgnoreCase(data)) { Calendar cal =
		 * Calendar.getInstance(); SimpleDateFormat sdf = new SimpleDateFormat(
		 * "yyyy-MM-dd HH:mm:ss"); String strDate = sdf.format(cal.getTime());
		 * String strRaisedCleared="Raised"; String strNewLine="";
		 * if("".equals(iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY"
		 * ,i, 4)) ||
		 * iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i, 4)==null)
		 * strNewLine=""; else strNewLine="\n";
		 * 
		 * 
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,0,"true");
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,2,iform.
		 * getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,
		 * 2)+strNewLine+iform.getActivityName());
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,3,iform.
		 * getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,
		 * 3)+strNewLine+"System");
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,4,iform.
		 * getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,
		 * 4)+strNewLine+strRaisedCleared);
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,5,iform.
		 * getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",i,
		 * 5)+strNewLine+strDate); strReturn=data; DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+
		 * ", Successfully Raised Automatic Exception for "+strReturn); } }
		 * 
		 * } catch (Exception e) { DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Exception in Raising Automatic Exception " + e.getMessage()); }
		 * //*******************************************************************
		 * ********** } //To set values when user manually make changes in
		 * Exception History Window. else
		 * if("raiseClearException".equals(controlName)) { try {
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+", Data for Exception is "
		 * +data); String strCheckUncheck=iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data), 0);
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+", Exception check uncheck is "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 0)); Calendar cal = Calendar.getInstance();
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		 * String strDate = sdf.format(cal.getTime()); String
		 * strRaisedCleared=""; String strNewLine="";
		 * if("".equals(iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY"
		 * ,Integer.parseInt(data), 4)) ||
		 * iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 4)==null) strNewLine=""; else strNewLine="\n";
		 * if("true".equals(strCheckUncheck)) strRaisedCleared="Raised"; else
		 * strRaisedCleared="Approved"; DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 2) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 2)+strNewLine+iform.getActivityName());
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),2,iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data),
		 * 2)+strNewLine+iform.getActivityName()); DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 3) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 3)+strNewLine+iform.getUserName());
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),3,iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data),
		 * 3)+strNewLine+iform.getUserName()); DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 4) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 4)+strNewLine+strRaisedCleared);
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),4,iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data),
		 * 4)+strNewLine+strRaisedCleared); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 5) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 5)+strNewLine+strDate);
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),5,iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data),
		 * 5)+strNewLine+strDate); strReturn = "Cleared"; } catch (Exception e)
		 * { DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", Exception in Service Request drop down load " + e.getMessage()); }
		 * } //To calculate aging in dsays automatically. else
		 * if("AgeingInDays".equals(controlName)) { try { List lstDecisions =
		 * iform .getDataFromDB("select dbo.GetOPSTAT_IRBL('"
		 * +getWorkitemName(iform)+"','"+iform.getActivityName()+
		 * "')  as OPSTAT where 1= 1"); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", lstDecisions : "+lstDecisions.toString());
		 * 
		 * //String Ageingvalue=lstDecisions.toString();
		 * 
		 * for(int i=0;i<lstDecisions.size();i++) { List<String>
		 * arr1=(List)lstDecisions.get(i); //Ageingvalue=arr1.get(0);
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+", arr1.get(0) : "+arr1.get(0));
		 * 
		 * strReturn=arr1.get(0); }
		 * 
		 * } catch (Exception e) { DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Exception in AgeingInDays " + e.getMessage()); } } //To load
		 * RM,SM, SOL_ID from RO automatically. else
		 * if("RO".equals(controlName)) { String ROField = (String)
		 * iform.getValue("RO"); DigitalAO.mLogger.debug("ROField -: "+ROField);
		 * try { List lstDecisions = iform .getDataFromDB(
		 * "SELECT RM,SOLID,SM FROM USR_0_IRBL_RMSMRO_Master WITH(NOLOCK) WHERE RO='"
		 * +ROField+"' AND ISACTIVE='Y' ORDER BY RO ASC");
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+", lstDecisions : "
		 * +lstDecisions.toString());
		 * 
		 * String value1=""; String value2=""; String value3="";
		 * iform.setValue("RM",""); iform.setValue("SOL_ID","");
		 * iform.setValue("SM","");
		 * 
		 * for(int i=0;i<lstDecisions.size();i++) { List<String>
		 * arr1=(List)lstDecisions.get(i); value1=arr1.get(0);
		 * value2=arr1.get(1); value3=arr1.get(2); iform.setValue("RM",value1);
		 * iform.setValue("SOL_ID",value2); iform.setValue("SM",value3);
		 * strReturn="RM SM RO SOL_ID Loaded"; } } catch (Exception e) {
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", Exception in RM,SM,SOLID load " + e.getMessage()); } } //To Fetch
		 * Signature details. else if("Signature".equals(controlName)) { try {
		 * DigitalAO.mLogger.debug("Inside Signature"); List lstDecisions =
		 * iform .getDataFromDB(
		 * "SELECT DISTINCT AcctId FROM USR_0_iRBL_InternalExpo_AcctDetails WITH(NOLOCK) WHERE Wi_Name = '"
		 * +getWorkitemName(iform)+"'"); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", lstDecisions : "+lstDecisions.toString()); for(int
		 * i=0;i<lstDecisions.size();i++) { List<String>
		 * arr1=(List)lstDecisions.get(i); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Account ID : "+arr1.get(0));
		 * 
		 * strReturn=strReturn+arr1.get(0)+"@";
		 * //strReturn=strReturn.substring(0,strReturn.length()-1);
		 * DigitalAO.mLogger.debug("strReturn---"+strReturn); }
		 * 
		 * } catch (Exception e) { DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Exception in Loading Signature !" + e.getMessage()); } } //Count
		 * for raising Nationality Exception else
		 * if("RestrictedValues".equals(controlName)) { int
		 * CRPartygridsize=iform.getDataFromGrid(
		 * "Q_USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS").size(); //int count=0;
		 * String value=""; String StrNationality=""; try { /*for(int
		 * i=0;i<CRPartygridsize;i++) { String Nationality =
		 * iform.getTableCellValue("Q_USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS",
		 * i,30); if(StrNationality.equals("")) StrNationality=Nationality; else
		 * StrNationality=StrNationality+"','"+Nationality; iRBL.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+", StrNationality : "+StrNationality);
		 * 
		 * }
		 * 
		 * String query =
		 * "select count(*) from USR_0_IRBL_CountryMaster with(nolock) where countryCode in("
		 * +
		 * " (select NATIONALITY from USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS with(nolock) where wi_name = '"
		 * +getWorkitemName(iform)+
		 * "' and NATIONALITY is not null and NATIONALITY != ''" + " UNION ALL"
		 * +
		 * " select ADDITIONALNATIONALITY from USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS with(nolock) where wi_name = '"
		 * +getWorkitemName(iform)+
		 * "' and ADDITIONALNATIONALITY is not null and ADDITIONALNATIONALITY != ''"
		 * + " UNION ALL" +
		 * " select ADDITIONALNATIONALITY2 from USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS with(nolock) where wi_name = '"
		 * +getWorkitemName(iform)+
		 * "' and ADDITIONALNATIONALITY2 is not null and ADDITIONALNATIONALITY2 != ''"
		 * + " UNION ALL" +
		 * " select ADDITIONALNATIONALITY3 from USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS with(nolock) where wi_name = '"
		 * +getWorkitemName(iform)+
		 * "' and ADDITIONALNATIONALITY3 is not null and ADDITIONALNATIONALITY3 != '' )"
		 * + " )" + " and IsRestricted = 'Y'";
		 * 
		 * DigitalAO.mLogger.debug("Query for Retricted Nationality :"+query);
		 * 
		 * List lstDecisions = iform .getDataFromDB(query);
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+", lstDecisions : "
		 * +lstDecisions.toString());
		 * 
		 * for(int j=0;j<lstDecisions.size();j++) { List<String>
		 * arr1=(List)lstDecisions.get(j);
		 * 
		 * value=arr1.get(0); } DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Nationality value : "+value);
		 * 
		 * //value=Integer.toString(count); strReturn=value; } catch (Exception
		 * e) { DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", Exception in Nationality Restriction " + e.getMessage()); } }
		 * //Count for raising Demographic Exception else
		 * if("DemographicValues".equals(controlName)) { int
		 * CRPartygridsize=iform.getDataFromGrid(
		 * "Q_USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS").size(); //int count=0;
		 * String value=""; String StrDemographic=""; try { /*for(int
		 * i=0;i<CRPartygridsize;i++) { String Demographic =
		 * iform.getTableCellValue("Q_USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS",
		 * i,30); if(StrDemographic.equals("")) StrDemographic=Demographic; else
		 * StrDemographic=StrDemographic+"','"+Demographic; iRBL.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+", StrDemographic : "+StrDemographic); }
		 * String query =
		 * "select count(*) from USR_0_IRBL_CountryMaster with(nolock) where countryCode in("
		 * +
		 * " select DEMOGRAPHIC from USR_0_IRBL_DEMOGRAPHIC_DTLS with(nolock) where WI_NAME = '"
		 * +getWorkitemName(iform)+"'" + " ) and IsDemographic = 'Y'"; List
		 * lstDecisions = iform .getDataFromDB(query); DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+", lstDecisions : "
		 * +lstDecisions.toString());
		 * 
		 * for(int j=0;j<lstDecisions.size();j++) { List<String>
		 * arr1=(List)lstDecisions.get(j);
		 * 
		 * value=arr1.get(0); } DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Demographic value : "+value);
		 * 
		 * //value=Integer.toString(count); strReturn=value; } catch (Exception
		 * e) { DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", Exception in Demographic Restriction " + e.getMessage()); } } //To
		 * fetch the names of all the exceptions to clear them automatically.
		 * else if("ExceptionNames".equals(controlName)) { int
		 * exceptionGridSize=iform.getDataFromGrid(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY").size(); String checkNames=""; try {
		 * for(int i=0;i<exceptionGridSize;i++) { String exceptionName =
		 * iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY", i,1);
		 * if(checkNames.equals("")) checkNames=exceptionName; else
		 * checkNames=checkNames+","+exceptionName; DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+", checkNames : "+checkNames); }
		 * strReturn=checkNames; } catch (Exception e) {
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", Exception in Loading Exception Names" + e.getMessage()); } } //To
		 * clear all the exceptions automatically. else
		 * if("raiseAutomaticClearException".equals(controlName)) { try {
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+", Data for Exception is "
		 * +data); String strCheckUncheck=iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data), 0);
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+", Exception check uncheck is "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 0)); Calendar cal = Calendar.getInstance();
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		 * String strDate = sdf.format(cal.getTime()); String
		 * strRaisedCleared=""; String strNewLine="";
		 * if("".equals(iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY"
		 * ,Integer.parseInt(data), 4)) ||
		 * iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 4)==null) strNewLine=""; else strNewLine="\n";
		 * if("true".equals(strCheckUncheck)) { strRaisedCleared="Approved";
		 * 
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 0) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 0));
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),0,"false"); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 2) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 2)+strNewLine+iform.getActivityName());
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),2,iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data),
		 * 2)+strNewLine+iform.getActivityName()); DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 3) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 3)+strNewLine+iform.getUserName());
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),3,iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data),
		 * 3)+strNewLine+iform.getUserName()); DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 4) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 4)+strNewLine+strRaisedCleared);
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),4,iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data),
		 * 4)+strNewLine+strRaisedCleared); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", iform.getTableCellValue(Q_USR_0_IRBL_EXCEPTION_HISTORY,Integer.parseInt(data), 5) "
		 * +iform.getTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data), 5)+strNewLine+strDate);
		 * iform.setTableCellValue("Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.
		 * parseInt(data),5,iform.getTableCellValue(
		 * "Q_USR_0_IRBL_EXCEPTION_HISTORY",Integer.parseInt(data),
		 * 5)+strNewLine+strDate);
		 * 
		 * } strReturn = "Cleared"; } catch (Exception e) {
		 * DigitalAO.mLogger.debug("WINAME : "+getWorkitemName(iform)+
		 * ", WSNAME: "+iform.getActivityName()+
		 * ", Exception in Service Request drop down load " + e.getMessage()); }
		 * } //To load Third Party Vendor Email ID from Third Party Vendor field
		 * automatically. else if("SetEmail".equals(controlName)) { String
		 * TPVendor = (String) iform.getValue("THIRD_PARTY_VENDOR");
		 * DigitalAO.mLogger.debug("TPVendor : "+TPVendor); try { List
		 * lstDecisions = iform .getDataFromDB(
		 * "SELECT ThirdParty_Email FROM USR_0_IRBL_THIRDPARTY_MASTER WITH(NOLOCK) WHERE THIRDPARTY='"
		 * +TPVendor+"' AND ISACTIVE='Y'"); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", lstDecisions : "+lstDecisions.toString());
		 * 
		 * String value1=""; iform.setValue("THIRD_PARTY_VENDOR_EMAIL","");
		 * 
		 * for(int i=0;i<lstDecisions.size();i++) { List<String>
		 * arr1=(List)lstDecisions.get(i); value1=arr1.get(0);
		 * iform.setValue("THIRD_PARTY_VENDOR_EMAIL",value1); strReturn=
		 * "Email Loaded"; } } catch (Exception e) { DigitalAO.mLogger.debug(
		 * "WINAME : "+getWorkitemName(iform)+", WSNAME: "
		 * +iform.getActivityName()+
		 * ", Exception in loading Third Party Vendor Email " + e.getMessage());
		 * } } else if("RestrictedValues_Nationality".equals(controlName)) { try
		 * { //String Nationality = (String)
		 * iform.getValue("Q_USR_0_IRBL_SIGNATORY_GRID_DTLS_NATIONALITY");
		 * /*List lstDecisions = iform .getDataFromDB(
		 * "SELECT IsRestricted FROM USR_0_IRBL_CountryMaster WITH(NOLOCK) WHERE countryCode='"
		 * +iform.getValue("Q_USR_0_IRBL_SIGNATORY_GRID_DTLS_NATIONALITY")+
		 * "' and ISACTIVE='Y'");
		 * 
		 * List lstDecisions = iform .getDataFromDB(
		 * "SELECT NationalityStatus FROM USR_0_IRBL_CountryMaster WITH(NOLOCK) WHERE countryCode='"
		 * +iform.getValue("Q_USR_0_IRBL_SIGNATORY_GRID_DTLS_NATIONALITY")+
		 * "' and ISACTIVE='Y' and NationalityStatus IS NOT NULL");
		 * 
		 * 
		 * String value=""; for(int i=0;i<lstDecisions.size();i++) {
		 * List<String> arr1=(List)lstDecisions.get(i); value=arr1.get(0);
		 * /*if("Y".equalsIgnoreCase(value))
		 * iform.setValue("Q_USR_0_IRBL_SIGNATORY_GRID_DTLS_NATIONALITY_STATUS",
		 * "Restricted"); else
		 * iform.setValue("Q_USR_0_IRBL_SIGNATORY_GRID_DTLS_NATIONALITY_STATUS",
		 * "Not Restricted");
		 * 
		 * iform.setValue("Q_USR_0_IRBL_SIGNATORY_GRID_DTLS_NATIONALITY_STATUS",
		 * value);
		 * 
		 * strReturn="Decision Loaded"; }
		 * 
		 * } catch (Exception e) { DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Exception in Decision drop down load " + e.getMessage()); } } else
		 * if("ProposedTenorValue".equals(controlName)) { String ProposedTenor =
		 * (String) iform.getValue("PROPOSED_TENOR"); DigitalAO.mLogger.debug(
		 * "ProposedTenor : "+ProposedTenor); try { List lstDecisions = iform
		 * .getDataFromDB(
		 * "select Description from USR_0_iRBL_Proposed_Tenor_Master with(nolock) where code ='"
		 * +ProposedTenor+"'");
		 * 
		 * String value=""; for(int i=0;i<lstDecisions.size();i++) {
		 * List<String> arr1=(List)lstDecisions.get(i); value=arr1.get(0);
		 * 
		 * strReturn=value; }
		 * 
		 * } catch (Exception e) { DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", Exception in loading Proposed Tenor value" + e.getMessage()); } }
		 * else if("setProductPriorityLevelBasedOnPriority".equals(controlName))
		 * { String Priority = (String) iform.getValue("PRIORITY"); String
		 * query=""; if("Express".equalsIgnoreCase(Priority.trim())) query =
		 * "update WFINSTRUMENTTABLE set PriorityLevel = 4 where ProcessInstanceID = '"
		 * +getWorkitemName(iform)+"'"; else query =
		 * "update WFINSTRUMENTTABLE set PriorityLevel = 1 where ProcessInstanceID = '"
		 * +getWorkitemName(iform)+"'"; iform.saveDataInDB(query); } else
		 * if("blacklistException".equals(controlName)) { List lstDecisions =
		 * iform.getDataFromDB(
		 * "SELECT MATCH_STATUS FROM USR_0_IRBL_BLACKLIST_GRID_DTLS WITH(nolock) WHERE WI_NAME='"
		 * +getWorkitemName(iform)+"'"); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+
		 * ", lstDecisions : "+lstDecisions.toString()); String value="";
		 * for(int i=0;i<lstDecisions.size();i++) { List<String>
		 * arr1=(List)lstDecisions.get(i); value=arr1.get(0);
		 * if("true".equalsIgnoreCase(value)) { strReturn=value; break; } }
		 * 
		 * } else if("blacklistException_firco".equals(controlName)) { List
		 * lstDecisions = iform.getDataFromDB(
		 * "SELECT MATCH_STATUS FROM USR_0_IRBL_FIRCO_GRID_DTLS WITH(nolock) WHERE WI_NAME='"
		 * +getWorkitemName(iform)+"'"); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", lstDecisions : "+lstDecisions.toString());
		 * String value=""; for(int i=0;i<lstDecisions.size();i++) {
		 * List<String> arr1=(List)lstDecisions.get(i); value=arr1.get(0);
		 * if("true".equalsIgnoreCase(value)) { strReturn=value; break; } } }
		 * else if("PEPException".equals(controlName)) { List lstDecisions =
		 * iform.getDataFromDB(
		 * "SELECT ISGOVERNMENTRELATION, COMPANYCATEGORY FROM USR_0_IRBL_CONDUCT_REL_PARTY_GRID_DTLS WITH(nolock) WHERE WI_NAME='"
		 * +getWorkitemName(iform)+"'"); DigitalAO.mLogger.debug("WINAME : "
		 * +getWorkitemName(iform)+", lstDecisions : "+lstDecisions.toString());
		 * for(int i=0;i<lstDecisions.size();i++) { List<String>
		 * arr1=(List)lstDecisions.get(i); if("Y".equalsIgnoreCase(arr1.get(0))
		 * || "Yes".equalsIgnoreCase(arr1.get(0)) ||
		 * "RF".equalsIgnoreCase(arr1.get(1))) { strReturn="true"; break; } } }
		 * //Count for raising Demographic Exception
		 */
		return strReturn;
	}
	public String fetchLdAccountSchemes(IFormReference iform) {

	    // Query to fetch SchemeCode from DB
	    String ldAccountQuery = "select SchemeCode from NG_DAO_LDACCOUNTS_MST with(nolock)";
	    List<List<String>> queryOutput = iform.getDataFromDB(ldAccountQuery);

//	    DigitalAO.mLogger.debug("ld_account_query_output : " + queryOutput);

	    String ldAccountScheme = "";

	    if (queryOutput != null && !queryOutput.isEmpty()) {

	        List<String> schemeList = new ArrayList<>();

	        for (List<String> row : queryOutput) {
	            if (row != null && !row.isEmpty()) {
	                schemeList.add(row.get(0));   // SchemeCode column
	            }
	        }

	        ldAccountScheme = String.join(",", schemeList);

	        iform.setValue("ldaccounts", ldAccountScheme);
	        DigitalAO.mLogger.debug("ldaccountscheme : " + ldAccountScheme);

	    } else {
	        DigitalAO.mLogger.debug("No LD Account Scheme found in DB.");
	    }

	    return ldAccountScheme;
	}

}
