package com.newgen.iforms.user;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

public class DigitalAO_AccountSummary extends DigitalAO_Common {

    private static NGEjbClient ngEjbClient;

 
    public String onclickevent(IFormReference iform, String control, String data) {

        String wiName = "";
        try {
            ngEjbClient = NGEjbClient.getSharedInstance();

            String processInstanceID=getWorkitemName(iform);
			String workstepName= getActivityName(iform);
			DigitalAO.mLogger.debug("processInstanceID :" +processInstanceID);
			String cifId=(String) iform.getValue("CIF");
			DigitalAO.mLogger.debug("cifId :" +cifId);
			
			int socketConnectionTimeOut=60;
			int integrationWaitTime=65;
			//CheckGridDataMap.put("CIF", cifId);
			String winame = getWorkitemName(iform);
			String cabinetName = getCabinetName(iform);
	    	String wi_name = getWorkitemName(iform);
	    	String ws_name = getActivityName(iform);
	    	String sessionID = getSessionId(iform);
	    	String userName = getUserName(iform);
	    	String jtsPort=iform.getServerPort();
	    	String jtsIP=iform.getServerIp();
	    	String ServerPort=iform.getServerPort();
	    	String ServerIp=iform.getServerIp();

            DigitalAO.mLogger.info("ACCOUNT_SUMMARY START | WI=" + wi_name + " | CIF=" + cifId);

            /* ---------- Socket Details ---------- */
            HashMap<String, String> socketDetails =
                    socketConnectionDetails(cabinetName, ServerIp, ServerPort, sessionID);

            if (socketDetails.isEmpty()) {
                DigitalAO.mLogger.error("Socket details not found | WI=" + wi_name);
                return "NotInserted";
            }
            
            String inXML = DigitalAO_Common.getAPProcedureInputXML(cabinetName,sessionID,"NG_DAO_SP_Delete_AccountSummary","'"+processInstanceID+"'");
	    	DigitalAO.mLogger.debug("AP proc inXML :" +inXML);
	    	String  strOutXml = WFNGExecute(inXML, jtsIP, jtsPort, 1);
	    	DigitalAO.mLogger.debug("AP proc strOutXml :" +strOutXml);
	    	if(strOutXml.indexOf("<MainCode>0</MainCode>")>-1)	
			{
	    		DigitalAO.mLogger.debug("deleted from procedure successfully ");
	    		//return "Deleted";
			}	
			else                                                                                    
			{
				DigitalAO.mLogger.debug("Not deleted from procedure  ");
				
			}
			

           //REQUEST BUILT
            StringBuilder requestXml = buildRequest(cifId);
            DigitalAO.mLogger.debug("requestXml :" +requestXml);
            String responseXML = socketConnection(cabinetName, userName,sessionID,ServerIp,ServerPort, wi_name, "AccountSummary", socketConnectionTimeOut, integrationWaitTime,  requestXml,socketDetails);
            
            DigitalAO.mLogger.debug("responseXML :" +responseXML);

            if (responseXML == null || responseXML.trim().length() == 0) {
                DigitalAO.mLogger.error("Empty response from integration | WI=" + wi_name);
                return "NotInserted";
            }

            DigitalAO.mLogger.debug("AccountSummary Response XML: " + responseXML);

            if (!responseXML.contains("<FINAccountDetail")) {
                DigitalAO.mLogger.error("Invalid ACCOUNT_SUMMARY response | WI=" + wi_name);
                return "NotInserted";
            }

            /* ---------- Parse & Insert ---------- */
            String parseResult = parseAccountSummary(
                    responseXML,
                    wi_name,
                    sessionID,
                    cabinetName,
                    cifId,
                    ServerIp,
                    ServerPort
            );

            if ("true".equalsIgnoreCase(parseResult)) {
    	    	DigitalAO.mLogger.debug("Account Summary call successful with intergrationStatus: " + parseResult);
    	    	String inputXML = DigitalAO_Common.getAPProcedureInputXML(cabinetName,sessionID,"NG_DAO_SP_AccountSummary","'"+processInstanceID+"'");
    	    	DigitalAO.mLogger.debug("AP proc inputXML :" +inputXML);
    	    	String  strOutputXml = WFNGExecute(inputXML, jtsIP, jtsPort, 1);
    	    	DigitalAO.mLogger.debug("AP proc strOutputXml :" +strOutputXml);
    	    	if(strOutputXml.indexOf("<MainCode>0</MainCode>")>-1)	
    			{
    	    		DigitalAO.mLogger.debug("Inserted in procedure successfully ");
    	    		return "Inserted";
    			}	
    			else
    			{
    				DigitalAO.mLogger.debug("Not inserted in procedure  ");
    				return "NotInserted";
    			}
    	    }
    	    else{
    	    	DigitalAO.mLogger.debug("Account Summary call failed with intergrationStatus: " + parseResult);
    	    	return "NotInserted";
    	    }
        } catch (Exception e) {
            DigitalAO.mLogger.error(
                    "Unhandled exception in AccountSummary | WI=" + wiName,
                    e
            );
            return "NotInserted";
        }
    }

    /* ============================================================
       BUILD REQUEST
       ============================================================ */
    private static StringBuilder buildRequest(String cifId) {
    	Date d1 = new Date();
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm");
		String DateExtra2 = sdf1.format(d1)+"+04:00";
		
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.mmm");
		String ReqDateTime = sdf2.format(d1);
        StringBuilder sb = new StringBuilder();

        sb.append("<EE_EAI_MESSAGE>")
          .append("<EE_EAI_HEADER>")
          .append("<MsgFormat>ACCOUNT_SUMMARY</MsgFormat>")
          .append("<MsgVersion>0000</MsgVersion>")
          .append("<RequestorChannelId>BPM</RequestorChannelId>")
          .append("<RequestorUserId>RAKUSER</RequestorUserId>")
          .append("<RequestorLanguage>E</RequestorLanguage>")
          .append("<RequestorSecurityInfo>secure</RequestorSecurityInfo>")
          .append("<ReturnCode>911</ReturnCode>")
          .append("<ReturnDesc>Issuer Timed Out</ReturnDesc>")
          .append("<MessageId>ACCOUNT_SUMMARY_0V27</MessageId>")
          .append("<Extra1>REQ||LAXMANRET.LAXMANRET</Extra1>")
          .append("<Extra2>").append(DateExtra2).append("</Extra2>")
          .append("</EE_EAI_HEADER>")
          .append("<FetchAccountListReq>")
          .append("<BankId>RAK</BankId>")
          .append("<CIFID>").append(cifId).append("</CIFID>")
          .append("<FetchClosedAcct>N</FetchClosedAcct>")
          .append("<AccountIndicator>A</AccountIndicator>")
          .append("</FetchAccountListReq>")
          .append("</EE_EAI_MESSAGE>");

        return sb;
    }
    /* ============================================================
       PARSE ACCOUNT SUMMARY
       ============================================================ */
    private static String parseAccountSummary(
            String xml,
            String wi_name,
            String sessionID,
            String cabinetName,
            String cifId,
            String serverIp,
            String serverPort) {

        try {
            // Remove illegal nested XML declarations
            xml = xml.replaceAll("<\\?xml.*?\\?>", "");

            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = db.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));

            NodeList list = doc.getElementsByTagName("FINAccountDetail");

            DigitalAO.mLogger.debug(
                    "FINAccountDetail count=" + list.getLength() + " | WI=" + wi_name);

            if (list.getLength() == 0) {
                DigitalAO.mLogger.warn("No FINAccountDetail nodes found | WI=" + wi_name);
                return "false";
            }

            for (int i = 0; i < list.getLength(); i++) {

                Element e = (Element) list.item(i);

                String branchId = getValue(e, "BranchId");
                String acctType = getValue(e, "AcctType");
                String accCat   = getValue(e, "AccountCategory");
                String crnCode  = getValue(e, "CrnCode");
                String prodId   = getValue(e, "ProductId");
                String prodDesc = getValue(e, "ProdDescription");

                // Log extracted values for debugging
                DigitalAO.mLogger.debug(
                        "\n--- FINAccountDetail ---" +
                        "\nBranchId       : " + branchId +
                        "\nAcctType       : " + acctType +
                        "\nAccountCategory: " + accCat +
                        "\nCrnCode        : " + crnCode +
                        "\nProductId      : " + prodId +
                        "\nProdDesc       : " + prodDesc +
                        "\nWI             : " + wi_name
                );

                // Validate mandatory fields
                if (prodId == null || prodId.trim().isEmpty()) {
                    DigitalAO.mLogger.error("Missing ProductId | WI=" + wi_name);
                    return "false";
                }
                DigitalAO.mLogger.debug( "[INSERT-ROW-PARAMS] " + "WI=" + wi_name + " | CIF=" + cifId + " | SessionId=" + sessionID + " | Cabinet=" + cabinetName + " | Server=" + serverIp + ":" + serverPort );
                String insertFlag = insertRow(
                        wi_name, cifId, branchId, acctType,
                        accCat, crnCode, prodId, prodDesc,
                        cabinetName, sessionID, serverIp, serverPort
                );

                if (!"true".equalsIgnoreCase(insertFlag)) {
                    DigitalAO.mLogger.error(
                            "Insert failed | WI=" + wi_name + " | ProductId=" + prodId);
                    return "false";
                }
            }

            DigitalAO.mLogger.info("Account summary parsed successfully | WI=" + wi_name);
            return "true";

        } catch (Exception e) {
            DigitalAO.mLogger.error("Parse exception | WI=" + wi_name, e);
            return "false";
        }
    }


    /* ============================================================
       INSERT
       ============================================================ */
    private static String insertRow(
            String wi_name,
            String cifId,
            String branchId,
            String acctType,
            String accCat,
            String crnCode,
            String prodId,
            String prodDesc,
            String cabinetName,
            String sessionID,
            String serverIp,
            String serverPort) {

        long startTime = System.currentTimeMillis();
        
        try {
        	
        	DigitalAO.mLogger.debug( "[INSERT-ROW-PARAMS] " + "WI=" + wi_name + " | CIF=" + cifId + " | SessionId=" + sessionID + " | Cabinet=" + cabinetName + " | Server=" + serverIp + ":" + serverPort );
           

            String createdOn =
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

            // Correct column order
            String cols =
                    "WI_NAME,CIF_ID,AcctType,AccountCategory," +
                    "CrnCode,ProductId,BranchId,ProdDescription,createdOn";

            String vals =
                    "'" + wi_name + "'," +
                    "'" + cifId + "'," +
                    "'" + acctType + "'," +
                    "'" + accCat + "'," +
                    "'" + crnCode + "'," +
                    "'" + prodId + "'," +
                    "'" + branchId + "'," +
                    "'" + prodDesc + "'," +
                    "'" + createdOn + "'";

            // TRACE LOGGING
            DigitalAO.mLogger.debug(
                    "\n[DB-INSERT-START]" +
                    "\nWI_NAME        : " + wi_name +
                    "\nCIF_ID         : " + cifId +
                    "\nAcctType       : " + acctType +
                    "\nAccountCategory: " + accCat +
                    "\nCrnCode        : " + crnCode +
                    "\nProductId      : " + prodId +
                    "\nBranchId       : " + branchId +
                    "\nProdDescription: " + prodDesc +
                    "\ncreatedOn      : " + createdOn +
                    "\nTable          : NG_DAO_ACCOUNT_SUMMARY"
            );

            // Build insert XML
            String inXML = DigitalAO_Common.apInsert(
                    cabinetName, sessionID, cols, vals, "NG_DAO_ACCOUNT_SUMMARY");

            DigitalAO.mLogger.debug("[DB-INSERT-REQUEST] XML=" + inXML);

            // Execute insert
            String outXML = WFNGExecute(inXML, serverIp, serverPort, 1);

            DigitalAO.mLogger.debug("[DB-INSERT-RESPONSE] XML=" + outXML);

            XMLParser parser = new XMLParser(outXML);
            String mainCode = parser.getValueOf("MainCode");

            long duration = System.currentTimeMillis() - startTime;

            if ("0".equals(mainCode)) {
                DigitalAO.mLogger.info(
                        "Insert successful | WI=" + wi_name +
                        " | ProductId=" + prodId +
                        " | Duration=" + duration + "ms"
                );
                return "true";
            } else {
                DigitalAO.mLogger.error(
                        "Insert failed | WI=" + wi_name +
                        " | ProductId=" + prodId +
                        " | MainCode=" + mainCode +
                        " | Duration=" + duration + "ms" +
                        " | ResponseXML=" + outXML
                );
                return "false";
            }

        } catch (Exception e) {
            DigitalAO.mLogger.error("DB insert exception | WI=" + wi_name, e);
            return "false";
        }
    }


    /* ============================================================
       UTIL
       ============================================================ */
    private static String getValue(Element e, String tag) {
        NodeList nl = e.getElementsByTagName(tag);
        return (nl != null && nl.getLength() > 0) ? nl.item(0).getTextContent() : "";
    }

    protected static String WFNGExecute(String xml, String ip, String port, int flag) {
        try {
            if (port.startsWith("33")) {
                return WFCallBroker.execute(xml, ip, Integer.parseInt(port), flag);
            }
            return ngEjbClient.makeCall(ip, port, "WebSphere", xml);
        } catch (Exception e) {
            DigitalAO.mLogger.error("WFNGExecute failed", e);
            return "";
        }
    }

    /* ============================================================
       SOCKET
       ============================================================ */
    private HashMap<String, String> socketConnectionDetails(String cabinetName, String sJtsIp, String iJtsPort, String sessionID) {
		HashMap<String, String> socketDetailsMap = new HashMap<String, String>();

		try {
			DigitalAO.mLogger.debug("Fetching Socket Connection Details.");
			System.out.println("Fetching Socket Connection Details.");

			String socketDetailsQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName = 'DigitalAO' and CallingSource = 'Form'";

			String socketDetailsInputXML = DigitalAO_Common.apSelectWithColumnNames(socketDetailsQuery, cabinetName, sessionID);
			DigitalAO.mLogger.debug("Socket Details APSelect InputXML: " + socketDetailsInputXML);

			String socketDetailsOutputXML = WFNGExecute(socketDetailsInputXML, sJtsIp, iJtsPort, 1);
			DigitalAO.mLogger.debug("Socket Details APSelect OutputXML: " + socketDetailsOutputXML);

			XMLParser xmlParserSocketDetails = new XMLParser(socketDetailsOutputXML);
			String socketDetailsMainCode = xmlParserSocketDetails.getValueOf("MainCode");
			DigitalAO.mLogger.debug("SocketDetailsMainCode: " + socketDetailsMainCode);

			int socketDetailsTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
			DigitalAO.mLogger.debug("SocketDetailsTotalRecords: " + socketDetailsTotalRecords);

			if (socketDetailsMainCode.equalsIgnoreCase("0") && socketDetailsTotalRecords > 0) {
				String xmlDataSocketDetails = xmlParserSocketDetails.getNextValueOf("Record");
				xmlDataSocketDetails = xmlDataSocketDetails.replaceAll("[ ]+>", ">").replaceAll("<[ ]+", "<");

				XMLParser xmlParserSocketDetailsRecord = new XMLParser(xmlDataSocketDetails);

				String socketServerIP = xmlParserSocketDetailsRecord.getValueOf("SocketServerIP");
				DigitalAO.mLogger.debug("SocketServerIP: " + socketServerIP);
				socketDetailsMap.put("SocketServerIP", socketServerIP);

				String socketServerPort = xmlParserSocketDetailsRecord.getValueOf("SocketServerPort");
				DigitalAO.mLogger.debug("SocketServerPort " + socketServerPort);
				socketDetailsMap.put("SocketServerPort", socketServerPort);

				DigitalAO.mLogger.debug("SocketServer Details found.");
				
			}
		} catch (Exception e) {
			DigitalAO.mLogger.debug("Exception in getting Socket Connection Details: " + e.getMessage());
			
		}

		return socketDetailsMap;
	}


    public static String socketConnection(String cabinetName, String username, String sessionID, String sJtsIp, String iJtsPort, String processInstanceID, String ws_name,
			int connection_timeout, int integrationWaitTime,StringBuilder sInputXML,HashMap<String, String> socketDetailsMap)
	{

		String socketServerIP;
		int socketServerPort;
		Socket socket = null;
		OutputStream out = null;
		InputStream socketInputStream = null;
		DataOutputStream dout = null;
		DataInputStream din = null;
		String outputResponse = null;
		String inputRequest = null;
		String inputMessageID = null;



		try
		{

			DigitalAO.mLogger.debug("userName "+ username);
			DigitalAO.mLogger.debug("SessionId "+ sessionID);

			socketServerIP=socketDetailsMap.get("SocketServerIP");
			DigitalAO.mLogger.debug("SocketServerIP "+ socketServerIP);
			socketServerPort=Integer.parseInt(socketDetailsMap.get("SocketServerPort"));
			DigitalAO.mLogger.debug("SocketServerPort "+ socketServerPort);

	   		if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort==0))
	   		{

    			socket = new Socket(socketServerIP, socketServerPort);
    			socket.setSoTimeout(connection_timeout*1000);
    			out = socket.getOutputStream();
    			socketInputStream = socket.getInputStream();
    			dout = new DataOutputStream(out);
    			din = new DataInputStream(socketInputStream);
    			DigitalAO.mLogger.debug("Dout " + dout);
    			DigitalAO.mLogger.debug("Din " + din);

    			outputResponse = "";

    			inputRequest = getRequestXML( cabinetName,sessionID ,processInstanceID, ws_name, username, sInputXML);


    			if (inputRequest != null && inputRequest.length() > 0)
    			{
    				int inputRequestLen = inputRequest.getBytes("UTF-16LE").length;
    				DigitalAO.mLogger.debug("RequestLen: "+inputRequestLen + "");
    				inputRequest = inputRequestLen + "##8##;" + inputRequest;
    				DigitalAO.mLogger.debug("InputRequest"+"Input Request Bytes : "+ inputRequest.getBytes("UTF-16LE"));
    				dout.write(inputRequest.getBytes("UTF-16LE"));dout.flush();
    			}
    			byte[] readBuffer = new byte[500];
    			int num = din.read(readBuffer);
    			if (num > 0)
    			{

    				byte[] arrayBytes = new byte[num];
    				System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
    				outputResponse = outputResponse+ new String(arrayBytes, "UTF-16LE");
					inputMessageID = outputResponse;
    				DigitalAO.mLogger.debug("OutputResponse: "+outputResponse);

    				if(!"".equalsIgnoreCase(outputResponse))
    					outputResponse = getResponseXML(cabinetName,sJtsIp,iJtsPort,sessionID, processInstanceID,outputResponse,integrationWaitTime );

    				if(outputResponse.contains("&lt;"))
    				{
    					outputResponse=outputResponse.replaceAll("&lt;", "<");
    					outputResponse=outputResponse.replaceAll("&gt;", ">");
    				}
    			}
    			socket.close();

				outputResponse = outputResponse.replaceAll("</MessageId>","</MessageId><InputMessageId>"+inputMessageID+"</InputMessageId>");

				return outputResponse;

    	 		}

    		else
    		{
    			DigitalAO.mLogger.debug("SocketServerIp and SocketServerPort is not maintained "+"");
    			DigitalAO.mLogger.debug("SocketServerIp is not maintained "+	socketServerIP);
    			DigitalAO.mLogger.debug(" SocketServerPort is not maintained "+	socketServerPort);
    			return "Socket Details not maintained";
    		}

		}

		catch (Exception e)
		{
			DigitalAO.mLogger.debug("Exception Occured Mq_connection_CC"+e.getStackTrace());
			return "";
		}
		finally
		{
			try
			{
				if(out != null)
				{
					out.close();
					out=null;
				}
				if(socketInputStream != null)
				{

					socketInputStream.close();
					socketInputStream=null;
				}
				if(dout != null)
				{

					dout.close();
					dout=null;
				}
				if(din != null)
				{

					din.close();
					din=null;
				}
				if(socket != null)
				{
					if(!socket.isClosed())
						socket.close();
					socket=null;
				}

			}

			catch(Exception e)
			{
				DigitalAO.mLogger.debug("Final Exception Occured Mq_connection_CC"+e.getStackTrace());
				//printException(e);
			}
		}


	}
    
    private static String getRequestXML(String cabinetName, String sessionID,
			String processInstanceID, String ws_name, String userName, StringBuilder sInputXML)
	{
		StringBuffer strBuff = new StringBuffer();
		strBuff.append("<APMQPUTGET_Input>");
		strBuff.append("<SessionId>" + sessionID + "</SessionId>");
		strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
		strBuff.append("<XMLHISTORY_TABLENAME>NG_DAO_XMLLOG_HISTORY</XMLHISTORY_TABLENAME>");
		strBuff.append("<WI_NAME>" + processInstanceID + "</WI_NAME>");
		strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
		strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
		strBuff.append("<MQ_REQUEST_XML>");
		strBuff.append(sInputXML);
		strBuff.append("</MQ_REQUEST_XML>");
		strBuff.append("</APMQPUTGET_Input>");
		DigitalAO.mLogger.debug("GetRequestXML: "+ strBuff.toString());
		return strBuff.toString();
	}
    private static String getResponseXML(String cabinetName,String sJtsIp,String iJtsPort, String sessionID, String processInstanceID,String message_ID, int integrationWaitTime)
	{

		String outputResponseXML="";
		try
		{
			String QueryString = "select OUTPUT_XML from NG_DAO_XMLLOG_HISTORY with (nolock) where MESSAGE_ID ='"+message_ID+"' and WI_NAME = '"+processInstanceID+"'";

			String responseInputXML =DigitalAO_Common.apSelectWithColumnNames(QueryString, cabinetName, sessionID);
			DigitalAO.mLogger.debug("Response APSelect InputXML: "+responseInputXML);

			int Loop_count=0;
			do
			{
				String responseOutputXML=WFNGExecute(responseInputXML,sJtsIp,iJtsPort,1);
				DigitalAO.mLogger.debug("Response APSelect OutputXML: "+responseOutputXML);

			    XMLParser xmlParserSocketDetails= new XMLParser(responseOutputXML);
			    String responseMainCode = xmlParserSocketDetails.getValueOf("MainCode");
			    DigitalAO.mLogger.debug("ResponseMainCode: "+responseMainCode);



			    int responseTotalRecords = Integer.parseInt(xmlParserSocketDetails.getValueOf("TotalRetrieved"));
			    DigitalAO.mLogger.debug("ResponseTotalRecords: "+responseTotalRecords);

			    if (responseMainCode.equals("0") && responseTotalRecords > 0)
				{

					String responseXMLData=xmlParserSocketDetails.getNextValueOf("Record");
					responseXMLData =responseXMLData.replaceAll("[ ]+>",">").replaceAll("<[ ]+", "<");

	        		XMLParser xmlParserResponseXMLData = new XMLParser(responseXMLData);
	        		
	        		outputResponseXML=xmlParserResponseXMLData.getValueOf("OUTPUT_XML");
	        		

	        		if("".equalsIgnoreCase(outputResponseXML)){
	        			outputResponseXML="Error";
	    			}
	        		break;
				}
			    Loop_count++;
			    Thread.sleep(1000);
			}
			while(Loop_count<integrationWaitTime);
			DigitalAO.mLogger.debug("integrationWaitTime: "+integrationWaitTime);

		}
		catch(Exception e)
		{
			DigitalAO.mLogger.debug("Exception occurred in outputResponseXML" + e.getMessage());
			outputResponseXML="Error";
		}

		return outputResponseXML;

	}
	
    
    
}
